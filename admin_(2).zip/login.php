<?php 
// 1. সেশন শুরু
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// 2. ডাটাবেস কনফিগারেশন
include 'config.php'; 

// 3. ফর্ম সাবমিট লজিক
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_name'] = $user['name'];
        $_SESSION['role'] = $user['role'];
        
        if($user['role'] == 'admin') {
            header("Location: admin/dashboard.php");
            exit(); 
        } else {
            header("Location: index.php");
            exit(); 
        }
    } else {
        $error = "Invalid Email or Password!";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Welcome</title>
    
    <!-- ====== ফন্ট: Inter ====== -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>
    <link rel="stylesheet" href="assets/css/premium-theme.css"/>

    <style>
        /* =========================================
           ✅ LOGIN PAGE UPDATED: 11 August 2026
           📌 Exact Match with Previous Blue Theme
           🔧 কালার পরিবর্তন: সবুজ → নীল (#1e2ab8)
        ========================================= */
        
        :root {
            --primary-blue: #1e2ab8;
            --primary-gradient: linear-gradient(135deg, #1e2ab8 0%, #4338ca 100%);
            --primary-hover: #0f172a;
            --primary-light: #e0e7ff;
            --border-color: #e2e8f0;
            --dark-bg: #0f172a;
            --text-slate: #64748b;
            --light-bg: #f8fafc;
            --card-bg: #ffffff;
        }

        /* ডার্ক মোড অটো */
        @media (prefers-color-scheme: dark) {
            :root {
                --card-bg: #1e293b;
                --light-bg: #0f172a;
                --dark-bg: #e2e8f0;
                --text-slate: #94a3b8;
                --border-color: #334155;
            }
            body { 
                background: radial-gradient(circle at 0% 0%, #0f172a 0%, #1e293b 100%) !important; 
            }
            .login-card { 
                background: #1e293b; 
                border-color: #334155 !important; 
            }
            .login-card::before { 
                background: linear-gradient(90deg, #1e2ab8, #4338ca) !important; 
            }
            .login-header h2 { color: #e2e8f0; }
            .login-header p { color: #94a3b8; }
            .brand-icon-wrapper { 
                background: #0f172a; 
                color: #60a5fa; 
                box-shadow: inset 0 0 0 1px rgba(30, 42, 184, 0.2);
            }
            .input-box input { 
                background: #0f172a; 
                border-color: #334155; 
                color: #e2e8f0; 
            }
            .input-box input:focus { 
                border-color: #60a5fa; 
                background: #1e293b; 
                box-shadow: 0 0 0 4px rgba(30, 42, 184, 0.15);
            }
            .input-box i { color: #64748b; }
            .input-box input:focus + i { color: #60a5fa; }
            .footer-links { border-top-color: #334155; }
            .footer-links a { color: #60a5fa; }
            .footer-links a:hover { color: #93bbfc; }
            .btn-back-home { color: #94a3b8 !important; }
            .btn-back-home:hover { color: #60a5fa !important; }
            .error-msg { background: #1e293b; border-color: #7f1d1d; color: #fca5a5; }
        }

        * { font-style: normal !important; }

        body {
            font-family: 'Inter', sans-serif;
            background: radial-gradient(circle at 0% 0%, #ffffff 0%, var(--light-bg) 100%);
            min-height: 100vh;
            margin: 0;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        /* ====== মেইন কন্টেইনার ====== */
        .login-wrapper {
            width: 100%;
            max-width: 430px;
            padding: 20px;
        }

        /* ====== লগইন কার্ড ====== */
        .login-card {
            background: var(--card-bg);
            border-radius: 24px;
            padding: 40px 35px;
            box-shadow: 0 15px 35px rgba(30, 42, 184, 0.04), 0 5px 15px rgba(0, 0, 0, 0.02);
            border: 1px solid var(--border-color);
            position: relative;
            overflow: hidden;
        }

        /* ====== টপ বর্ডার (নীল) ====== */
        .login-card::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 5px;
            background: var(--primary-gradient);
        }

        /* ====== ব্র্যান্ড আইকন ====== */
        .brand-icon-wrapper {
            width: 65px;
            height: 65px;
            background: var(--primary-light);
            color: var(--primary-blue);
            border-radius: 18px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.8rem;
            margin: 0 auto 20px auto;
            box-shadow: inset 0 0 0 1px rgba(30, 42, 184, 0.1);
        }

        /* ====== হেডার ====== */
        .login-header h2 {
            font-weight: 900;
            font-size: 1.75rem;
            color: var(--dark-bg);
            margin-bottom: 8px;
            letter-spacing: -0.5px;
            text-transform: uppercase;
        }

        .login-header p {
            color: var(--text-slate);
            font-size: 0.95rem;
            margin-bottom: 30px;
            font-weight: 500;
        }

        /* ====== ইনপুট বক্স ====== */
        .input-box {
            position: relative;
            margin-bottom: 22px;
        }

        .input-box i {
            position: absolute;
            left: 18px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--text-slate);
            transition: all 0.25s ease;
            font-size: 1rem;
        }

        .input-box input {
            width: 100%;
            padding: 15px 20px 15px 50px;
            background: var(--light-bg);
            border: 1.5px solid var(--border-color);
            border-radius: 14px;
            font-size: 0.95rem;
            transition: all 0.25s ease;
            outline: none;
            color: var(--dark-bg);
            font-weight: 600;
        }

        .input-box input::placeholder {
            color: var(--text-slate);
            font-weight: 400;
        }

        .input-box input:focus {
            border-color: var(--primary-blue);
            background: var(--card-bg);
            box-shadow: 0 0 0 4px rgba(30, 42, 184, 0.08);
        }

        .input-box input:focus + i {
            color: var(--primary-blue);
        }

        /* ====== লগইন বাটন (নীল) ====== */
        .btn-login {
            background: var(--primary-gradient);
            color: #fff;
            padding: 15px;
            border: none;
            border-radius: 14px;
            width: 100%;
            font-weight: 900;
            font-size: 0.95rem;
            transition: all 0.3s ease;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            box-shadow: 0 4px 15px rgba(30, 42, 184, 0.15);
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .btn-login:hover {
            background: var(--primary-hover);
            transform: translateY(-2px);
            box-shadow: 0 8px 30px rgba(30, 42, 184, 0.25);
            color: #fff;
        }

        /* ====== এরর মেসেজ ====== */
        .error-msg {
            background: #fef2f2;
            color: #dc2626;
            padding: 12px 15px;
            border-radius: 14px;
            text-align: left;
            font-weight: 700;
            font-size: 0.85rem;
            margin-bottom: 22px;
            border: 1px solid #fee2e2;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .error-msg i {
            font-size: 1.1rem;
        }

        /* ====== ফুটার লিংক ====== */
        .footer-links {
            margin-top: 30px;
            text-align: center;
            font-size: 0.88rem;
            border-top: 1px solid var(--border-color);
            padding-top: 20px;
            font-weight: 600;
        }

        .footer-links p {
            color: var(--text-slate);
            margin-bottom: 8px;
        }

        .footer-links a {
            color: var(--primary-blue);
            text-decoration: none;
            font-weight: 700;
            transition: color 0.2s ease;
        }

        .footer-links a:hover {
            color: var(--primary-hover);
            text-decoration: underline;
        }
        
        .btn-back-home {
            color: var(--text-slate) !important;
            font-weight: 600 !important;
            text-decoration: none !important;
            display: inline-block;
            transition: all 0.2s ease;
        }
        
        .btn-back-home:hover {
            color: var(--primary-blue) !important;
            text-decoration: underline !important;
        }

        /* ====== রেসপনসিভ ====== */
        @media (max-width: 480px) {
            .login-wrapper { padding: 15px; }
            .login-card {
                padding: 30px 20px;
                border-radius: 20px;
            }
            .login-header h2 {
                font-size: 1.4rem;
            }
            .brand-icon-wrapper {
                width: 55px;
                height: 55px;
                font-size: 1.5rem;
            }
            .input-box input {
                padding: 13px 16px 13px 44px;
                font-size: 0.85rem;
            }
            .btn-login {
                padding: 13px;
                font-size: 0.85rem;
            }
            .footer-links {
                font-size: 0.8rem;
            }
        }
    </style>
</head>
<body>

<div class="login-wrapper">
    <div class="login-card animate__animated animate__fadeInUp">
        
        <!-- ====== ব্র্যান্ড আইকন ====== -->
        <div class="brand-icon-wrapper">
            <i class="fas fa-shield-halved"></i>
        </div>

        <!-- ====== হেডার ====== -->
        <div class="login-header text-center">
            <h2>Welcome Back</h2>
            <p>Sign in to manage your account</p>
        </div>

        <!-- ====== এরর / সাকসেস মেসেজ ====== -->
        <?php if(isset($_GET['registered'])): ?>
            <div class="alert alert-success py-2 small mb-3 border-0 text-center" style="background:#ecfdf5;color:#065f46;font-weight:700;border-radius:10px;">
                <i class="fas fa-check-circle me-1"></i> Account created successfully! Please sign in.
            </div>
        <?php endif; ?>

        <?php if(isset($error)): ?>
            <div class="error-msg animate__animated animate__headShake">
                <i class="fas fa-circle-exclamation"></i> 
                <span><?= $error ?></span>
            </div>
        <?php endif; ?>

        <!-- ====== লগইন ফর্ম ====== -->
        <form method="POST">
            <div class="input-box">
                <i class="fas fa-envelope"></i>
                <input type="email" name="email" placeholder="Email Address" required autocomplete="email">
            </div>

            <div class="input-box">
                <i class="fas fa-lock"></i>
                <input type="password" name="password" placeholder="Password" required>
            </div>

            <button type="submit" class="btn-login">
                <span>Sign In</span> <i class="fas fa-arrow-right"></i>
            </button>
        </form>

        <!-- ====== ফুটার লিংক ====== -->
        <div class="footer-links">
            <p>New to our platform? <a href="signup.php">Create Account</a></p>
            <a href="index.php" class="btn-back-home">
                <i class="fas fa-chevron-left me-1"></i> Back to Home
            </a>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="assets/js/premium.js"></script>
</body>
</html>