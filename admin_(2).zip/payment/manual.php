<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include '../config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

if (empty($set['enable_manual_payment'])) {
    die("
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset='utf-8'>
        <title>Manual Payment Disabled</title>
        <style>
            body { font-family: 'Inter', system-ui, sans-serif; background: #0f172a; color: #f8fafc; display: grid; place-items: center; min-height: 100vh; margin: 0; padding: 20px; box-sizing: border-box; }
            .box { max-width: 520px; width: 100%; background: #1e293b; border: 1px solid #334155; border-radius: 20px; padding: 32px; text-align: center; }
            h2 { color: #f87171; margin-top: 0; }
            p { color: #94a3b8; line-height: 1.6; }
            .btn { display: inline-block; background: #2563eb; color: #fff; padding: 12px 24px; border-radius: 12px; text-decoration: none; font-weight: 700; margin-top: 14px; }
        </style>
    </head>
    <body>
        <div class='box'>
            <h2>Manual Payment Currently Disabled</h2>
            <p>The administrator has currently disabled manual payment submissions. Please check back later or contact support.</p>
            <a href='../index.php' class='btn'>Return to Store</a>
        </div>
    </body>
    </html>
    ");
}

$errors = [];
$success = false;

/* ---------------------------------------------------------
   STEP A: Handle the confirmation form submit (POST)
--------------------------------------------------------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $product_id     = $_POST['product_id'] ?? null;
    $sub_email      = trim($_POST['sub_email'] ?? '');
    $final_amount   = $_POST['final_amount'] ?? null;
    $selected_var   = trim($_POST['selected_variation'] ?? '');
    $trx_id         = trim($_POST['trx_id'] ?? '');
    $sender_number  = trim($_POST['sender_number'] ?? '');

    if (!$product_id) $errors[] = "Invalid product.";
    if ($trx_id === '') $errors[] = "Transaction ID is required.";
    if ($sender_number === '') $errors[] = "Sender number is required.";

    if (empty($errors)) {
        $stmt = $pdo->prepare("SELECT * FROM products WHERE id = ?");
        $stmt->execute([$product_id]);
        $product = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$product) {
            $errors[] = "Product not found.";
        } else {
            $amount = is_numeric($final_amount) && $final_amount > 0 ? (float) $final_amount : (float) $product['offer_price'];

            // Prevent duplicate transaction id submissions
            $check = $pdo->prepare("SELECT id FROM orders WHERE trx_id = ?");
            $check->execute([$trx_id]);

            if ($check->rowCount() > 0) {
                $errors[] = "This Transaction ID has already been submitted. Please check your Orders page.";
            } else {
                $status = 'Pending';
                $now = date('Y-m-d H:i:s');
                $ins = $pdo->prepare("INSERT INTO orders (user_id, product_id, amount, status, payment_method, sub_email, sender_number, trx_id, created_at) VALUES (?, ?, ?, ?, 'Manual', ?, ?, ?, ?)");
                $ins->execute([
                    $_SESSION['user_id'],
                    $product_id,
                    $amount,
                    $status,
                    $sub_email,
                    $sender_number,
                    $trx_id,
                    $now
                ]);
                $new_order_id = (int)$pdo->lastInsertId();
                header("Location: ../invoice.php?order_id=" . $new_order_id . "&submitted=1");
                exit();
            }
        }
    }
}

/* ---------------------------------------------------------
   STEP B: Show the payment instruction + confirmation form (GET)
--------------------------------------------------------- */
$product_id   = $_GET['product_id'] ?? ($_POST['product_id'] ?? null);
$sub_email    = $_GET['sub_email'] ?? ($_POST['sub_email'] ?? '');
$selected_var = $_GET['selected_variation'] ?? ($_POST['selected_variation'] ?? '');
$final_amount = $_GET['final_amount'] ?? ($_POST['final_amount'] ?? null);

if (!$product_id) {
    header("Location: ../index.php");
    exit();
}

$stmt = $pdo->prepare("SELECT * FROM products WHERE id = ?");
$stmt->execute([$product_id]);
$product = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$product) {
    die("Product not found.");
}

$amount = (is_numeric($final_amount) && $final_amount > 0) ? (float) $final_amount : (float) $product['offer_price'];

include '../header.php';
?>

<!-- ====== ফন্ট: Inter ====== -->
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

<style>
    /* =========================================
       ✅ MANUAL PAYMENT UPDATED: 11 August 2026
       📌 Exact Match with Previous Blue Theme
       🔧 কালার পরিবর্তন: সবুজ → নীল (#1e2ab8)
    ========================================= */
    
    :root {
        --primary-blue: #1e2ab8;
        --primary-gradient: linear-gradient(135deg, #1e2ab8 0%, #4338ca 100%);
        --primary-hover: #0f172a;
        --primary-light: #e0e7ff;
        --border-color: #e2e8f0;
        --dark-bg: #0f172a;
        --text-slate: #64748b;
        --light-bg: #f8fafc;
        --card-bg: #ffffff;
    }

    /* ডার্ক মোড অটো */
    @media (prefers-color-scheme: dark) {
        :root {
            --card-bg: #1e293b;
            --light-bg: #0f172a;
            --dark-bg: #e2e8f0;
            --text-slate: #94a3b8;
            --border-color: #334155;
        }
        body { background-color: #0f172a; }
        .manual-pay-card { background: #1e293b; border-color: #334155; }
        .manual-summary-box { background: #0f172a; border-color: #334155; }
        .manual-summary-box .amt { color: #60a5fa; }
        .jx-method-icon.bkash { background: #1e293b; color: #f472b6; }
        .jx-method-icon.nagad { background: #1e293b; color: #fb923c; }
        .jx-method-icon.rocket { background: #1e293b; color: #a78bfa; }
        .form-control-lg-rounded { background: #1e293b; color: #e2e8f0; border-color: #334155; }
        .form-control-lg-rounded:focus { border-color: #60a5fa; }
        .steps-note { color: #94a3b8; }
        .jx-number-box code { color: #e2e8f0 !important; }
        .alert-jx-error { background: #1e293b; border-color: #7f1d1d; color: #fca5a5; }
        .breadcrumb-item a { color: #60a5fa !important; }
    }

    * { font-style: normal !important; }

    body { 
        font-family: 'Inter', sans-serif; 
        background-color: var(--light-bg); 
    }

    .manual-pay-card {
        background: var(--card-bg);
        border-radius: 22px;
        border: 1px solid #dbeafe;
        box-shadow: 0 14px 34px rgba(30, 42, 184, 0.08);
        padding: clamp(16px, 3vw, 30px);
        margin: clamp(14px, 3vw, 28px) auto 0;
        width: min(100%, 680px);
    }

    /* ====== সারাংশ বক্স ====== */
    .manual-summary-box {
        background: linear-gradient(135deg, #eff6ff 0%, #eef2ff 100%);
        border: 1px solid #c7d2fe;
        border-radius: 16px;
        padding: 16px 20px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 18px;
        margin-bottom: 22px;
    }

    .manual-summary-box .amt { 
        font-size: 1.6rem; 
        font-weight: 900; 
        color: var(--primary-blue); 
    }

    /* ====== মেথড গ্রিড ====== */
    .method-grid { 
        display: grid; 
        grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); 
        gap: 14px; 
        margin-bottom: 24px; 
    }

    .jx-number-box {
        background: #fff;
        border: 1px solid #dbeafe;
        border-radius: 14px;
        padding: 14px 16px;
        transition: all 0.3s ease;
        min-width: 0;
    }

    .jx-number-box:hover {
        border-color: var(--primary-blue);
        box-shadow: 0 4px 15px rgba(30, 42, 184, 0.06);
    }

    .jx-method-icon {
        width: 38px;
        height: 38px;
        border-radius: 10px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.1rem;
    }

    .jx-method-icon.bkash { background: #fdeef4; color: #e2136e; }
    .jx-method-icon.nagad { background: #fef2f2; color: #f97316; }
    .jx-method-icon.rocket { background: #eef2ff; color: #6d28d9; }

    .jx-number-box code {
        font-weight: 900;
        font-size: 1rem;
        color: var(--dark-bg);
        background: transparent;
        padding: 0;
    }

    .jx-copy-btn {
        background: transparent;
        border: 1px solid var(--border-color);
        border-radius: 8px;
        padding: 4px 12px;
        font-size: 0.7rem;
        font-weight: 700;
        color: var(--text-slate);
        transition: all 0.3s ease;
        cursor: pointer;
    }

    .jx-copy-btn:hover {
        background: var(--primary-blue);
        color: #fff;
        border-color: var(--primary-blue);
    }

    /* ====== ফর্ম এলিমেন্ট ====== */
    .form-control-lg-rounded {
        display: block;
        width: 100%;
        max-width: 100%;
        min-height: 50px;
        box-sizing: border-box;
        border-radius: 12px;
        border: 1px solid #cbd5e1;
        padding: 13px 16px;
        font-size: 0.95rem;
        font-weight: 600;
        background: #fff;
        color: #0f172a;
        transition: all 0.3s ease;
    }

    .form-control-lg-rounded:focus {
        border-color: var(--primary-blue);
        box-shadow: 0 0 0 0.25rem rgba(30, 42, 184, 0.15);
        outline: none;
    }

    .form-control-lg-rounded::placeholder {
        color: var(--text-slate);
        font-weight: 400;
    }

    .form-label {
        font-weight: 900;
        font-size: 0.75rem;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        color: var(--text-slate);
    }

    .form-label i {
        color: var(--primary-blue);
    }

    /* ====== সাবমিট বাটন ====== */
    .jx-pay-submit {
        background: var(--primary-gradient);
        color: #fff;
        border: none;
        padding: 15px;
        font-size: 0.9rem;
        font-weight: 900;
        border-radius: 14px;
        width: 100%;
        box-shadow: 0 4px 15px rgba(30, 42, 184, 0.2);
        transition: all 0.3s ease;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }

    .jx-pay-submit:hover {
        transform: translateY(-2px);
        box-shadow: 0 10px 30px rgba(30, 42, 184, 0.3);
        background: var(--primary-hover);
        color: #fff;
    }

    .jx-pay-submit i {
        margin-right: 8px;
    }

    /* ====== স্টেপস ====== */
    .steps-note {
        font-size: 0.85rem;
        color: var(--text-slate);
        line-height: 2;
        font-weight: 500;
    }

    .steps-note .jx-step-num {
        display: inline-block;
        width: 24px;
        height: 24px;
        background: var(--primary-light);
        color: var(--primary-blue);
        border-radius: 50%;
        text-align: center;
        line-height: 24px;
        font-weight: 900;
        font-size: 0.7rem;
        margin-right: 8px;
    }

    /* ====== অ্যালার্ট ====== */
    .alert-jx-error {
        background: #fef2f2;
        border: 1px solid #fee2e2;
        color: #dc2626;
        border-radius: 12px;
        padding: 12px 16px;
        font-size: 0.9rem;
        font-weight: 600;
        margin-bottom: 18px;
    }

    .alert-jx-error i {
        margin-right: 6px;
    }

    /* ====== ব্রেডক্রাম্ব ====== */
    .breadcrumb {
        background: transparent;
        padding: 0;
        margin-bottom: 10px;
    }

    .breadcrumb-item a {
        color: var(--primary-blue);
        text-decoration: none;
        font-weight: 700;
        font-size: 0.8rem;
        text-transform: uppercase;
        letter-spacing: 0.3px;
    }

    .breadcrumb-item a:hover {
        color: var(--primary-hover);
        text-decoration: underline;
    }

    .breadcrumb-item.active {
        color: var(--text-slate);
        font-weight: 600;
        font-size: 0.8rem;
        text-transform: uppercase;
        letter-spacing: 0.3px;
    }

    /* ====== রেসপনসিভ ====== */
    @media (max-width: 768px) {
        .manual-pay-card { padding: 20px; border-radius: 20px; }
        .manual-summary-box .amt { font-size: 1.3rem; }
        .method-grid { grid-template-columns: 1fr; }
        .jx-pay-submit { font-size: 0.8rem; padding: 13px; }
        .steps-note { font-size: 0.8rem; }
    }

    @media (max-width: 480px) {
        .manual-pay-card { padding: 14px; border-radius: 16px; margin-top: 12px; }
        .manual-summary-box { align-items: flex-start; padding: 14px; }
        .manual-summary-box .text-end { text-align: right !important; }
        .jx-number-box { padding: 12px; }
        .manual-summary-box { flex-direction: column; text-align: center; gap: 8px; }
        .manual-summary-box .amt { font-size: 1.2rem; }
        .jx-number-box { padding: 12px; }
        .jx-number-box code { font-size: 0.85rem; }
        .form-control-lg-rounded { font-size: 0.85rem; padding: 11px 14px; }
    }
</style>

<div class="container pb-5">
    <div class="manual-pay-card animate__animated animate__fadeInUp">

        <nav aria-label="breadcrumb" class="mb-2">
            <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item"><a href="../index.php"><i class="fas fa-home"></i> Home</a></li>
                <li class="breadcrumb-item"><a href="../product.php?id=<?= (int)$product['id'] ?>">Product</a></li>
                <li class="breadcrumb-item active">Manual Payment</li>
            </ol>
        </nav>

        <h4 class="fw-bold mb-1" style="color: var(--dark-bg); text-transform: uppercase; letter-spacing: -0.5px; font-size: 1.3rem;">
            <i class="fa-solid fa-mobile-screen-button me-2" style="color: var(--primary-blue);"></i> Manual Payment
        </h4>
        <p class="text-muted small mb-4" style="color: var(--text-slate); font-weight: 500;">
            Send money to any of the numbers below, then submit your Transaction ID for verification.
        </p>

        <?php if(!empty($errors)): ?>
            <div class="alert-jx-error animate__animated animate__headShake">
                <?php foreach($errors as $e) echo "<div><i class='fa-solid fa-circle-exclamation me-1'></i> " . htmlspecialchars($e) . "</div>"; ?>
            </div>
        <?php endif; ?>

        <!-- ====== সারাংশ ====== -->
        <div class="manual-summary-box">
            <div>
                <div class="small text-muted fw-bold text-uppercase" style="font-size:.7rem; letter-spacing: 0.5px; color: var(--text-slate);">Product</div>
                <div class="fw-bold" style="color: var(--dark-bg);"><?= htmlspecialchars($product['title']) ?></div>
            </div>
            <div class="text-end">
                <div class="small text-muted fw-bold text-uppercase" style="font-size:.7rem; letter-spacing: 0.5px; color: var(--text-slate);">Amount To Pay</div>
                <div class="amt">৳<?= number_format($amount, 2) ?></div>
            </div>
        </div>

        <!-- ====== পেমেন্ট মেথড ====== -->
        <div class="method-grid">
            <?php if(!empty($set['bkash_number'])): ?>
            <div class="jx-number-box">
                <div class="d-flex align-items-center gap-2 mb-2">
                    <div class="jx-method-icon bkash"><i class="fa-solid fa-mobile-screen"></i></div>
                    <div>
                        <div class="fw-bold small" style="color: var(--dark-bg);">bKash</div>
                        <div class="text-muted" style="font-size:.7rem; color: var(--text-slate);"><?= htmlspecialchars($set['manual_payment_type'] ?? 'Personal') ?></div>
                    </div>
                </div>
                <div class="d-flex w-100 justify-content-between align-items-center">
                    <code class="fw-bold" style="color:#e2136e;font-size:1rem;"><?= htmlspecialchars($set['bkash_number']) ?></code>
                    <button type="button" class="jx-copy-btn" onclick="jxCopyText('<?= htmlspecialchars($set['bkash_number']) ?>', this)">
                        <i class="fa-regular fa-copy"></i> Copy
                    </button>
                </div>
            </div>
            <?php endif; ?>

            <?php if(!empty($set['nagad_number'])): ?>
            <div class="jx-number-box">
                <div class="d-flex align-items-center gap-2 mb-2">
                    <div class="jx-method-icon nagad"><i class="fa-solid fa-mobile-screen"></i></div>
                    <div>
                        <div class="fw-bold small" style="color: var(--dark-bg);">Nagad</div>
                        <div class="text-muted" style="font-size:.7rem; color: var(--text-slate);"><?= htmlspecialchars($set['manual_payment_type'] ?? 'Personal') ?></div>
                    </div>
                </div>
                <div class="d-flex w-100 justify-content-between align-items-center">
                    <code class="fw-bold" style="color:#f97316;font-size:1rem;"><?= htmlspecialchars($set['nagad_number']) ?></code>
                    <button type="button" class="jx-copy-btn" onclick="jxCopyText('<?= htmlspecialchars($set['nagad_number']) ?>', this)">
                        <i class="fa-regular fa-copy"></i> Copy
                    </button>
                </div>
            </div>
            <?php endif; ?>

            <?php if(!empty($set['rocket_number'])): ?>
            <div class="jx-number-box">
                <div class="d-flex align-items-center gap-2 mb-2">
                    <div class="jx-method-icon rocket"><i class="fa-solid fa-mobile-screen"></i></div>
                    <div>
                        <div class="fw-bold small" style="color: var(--dark-bg);">Rocket</div>
                        <div class="text-muted" style="font-size:.7rem; color: var(--text-slate);"><?= htmlspecialchars($set['manual_payment_type'] ?? 'Personal') ?></div>
                    </div>
                </div>
                <div class="d-flex w-100 justify-content-between align-items-center">
                    <code class="fw-bold" style="color:#6d28d9;font-size:1rem;"><?= htmlspecialchars($set['rocket_number']) ?></code>
                    <button type="button" class="jx-copy-btn" onclick="jxCopyText('<?= htmlspecialchars($set['rocket_number']) ?>', this)">
                        <i class="fa-regular fa-copy"></i> Copy
                    </button>
                </div>
            </div>
            <?php endif; ?>

            <?php if(!empty($set['upay_number'])): ?>
            <div class="jx-number-box">
                <div class="d-flex align-items-center gap-2 mb-2">
                    <div class="jx-method-icon" style="background:#0284c7;color:#fff;"><i class="fa-solid fa-mobile-screen"></i></div>
                    <div>
                        <div class="fw-bold small" style="color: var(--dark-bg);">Upay</div>
                        <div class="text-muted" style="font-size:.7rem; color: var(--text-slate);"><?= htmlspecialchars($set['manual_payment_type'] ?? 'Personal') ?></div>
                    </div>
                </div>
                <div class="d-flex w-100 justify-content-between align-items-center">
                    <code class="fw-bold" style="color:#0284c7;font-size:1rem;"><?= htmlspecialchars($set['upay_number']) ?></code>
                    <button type="button" class="jx-copy-btn" onclick="jxCopyText('<?= htmlspecialchars($set['upay_number']) ?>', this)">
                        <i class="fa-regular fa-copy"></i> Copy
                    </button>
                </div>
            </div>
            <?php endif; ?>
        </div>

        <?php if(empty($set['bkash_number']) && empty($set['nagad_number']) && empty($set['rocket_number']) && empty($set['upay_number'])): ?>
            <div class="alert-jx-error mb-4">
                <i class="fa-solid fa-triangle-exclamation me-1"></i> Manual payment numbers are not set up yet. Please contact admin.
            </div>
        <?php endif; ?>

        <!-- ====== স্টেপস ====== -->
        <div class="steps-note mb-4">
            <div><span class="jx-step-num">1</span> Open your bKash / Nagad / Rocket / Upay app and choose <b>"Send Money"</b>.</div>
            <div><span class="jx-step-num">2</span> Send exactly <b>৳<?= number_format($amount, 2) ?></b> to the number above.</div>
            <div><span class="jx-step-num">3</span> Copy the <b>Transaction ID (TrxID)</b> from the confirmation SMS.</div>
            <?php if(!empty($set['auto_approve_orders']) && (int)$set['auto_approve_orders'] === 1): ?>
                <div style="color:#059669;font-weight:700;"><span class="jx-step-num" style="background:#059669;color:#fff;">4</span> Fill the form below & submit — <b>Your order will be instantly activated & ZIP download enabled!</b></div>
            <?php else: ?>
                <div><span class="jx-step-num">4</span> Fill the form below and submit — our team will verify and activate your order shortly.</div>
            <?php endif; ?>
        </div>

        <?php if(!empty($set['manual_payment_note'])): ?>
            <div class="text-muted small mb-4" style="background: var(--light-bg); border-radius:12px; padding:12px 16px; border:1px solid var(--border-color); color: var(--text-slate);">
                <i class="fa-solid fa-circle-info me-1" style="color: var(--primary-blue);"></i> <?= nl2br(htmlspecialchars($set['manual_payment_note'])) ?>
            </div>
        <?php endif; ?>

        <!-- ====== ফর্ম ====== -->
        <form method="POST" action="manual.php">
            <input type="hidden" name="product_id" value="<?= (int)$product['id'] ?>">
            <input type="hidden" name="sub_email" value="<?= htmlspecialchars($sub_email) ?>">
            <input type="hidden" name="selected_variation" value="<?= htmlspecialchars($selected_var) ?>">
            <input type="hidden" name="final_amount" value="<?= htmlspecialchars($amount) ?>">

            <div class="mb-3">
                <label class="form-label"><i class="fa-solid fa-hashtag me-1"></i> Transaction ID (TrxID)</label>
                <input type="text" name="trx_id" class="form-control form-control-lg-rounded" placeholder="e.g. 9XJ2K4LQ" value="<?= htmlspecialchars($_POST['trx_id'] ?? '') ?>" required>
            </div>

            <div class="mb-4">
                <label class="form-label"><i class="fa-solid fa-phone me-1"></i> Your Number (Sender)</label>
                <input type="text" name="sender_number" class="form-control form-control-lg-rounded" placeholder="e.g. 01XXXXXXXXX" value="<?= htmlspecialchars($_POST['sender_number'] ?? '') ?>" required>
            </div>

            <button type="submit" class="jx-pay-submit">
                <i class="fa-solid fa-paper-plane me-2"></i> Submit For Verification
            </button>
        </form>

    </div>
</div>

<!-- ====== কপি ফাংশন ====== -->
<script>
function jxCopyText(text, btn) {
    navigator.clipboard.writeText(text).then(() => {
        const original = btn.innerHTML;
        btn.innerHTML = '<i class="fa-solid fa-check"></i> Copied!';
        setTimeout(() => { btn.innerHTML = original; }, 2000);
    }).catch(() => {
        if (window.JXToast) {
            window.JXToast.error('Please copy manually: ' + text, 'Copy failed');
        }
    });
}
</script>

<?php include '../footer.php'; ?>