<?php
/**
 * WHMCS-HostNekoPay Callback & Webhook Verification Handler
 * Receives callback from pay.hostneko.com and verifies transaction via /api/payment/verify
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/../config.php';

// Parse incoming request parameters (supports GET, POST, and raw JSON payload)
$rawBody = file_get_contents('php://input');
$jsonBody = !empty($rawBody) ? json_decode($rawBody, true) : [];

$invoiceId = (int)($_REQUEST['invoice'] ?? $_REQUEST['order_id'] ?? ($jsonBody['invoice'] ?? ($jsonBody['order_id'] ?? 0)));
$transactionId = trim((string)($_REQUEST['transactionId'] ?? $_REQUEST['transaction_id'] ?? $_REQUEST['trx_id'] ?? ($jsonBody['transactionId'] ?? ($jsonBody['transaction_id'] ?? ''))));
$statusParam = trim((string)($_REQUEST['status'] ?? ($jsonBody['status'] ?? '')));

$apiKey = trim((string)($_REQUEST['api'] ?? ($set['hostneko_api_key'] ?? '')));
if (empty($apiKey)) {
    $apiKey = trim($set['hostneko_api_key'] ?? '');
}

// If no order ID, return or redirect to orders page
if ($invoiceId < 1) {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        header('Content-Type: application/json');
        echo json_encode(['status' => false, 'message' => 'Missing invoice / order ID.']);
        exit();
    }
    header('Location: ../orders.php');
    exit();
}

// Fetch order
$stmt = $pdo->prepare("SELECT * FROM orders WHERE id = ? LIMIT 1");
$stmt->execute([$invoiceId]);
$order = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$order) {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        header('Content-Type: application/json');
        http_response_code(404);
        echo json_encode(['status' => false, 'message' => 'Order not found.']);
        exit();
    }
    header('Location: ../orders.php');
    exit();
}

// If order is already completed, redirect immediately or acknowledge webhook
if (strtolower($order['status']) === 'completed') {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        header('Content-Type: application/json');
        echo json_encode(['status' => true, 'message' => 'Order already verified & completed.']);
        exit();
    }
    header("Location: ../invoice.php?order_id={$invoiceId}&paid=1");
    exit();
}

// Verify transaction with HostNekoPay API if transaction ID is available
$isVerified = false;
$verifyResponse = null;

if (!empty($transactionId) && !empty($apiKey)) {
    $verifyPayload = json_encode(["transaction_id" => $transactionId]);
    $headers = [
        'Content-Type: application/json',
        'API-KEY: ' . $apiKey,
    ];

    $curl = curl_init();
    curl_setopt_array($curl, [
        CURLOPT_URL            => 'https://pay.hostneko.com/api/payment/verify',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 30,
        CURLOPT_CUSTOMREQUEST  => 'POST',
        CURLOPT_POSTFIELDS     => $verifyPayload,
        CURLOPT_HTTPHEADER     => $headers,
        CURLOPT_SSL_VERIFYPEER => false,
    ]);

    $response = curl_exec($curl);
    curl_close($curl);

    $verifyResponse = json_decode($response, true);

    if (
        is_array($verifyResponse) && 
        (
            (isset($verifyResponse['status']) && strtoupper((string)$verifyResponse['status']) === 'COMPLETED') ||
            (isset($verifyResponse['status']) && $verifyResponse['status'] === true && isset($verifyResponse['transaction_status']) && strtoupper((string)$verifyResponse['transaction_status']) === 'COMPLETED')
        )
    ) {
        $isVerified = true;
    }
}

// Process order activation if verified
if ($isVerified) {
    // 1. Update order status to Completed
    $upd = $pdo->prepare("UPDATE orders SET status = 'Completed', trx_id = ?, payment_method = 'HostNekoPay' WHERE id = ?");
    $upd->execute([$transactionId, $invoiceId]);

    // 2. Decrement product stock if stock > 0
    try {
        $pdo->prepare("UPDATE products SET stock = CASE WHEN stock > 0 THEN stock - 1 ELSE 0 END WHERE id = ?")
            ->execute([$order['product_id']]);
    } catch (Throwable $ignore) {}

    // 3. Webhook response vs Browser response
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        header('Content-Type: application/json');
        echo json_encode([
            'status'  => true,
            'message' => 'Payment verified and order activated successfully.',
            'order_id' => $invoiceId
        ]);
        exit();
    }

    header("Location: ../invoice.php?order_id={$invoiceId}&paid=1");
    exit();
}

// Fallback handling for browser redirect if status=success or cancelled
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json');
    http_response_code(400);
    echo json_encode([
        'status'  => false,
        'message' => 'Payment verification failed or invalid transaction.',
        'details' => $verifyResponse
    ]);
    exit();
}

// Customer browser return
if ($statusParam === 'cancel' || $statusParam === 'cancelled') {
    header("Location: ../invoice.php?order_id={$invoiceId}&payment=cancelled");
    exit();
}

// If customer reached return URL and verification is pending or in progress
header("Location: ../invoice.php?order_id={$invoiceId}");
exit();
