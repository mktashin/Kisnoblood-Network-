<?php
/**
 * WHMCS-HostNekoPay Automatic Payment Gateway Handler
 * Initiates payment session with https://pay.hostneko.com/api/payment/create
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/../config.php';

// Check user authentication
if (!isset($_SESSION['user_id'])) {
    $redirectUrl = '../login.php?redirect=' . urlencode($_SERVER['REQUEST_URI'] ?? '');
    header('Location: ' . $redirectUrl);
    exit();
}

// Check gateway status
$auto_enabled = !empty($set['enable_auto_payment']);
$api_key = trim($set['hostneko_api_key'] ?? '');

if (!$auto_enabled || $api_key === '') {
    die("
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset='utf-8'>
        <title>Payment Gateway Unavailable</title>
        <style>
            body { font-family: 'Inter', system-ui, sans-serif; background: #0f172a; color: #f8fafc; display: grid; place-items: center; min-height: 100vh; margin: 0; padding: 20px; }
            .box { max-width: 520px; width: 100%; background: #1e293b; border: 1px solid #334155; border-radius: 20px; padding: 32px; text-align: center; }
            h2 { color: #f59e0b; margin-top: 0; }
            p { color: #94a3b8; line-height: 1.6; }
            .btn { display: inline-block; background: #2563eb; color: #fff; padding: 12px 24px; border-radius: 12px; text-decoration: none; font-weight: 700; margin-top: 14px; }
        </style>
    </head>
    <body>
        <div class='box'>
            <h2>Auto Payment Gateway Disabled</h2>
            <p>Automatic payments are currently not enabled by the administrator. Please use Manual Payment or contact support.</p>
            <a href='../index.php' class='btn'>Return to Store</a>
        </div>
    </body>
    </html>
    ");
}

// Extract & Validate Request Parameters
$product_id   = (int)($_POST['product_id'] ?? $_GET['product_id'] ?? 0);
$sub_email    = trim($_POST['sub_email'] ?? $_GET['sub_email'] ?? '');
$selected_var = trim($_POST['selected_variation'] ?? $_GET['selected_variation'] ?? '');
$final_amount = $_POST['final_amount'] ?? $_GET['final_amount'] ?? null;

if ($product_id < 1) {
    header('Location: ../index.php');
    exit();
}

$stmt = $pdo->prepare("SELECT * FROM products WHERE id = ?");
$stmt->execute([$product_id]);
$product = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$product) {
    die("Product not found.");
}

$amount = (is_numeric($final_amount) && $final_amount > 0) ? (float)$final_amount : (float)$product['offer_price'];

// Fetch buyer details
$uStmt = $pdo->prepare("SELECT name, email, whatsapp FROM users WHERE id = ?");
$uStmt->execute([$_SESSION['user_id']]);
$customer = $uStmt->fetch(PDO::FETCH_ASSOC);

$cus_name = !empty($customer['name']) ? $customer['name'] : 'Customer';
$cus_email = !empty($customer['email']) ? $customer['email'] : 'customer@gmail.com';

// Generate order in database
$temp_trx = 'HNK-' . strtoupper(bin2hex(random_bytes(4))) . '-' . time();
$now = date('Y-m-d H:i:s');

$ins = $pdo->prepare("INSERT INTO orders (user_id, product_id, amount, status, payment_method, sub_email, sender_number, trx_id, created_at) VALUES (?, ?, ?, 'Pending', 'HostNekoPay', ?, 'Auto Gateway', ?, ?)");
$ins->execute([
    $_SESSION['user_id'],
    $product_id,
    $amount,
    $sub_email,
    $temp_trx,
    $now
]);
$order_id = (int)$pdo->lastInsertId();

// Build System & Callback URLs
$protocol = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') ? 'https://' : 'http://';
$host = $_SERVER['HTTP_HOST'];
$scriptDir = dirname($_SERVER['SCRIPT_NAME'] ?? '');
$rootDir = rtrim(dirname($scriptDir), '/\\');
$systemUrl = $protocol . $host . ($rootDir === '' || $rootDir === '/' ? '' : $rootDir);

$webhook_url = $systemUrl . '/payment/hostneko_callback.php?invoice=' . $order_id . '&api=' . urlencode($api_key);
$success_url = $systemUrl . '/payment/hostneko_callback.php?invoice=' . $order_id . '&status=success';
$cancel_url  = $systemUrl . '/invoice.php?order_id=' . $order_id . '&payment=cancelled';

// Convert amount if currency conversion is specified
$currency_rate = (float)($set['hostneko_currency_rate'] ?? 1);
$pay_amount = ($currency_rate > 0 && $currency_rate != 1) ? ($amount * $currency_rate) : $amount;

$payload = [
    "cus_name"    => $cus_name,
    "cus_email"   => $cus_email,
    "amount"      => $pay_amount,
    "webhook_url" => $webhook_url,
    "success_url" => $success_url,
    "cancel_url"  => $cancel_url,
];

$headers = [
    'Content-Type: application/json',
    'API-KEY: ' . $api_key,
];

$curl = curl_init();
curl_setopt_array($curl, [
    CURLOPT_URL            => 'https://pay.hostneko.com/api/payment/create',
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING       => '',
    CURLOPT_MAXREDIRS      => 10,
    CURLOPT_TIMEOUT        => 30,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_HTTP_VERSION   => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST  => 'POST',
    CURLOPT_POSTFIELDS     => json_encode($payload),
    CURLOPT_HTTPHEADER     => $headers,
    CURLOPT_SSL_VERIFYPEER => false,
]);

$response = curl_exec($curl);
$curl_error = curl_error($curl);
curl_close($curl);

$res = json_decode($response, true);

if (!empty($res['status']) && !empty($res['payment_url'])) {
    // Save gateway response data
    try {
        $pdo->prepare("UPDATE orders SET payment_data = ? WHERE id = ?")->execute([json_encode($res), $order_id]);
    } catch (Throwable $ignore) {}

    // Redirect user to HostNekoPay secure payment checkout
    header('Location: ' . $res['payment_url']);
    exit();
} else {
    $error_msg = $res['message'] ?? $curl_error ?? 'Unable to initiate HostNekoPay transaction.';
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Payment Gateway Error | HostNekoPay</title>
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800;900&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
        <style>
            body { font-family: 'Inter', system-ui, sans-serif; background: #0f172a; color: #f8fafc; display: grid; place-items: center; min-height: 100vh; margin: 0; padding: 20px; box-sizing: border-box; }
            .card { max-width: 540px; width: 100%; background: #1e293b; border: 1px solid #334155; border-radius: 24px; padding: 36px 28px; text-align: center; box-shadow: 0 20px 50px rgba(0,0,0,0.4); }
            .icon-wrap { width: 70px; height: 70px; border-radius: 50%; background: rgba(239, 68, 68, 0.12); border: 2px solid #ef4444; color: #f87171; display: grid; place-items: center; margin: 0 auto 20px; font-size: 2rem; }
            h2 { color: #f87171; font-size: 1.35rem; margin: 0 0 10px; font-weight: 800; }
            p { color: #94a3b8; font-size: 0.94rem; line-height: 1.6; margin: 0 0 20px; }
            .error-box { background: #090d16; color: #fca5a5; padding: 12px 16px; border-radius: 12px; font-size: 0.85rem; word-break: break-all; margin-bottom: 24px; text-align: left; font-family: monospace; border: 1px solid #7f1d1d; }
            .btn-group { display: flex; gap: 10px; justify-content: center; flex-wrap: wrap; }
            .btn { display: inline-flex; align-items: center; gap: 8px; background: #2563eb; color: #fff; padding: 12px 22px; border-radius: 12px; text-decoration: none; font-weight: 700; font-size: 0.88rem; transition: 0.2s; }
            .btn:hover { background: #1d4ed8; }
            .btn-secondary { background: #334155; color: #e2e8f0; }
            .btn-secondary:hover { background: #475569; }
        </style>
    </head>
    <body>
        <div class="card">
            <div class="icon-wrap"><i class="fas fa-triangle-exclamation"></i></div>
            <h2>HostNekoPay Gateway Error</h2>
            <p>We could not connect to the automated payment gateway. Please check the error below or try manual payment.</p>
            <div class="error-box"><?= htmlspecialchars($error_msg) ?></div>
            <div class="btn-group">
                <a href="../product.php?id=<?= $product_id ?>" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Back to Product</a>
                <?php if(!empty($set['enable_manual_payment'])): ?>
                    <a href="manual.php?product_id=<?= $product_id ?>&final_amount=<?= $amount ?>&sub_email=<?= urlencode($sub_email) ?>" class="btn"><i class="fas fa-mobile-screen"></i> Pay Manually</a>
                <?php endif; ?>
            </div>
        </div>
    </body>
    </html>
    <?php
    exit();
}
