<?php
// Shared footer settings
try {
    $stmt_set = $pdo->query("SELECT * FROM settings LIMIT 1");
    $settings = $stmt_set->fetch(PDO::FETCH_ASSOC) ?: [];
} catch (Exception $e) {
    $settings = [];
}

$settings = array_merge([
    'site_name'        => 'Digital Shop',
    'meta_desc'        => 'Premium digital subscriptions and instant delivery.',
    'whatsapp_number'  => '',
    'bkash_number'     => '',
    'nagad_number'     => '',
    'rocket_number'    => '',
    'upay_number'      => ''
], $settings);

// manual.php lives inside /payment/; all other public pages live at root.
$footer_base = (strpos($_SERVER['SCRIPT_NAME'] ?? '', '/payment/') !== false) ? '../' : '';

// Format WhatsApp URL
$wa_raw = (string)($settings['whatsapp_number'] ?? '');
$wa_clean = preg_replace('/[^0-9]/', '', $wa_raw);
if (strlen($wa_clean) === 11 && str_starts_with($wa_clean, '01')) {
    $wa_clean = '88' . $wa_clean;
}
$wa_link = !empty($wa_clean) 
    ? "https://wa.me/{$wa_clean}?text=" . urlencode("Hello! I need support on " . ($settings['site_name'] ?? 'your website')) 
    : "#";
?>

<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

<style>
    :root {
        --ft-bg: #ffffff;
        --ft-bg-subtle: #f8fafc;
        --ft-border: #e2e8f0;
        --ft-ink: #0f172a;
        --ft-muted: #64748b;
        --ft-primary: #2563eb;
        --wa-green: #25D366;
        --wa-dark: #128C7E;
    }

    .site-streamlined-footer {
        width: 100%;
        background: var(--ft-bg);
        border-top: 1px solid var(--ft-border);
        color: var(--ft-ink);
        font-family: 'Inter', system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
        margin-top: clamp(40px, 6vw, 70px);
        position: relative;
        z-index: 10;
        box-sizing: border-box;
    }

    .site-streamlined-footer *,
    .site-streamlined-footer *::before,
    .site-streamlined-footer *::after {
        box-sizing: border-box;
    }

    .footer-wrapper {
        max-width: 1180px;
        margin: 0 auto;
        padding: 24px 20px 20px;
        display: flex;
        flex-direction: column;
        gap: 18px;
    }

    /* ROW 1: PAYMENT METHODS */
    .footer-payments-row {
        display: flex;
        align-items: center;
        flex-wrap: wrap;
        gap: 12px 16px;
        padding-bottom: 14px;
        border-bottom: 1px dashed var(--ft-border);
    }

    .footer-payment-title {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        font-size: 0.82rem;
        font-weight: 800;
        color: var(--ft-ink);
        letter-spacing: 0.2px;
        white-space: nowrap;
    }

    .footer-payment-title i {
        color: var(--ft-primary);
        font-size: 0.85rem;
    }

    .footer-payment-badges {
        display: flex;
        align-items: center;
        flex-wrap: wrap;
        gap: 8px;
    }

    .pay-badge {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        padding: 5px 12px;
        border-radius: 8px;
        font-size: 0.74rem;
        font-weight: 800;
        letter-spacing: 0.2px;
        border: 1px solid transparent;
        transition: transform 0.2s ease, box-shadow 0.2s ease;
        user-select: none;
    }

    .pay-badge:hover {
        transform: translateY(-2px);
    }

    .pay-badge.bkash {
        background: #e2136e;
        color: #ffffff;
        box-shadow: 0 2px 8px rgba(226, 19, 110, 0.2);
    }
    .pay-badge.nagad {
        background: #f97316;
        color: #ffffff;
        box-shadow: 0 2px 8px rgba(249, 115, 22, 0.2);
    }
    .pay-badge.rocket {
        background: #8b5cf6;
        color: #ffffff;
        box-shadow: 0 2px 8px rgba(139, 92, 246, 0.2);
    }
    .pay-badge.binance {
        background: #0b0e11;
        color: #f3ba2f;
        border-color: #f3ba2f;
        box-shadow: 0 2px 8px rgba(243, 186, 47, 0.15);
    }
    .pay-badge.payeer {
        background: #0088cc;
        color: #ffffff;
        box-shadow: 0 2px 8px rgba(0, 136, 204, 0.2);
    }
    .pay-badge.upay {
        background: #0284c7;
        color: #ffffff;
        box-shadow: 0 2px 8px rgba(2, 132, 199, 0.2);
    }

    /* ROW 2: TRUST BADGES */
    .footer-trust-row {
        display: flex;
        align-items: center;
        flex-wrap: wrap;
        gap: 12px 24px;
        padding: 6px 0;
    }

    .trust-item {
        display: inline-flex;
        align-items: center;
        gap: 7px;
        font-size: 0.8rem;
        font-weight: 700;
        color: var(--ft-ink);
        transition: color 0.2s ease;
    }

    .trust-item i {
        font-size: 0.88rem;
    }

    .trust-item.ssl i { color: #0284c7; }
    .trust-item.instant i { color: #f59e0b; }
    .trust-item.support i { color: #2563eb; }
    .trust-item.guarantee i { color: #10b981; }
    .trust-item.verified i { color: #8b5cf6; }

    /* ROW 3: COPYRIGHT & LEGAL LINKS */
    .footer-bottom-row {
        display: flex;
        align-items: center;
        justify-content: space-between;
        flex-wrap: wrap;
        gap: 12px 20px;
        padding-top: 14px;
        border-top: 1px solid var(--ft-border);
    }

    .footer-copyright {
        margin: 0;
        font-size: 0.78rem;
        font-weight: 600;
        color: var(--ft-muted);
    }

    .footer-copyright strong {
        color: var(--ft-ink);
        font-weight: 800;
    }

    .footer-policy-links {
        display: inline-flex;
        align-items: center;
        gap: 16px;
        flex-wrap: wrap;
    }

    .footer-policy-links a {
        color: var(--ft-muted);
        font-size: 0.78rem;
        font-weight: 700;
        text-decoration: none;
        transition: color 0.2s ease;
    }

    .footer-policy-links a:hover {
        color: var(--ft-primary);
        text-decoration: underline;
    }

    /* FLOATING WHATSAPP BUTTON */
    .wa-float-btn {
        position: fixed;
        left: 24px;
        bottom: 24px;
        z-index: 1040;
        width: 52px;
        height: 52px;
        border-radius: 50%;
        background: linear-gradient(135deg, #25D366 0%, #128C7E 100%);
        color: #ffffff !important;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.6rem;
        box-shadow: 0 6px 20px rgba(37, 211, 102, 0.45);
        text-decoration: none;
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    }

    .wa-float-btn:hover {
        transform: scale(1.1) translateY(-3px);
        box-shadow: 0 10px 28px rgba(37, 211, 102, 0.6);
        color: #ffffff !important;
    }

    .wa-float-btn::before {
        content: '';
        position: absolute;
        inset: -4px;
        border-radius: 50%;
        border: 2px solid rgba(37, 211, 102, 0.6);
        animation: wa-pulse 2s infinite cubic-bezier(0.25, 0, 0, 1);
        pointer-events: none;
    }

    @keyframes wa-pulse {
        0% { transform: scale(0.95); opacity: 0.8; }
        70% { transform: scale(1.3); opacity: 0; }
        100% { transform: scale(1.3); opacity: 0; }
    }

    /* Dark Mode Compatibility */
    @media (prefers-color-scheme: dark) {
        .site-streamlined-footer {
            background: #111827;
            border-color: #334155;
            color: #f8fafc;
        }
        .footer-payment-title, .trust-item, .footer-copyright strong {
            color: #f8fafc;
        }
        .footer-payments-row, .footer-bottom-row {
            border-color: #334155;
        }
        .footer-copyright, .footer-policy-links a {
            color: #94a3b8;
        }
        .footer-policy-links a:hover {
            color: #60a5fa;
        }
    }

    /* Mobile Adaptations */
    @media (max-width: 991px) {
        .site-streamlined-footer {
            margin-bottom: 74px; /* Space above fixed bottom navbar */
        }
        .wa-float-btn {
            bottom: 84px; /* Float above mobile bottom bar */
            left: 18px;
            width: 48px;
            height: 48px;
            font-size: 1.45rem;
        }
    }

    @media (max-width: 640px) {
        .footer-wrapper {
            padding: 18px 16px 16px;
            gap: 14px;
        }
        .footer-payments-row,
        .footer-trust-row,
        .footer-bottom-row {
            gap: 10px 14px;
        }
        .footer-bottom-row {
            flex-direction: column;
            align-items: flex-start;
        }
        .trust-item {
            font-size: 0.74rem;
        }
        .footer-policy-links {
            gap: 12px;
        }
    }
</style>

<footer class="site-streamlined-footer">
    <div class="footer-wrapper">
        
        <!-- ROW 1: PAYMENT METHOD BADGES -->
        <div class="footer-payments-row">
            <span class="footer-payment-title">
                <i class="fa-solid fa-lock"></i> Secure Payments:
            </span>
            <div class="footer-payment-badges">
                <span class="pay-badge bkash"><i class="fa-solid fa-money-bill-wave me-1"></i> bKash</span>
                <span class="pay-badge nagad"><i class="fa-solid fa-wallet me-1"></i> Nagad</span>
                <span class="pay-badge rocket"><i class="fa-solid fa-bolt me-1"></i> Rocket</span>
                <span class="pay-badge binance"><i class="fa-solid fa-coins me-1"></i> Binance</span>
                <span class="pay-badge payeer"><i class="fa-solid fa-credit-card me-1"></i> Payeer</span>
                <?php if (!empty($settings['upay_number'])): ?>
                    <span class="pay-badge upay"><i class="fa-solid fa-mobile-screen me-1"></i> Upay</span>
                <?php endif; ?>
            </div>
        </div>

        <!-- ROW 2: TRUST BADGES -->
        <div class="footer-trust-row">
            <div class="trust-item ssl">
                <i class="fa-solid fa-shield-halved"></i>
                <span>SSL Secured</span>
            </div>
            <div class="trust-item instant">
                <i class="fa-solid fa-bolt"></i>
                <span>Instant Delivery</span>
            </div>
            <div class="trust-item support">
                <i class="fa-solid fa-headset"></i>
                <span>24/7 Support</span>
            </div>
            <div class="trust-item guarantee">
                <i class="fa-solid fa-rotate-left"></i>
                <span>Money-Back Guarantee</span>
            </div>
            <div class="trust-item verified">
                <i class="fa-solid fa-circle-check"></i>
                <span>Verified Products</span>
            </div>
        </div>

        <!-- ROW 3: COPYRIGHT & LEGAL POLICY LINKS -->
        <div class="footer-bottom-row">
            <p class="footer-copyright">
                &copy; <?= date('Y') ?> <strong><?= htmlspecialchars($settings['site_name'] ?? 'Digital Shop') ?></strong> — All Rights Reserved
            </p>
            <nav class="footer-policy-links" aria-label="Legal policies">
                <a href="<?= $footer_base ?>privacy-policy.php">Privacy Policy</a>
                <a href="<?= $footer_base ?>terms-of-service.php">Terms of Service</a>
                <a href="<?= $footer_base ?>refund-policy.php">Refund Policy</a>
            </nav>
        </div>

    </div>
</footer>

<!-- FLOATING WHATSAPP SUPPORT BUTTON -->
<a href="<?= htmlspecialchars($wa_link) ?>" 
   target="_blank" 
   rel="noopener noreferrer" 
   class="wa-float-btn" 
   aria-label="WhatsApp Support" 
   title="Chat on WhatsApp">
    <i class="fa-brands fa-whatsapp"></i>
</a>
