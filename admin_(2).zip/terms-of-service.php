<?php
$_GET['slug'] = 'terms-of-service';
include __DIR__ . '/page.php';
