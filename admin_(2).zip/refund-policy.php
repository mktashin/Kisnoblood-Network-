<?php
$_GET['slug'] = 'refund-policy';
include __DIR__ . '/page.php';
