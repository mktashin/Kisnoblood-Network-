<?php
$_GET['slug'] = 'privacy-policy';
include __DIR__ . '/page.php';
