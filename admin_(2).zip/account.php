<?php 
// সেশন শুরু করা নিশ্চিত করা হলো (যদি config.php তে অলরেডি করা না থাকে)
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include 'config.php'; 

// ইউজার লগইন না থাকলে সরাসরি login.php তে রিডাইরেক্ট করবে
if (!isset($_SESSION['user_id'])) { 
    header("Location: login.php"); 
    exit(); 
}

include 'header.php';

$user = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$user->execute([$_SESSION['user_id']]);
$u = $user->fetch();

$total_purchased = $pdo->prepare("SELECT COUNT(*) FROM orders WHERE user_id = ? AND status = 'Completed'");
$total_purchased->execute([$_SESSION['user_id']]);
$count = $total_purchased->fetchColumn();
?>

<!-- ====== ফন্ট: Inter ====== -->
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>

<style>
    /* =========================================
       ✅ PROFILE PAGE UPDATED: 11 August 2026
       📌 Exact Match with Previous Blue Theme
       🔧 কালার পরিবর্তন: সবুজ → নীল (#1e2ab8)
    ========================================= */
    
    :root {
        --primary-blue: #1e2ab8;
        --primary-gradient: linear-gradient(135deg, #1e2ab8 0%, #4338ca 100%);
        --primary-hover: #0f172a;
        --primary-light: #e0e7ff;
        --border-color: #e2e8f0;
        --dark-bg: #0f172a;
        --text-slate: #64748b;
        --light-bg: #f8fafc;
        --card-bg: #ffffff;
        --success-green: #059669;
    }

    /* ডার্ক মোড অটো */
    @media (prefers-color-scheme: dark) {
        :root {
            --card-bg: #1e293b;
            --light-bg: #0f172a;
            --dark-bg: #e2e8f0;
            --text-slate: #94a3b8;
            --border-color: #334155;
        }
        body { background-color: #0f172a; }
        .profile-card { background: #1e293b; border-color: #334155; }
        .profile-header { background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%); border-bottom-color: #334155; }
        .profile-name { color: #e2e8f0; }
        .profile-meta { color: #94a3b8; }
        .stats-box { background: #1e293b; border-color: #334155; }
        .stats-count { color: #60a5fa; }
        .stats-label { color: #94a3b8; }
        .menu-item { background: #1e293b; border-color: #334155; color: #e2e8f0; }
        .menu-item i { background: #0f172a; border-color: #334155; }
        .menu-item:hover { background: #0f172a; border-color: #60a5fa; color: #60a5fa; }
        .logout-item { color: #f87171; background: #1e293b; border-color: #7f1d1d; }
        .logout-item i { color: #f87171; background: #0f172a; border-color: #7f1d1d; }
        .logout-item:hover { background: #dc2626; border-color: #dc2626; color: #fff !important; }
        .avatar-img { border-color: #60a5fa; }
    }

    * { font-style: normal !important; }

    body {
        font-family: 'Inter', sans-serif;
        background-color: var(--light-bg);
        color: var(--dark-bg);
    }

    /* ====== প্রোফাইল কন্টেইনার ====== */
    .profile-container {
        max-width: 480px;
        margin: 15px auto 40px;
        padding: 0 12px;
    }
    @media(min-width: 576px) {
        .profile-container { margin: 30px auto 50px; padding: 0 15px; }
    }

    /* ====== প্রোফাইল কার্ড ====== */
    .profile-card {
        background: var(--card-bg);
        border-radius: 24px;
        border: 1px solid var(--border-color);
        box-shadow: 0 10px 30px rgba(30, 42, 184, 0.04);
        overflow: hidden;
        position: relative;
    }

    /* ====== হেডার ====== */
    .profile-header {
        background: linear-gradient(135deg, var(--card-bg) 0%, var(--primary-light) 100%);
        padding: 35px 15px 50px;
        text-align: center;
        color: var(--dark-bg);
        border-bottom: 1px solid var(--border-color);
    }
    @media(min-width: 576px) {
        .profile-header { padding: 45px 20px 60px; }
    }

    /* ====== অ্যাভাটার ====== */
    .avatar-wrapper {
        position: relative;
        display: inline-block;
        margin-bottom: 14px;
    }

    .avatar-img {
        width: 85px;
        height: 85px;
        border-radius: 50%;
        border: 3px solid var(--primary-blue);
        padding: 4px;
        background: var(--card-bg);
        object-fit: cover;
        box-shadow: 0 4px 15px rgba(30, 42, 184, 0.15);
    }
    @media(min-width: 576px) {
        .avatar-img { width: 95px; height: 95px; }
    }

    /* ====== নাম ====== */
    .profile-name {
        font-weight: 900;
        font-size: 1.4rem;
        margin-bottom: 6px;
        color: var(--dark-bg);
        letter-spacing: -0.3px;
        text-transform: uppercase;
    }

    /* ====== মেটা ====== */
    .profile-meta {
        font-size: 0.85rem;
        color: var(--text-slate);
        line-height: 1.8;
        font-weight: 500;
    }
    
    .profile-meta i {
        color: var(--primary-blue);
        width: 18px;
    }

    /* ====== স্ট্যাটস বক্স ====== */
    .stats-box {
        background: var(--card-bg);
        margin: -30px 20px 20px;
        padding: 15px;
        border-radius: 16px;
        box-shadow: 0 8px 25px rgba(30, 42, 184, 0.06);
        text-align: center;
        border: 1px solid var(--border-color);
        position: relative;
        z-index: 2;
    }
    @media(min-width: 576px) {
        .stats-box { margin: -35px 30px 25px; padding: 18px; }
    }

    .stats-count {
        font-size: 1.75rem;
        font-weight: 900;
        color: var(--primary-blue);
        line-height: 1;
        margin-bottom: 4px;
    }

    .stats-label {
        font-size: 0.7rem;
        text-transform: uppercase;
        letter-spacing: 0.8px;
        color: var(--text-slate);
        font-weight: 700;
    }

    /* ====== মেনু আইটেম ====== */
    .menu-list {
        padding: 5px 15px 25px;
    }
    @media(min-width: 576px) {
        .menu-list { padding: 5px 25px 30px; }
    }

    .menu-item {
        display: flex;
        align-items: center;
        padding: 13px 16px;
        margin-bottom: 10px;
        border-radius: 12px;
        text-decoration: none !important;
        color: var(--dark-bg);
        font-size: 0.85rem;
        font-weight: 700;
        transition: all 0.25s ease;
        background: var(--card-bg);
        border: 1px solid var(--border-color);
        text-transform: uppercase;
        letter-spacing: 0.3px;
    }

    .menu-item i {
        width: 34px;
        height: 34px;
        display: flex;
        align-items: center;
        justify-content: center;
        background: var(--light-bg);
        border-radius: 8px;
        margin-right: 12px;
        font-size: 0.95rem;
        border: 1px solid var(--border-color);
        transition: all 0.25s ease;
        flex-shrink: 0;
    }

    /* ====== সোশ্যাল আইকন কালার ====== */
    .menu-item .fa-youtube { color: #ff0000; }
    .menu-item .fa-facebook { color: #1877f2; }
    .menu-item .fa-telegram, .menu-item .fa-telegram-plane { color: #0088cc; }
    .menu-item .fa-comment-dots { color: var(--primary-blue); }

    /* ====== মেনু হোভার ====== */
    .menu-item:hover {
        background: var(--primary-light);
        border-color: var(--primary-blue);
        color: var(--primary-blue);
        transform: translateX(4px);
        box-shadow: 0 4px 15px rgba(30, 42, 184, 0.08);
    }
    
    .menu-item:hover i {
        background: var(--card-bg);
        border-color: var(--primary-blue);
    }

    /* ====== লগআউট বাটন ====== */
    .logout-item {
        color: #ef4444;
        background: #fef2f2;
        border-color: #fee2e2;
        margin-top: 15px;
    }
    
    .logout-item i {
        color: #ef4444;
        background: var(--card-bg);
        border-color: #fca5a5;
    }

    .logout-item:hover {
        background: #ef4444;
        border-color: #ef4444;
        color: #fff !important;
        transform: translateX(4px);
        box-shadow: 0 4px 15px rgba(239, 68, 68, 0.15);
    }
    .logout-item:hover i {
        background: rgba(255,255,255,0.15);
        color: #fff;
        border-color: transparent;
    }

    /* ====== রেসপনসিভ ====== */
    @media (max-width: 480px) {
        .profile-container { margin: 10px auto 30px; padding: 0 10px; }
        .profile-header { padding: 25px 12px 40px; }
        .avatar-img { width: 70px; height: 70px; }
        .profile-name { font-size: 1.1rem; }
        .profile-meta { font-size: 0.75rem; }
        .stats-box { margin: -25px 12px 15px; padding: 12px; }
        .stats-count { font-size: 1.4rem; }
        .menu-item { font-size: 0.75rem; padding: 11px 14px; }
        .menu-item i { width: 30px; height: 30px; font-size: 0.8rem; margin-right: 10px; }
        .menu-list { padding: 5px 12px 18px; }
    }
</style>

<div class="profile-container animate__animated animate__fadeIn">
    <div class="profile-card">
        
        <!-- ====== হেডার ====== -->
        <div class="profile-header">
            <div class="avatar-wrapper">
                <img src="https://ui-avatars.com/api/?name=<?= urlencode($u['name'] ?? 'User') ?>&background=1e2ab8&color=fff&size=128" class="avatar-img" alt="Avatar">
            </div>
            <div class="profile-name"><?= htmlspecialchars($u['name'] ?? '') ?></div>
            <div class="profile-meta">
                <div><i class="fa-solid fa-envelope"></i> <?= htmlspecialchars($u['email'] ?? '') ?></div>
                <?php if(!empty($u['whatsapp'])): ?>
                    <div class="mt-1"><i class="fa-brands fa-whatsapp"></i> <?= htmlspecialchars($u['whatsapp']) ?></div>
                <?php endif; ?>
            </div>
        </div>

        <!-- ====== স্ট্যাটস ====== -->
        <div class="stats-box">
            <div class="stats-count"><?= intval($count) ?></div>
            <div class="stats-label">Total Purchased Items</div>
        </div>

        <!-- ====== মেনু লিস্ট ====== -->
        <div class="menu-list">
            <?php if(!empty($set['yt_link'])): ?>
                <a href="<?= htmlspecialchars($set['yt_link']) ?>" target="_blank" class="menu-item">
                    <i class="fa-brands fa-youtube"></i> YouTube Channel
                </a>
            <?php endif; ?>
            
            <?php if(!empty($set['fb_link'])): ?>
                <a href="<?= htmlspecialchars($set['fb_link']) ?>" target="_blank" class="menu-item">
                    <i class="fa-brands fa-facebook"></i> Facebook Page
                </a>
            <?php endif; ?>
            
            <?php if(!empty($set['whatsapp_number'])): 
                $wa_raw_acc = (string)($set['whatsapp_number'] ?? '');
                $wa_clean_acc = preg_replace('/[^0-9]/', '', $wa_raw_acc);
                if (strlen($wa_clean_acc) === 11 && str_starts_with($wa_clean_acc, '01')) {
                    $wa_clean_acc = '88' . $wa_clean_acc;
                }
            ?>
                <a href="https://wa.me/<?= $wa_clean_acc ?>?text=<?= urlencode('Hello, I need support!') ?>" target="_blank" class="menu-item" style="color:#10b981;">
                    <i class="fa-brands fa-whatsapp" style="color:#10b981; font-size:1.1rem;"></i> WhatsApp Support
                </a>
            <?php endif; ?>
            
            <a href="logout.php" class="menu-item logout-item">
                <i class="fa-solid fa-right-from-bracket"></i> Logout Account
            </a>
        </div>
        
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<?php include 'footer.php'; ?>