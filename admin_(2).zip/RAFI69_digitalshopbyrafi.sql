-- phpMyAdmin SQL Dump
-- version 5.2.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Sep 15, 2026 at 05:46 PM
-- Server version: 10.11.18-MariaDB-cll-lve
-- PHP Version: 8.4.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dreampan_digitalshopbyrafi`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`) VALUES
(1, 'Premium Subscriptions'),
(2, 'php-script');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `status` enum('Pending','Processing','Completed','Rejected') NOT NULL DEFAULT 'Pending',
  `payment_method` varchar(50) NOT NULL DEFAULT 'Manual',
  `sub_email` varchar(190) DEFAULT NULL,
  `sender_number` varchar(30) DEFAULT NULL,
  `trx_id` varchar(100) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `payment_data` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `product_id`, `amount`, `status`, `payment_method`, `sub_email`, `sender_number`, `trx_id`, `created_at`, `payment_data`) VALUES
(1, 1, 6, 6000.00, 'Completed', 'Manual', '', '01312121212', 'Testbydevrafi', '2026-09-11 09:02:54', NULL),
(2, 1, 6, 6000.00, 'Completed', 'Manual', '', 'Rueu', 'M94348', '2026-09-11 09:20:23', NULL),
(3, 2, 6, 6000.00, 'Completed', 'Manual', '', '94348', '94348', '2026-09-11 09:22:35', NULL),
(4, 1, 7, 96.00, 'Completed', 'Manual', '', '88', 'M94349', '2026-09-11 09:37:03', NULL),
(5, 1, 6, 6000.00, 'Completed', 'Manual', '', '01613131313', 'hujjhhj', '2026-09-11 09:57:51', NULL),
(6, 1, 6, 6000.00, 'Completed', 'Manual', '', '943487', 'M943498', '2026-09-11 10:05:33', NULL),
(7, 2, 8, 96.00, 'Pending', 'Manual', '', '943486', '943487', '2026-09-11 14:56:51', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `product_type` enum('downloadable','subscription') NOT NULL,
  `regular_price` decimal(10,2) NOT NULL,
  `offer_price` decimal(10,2) NOT NULL,
  `stock` int(11) NOT NULL DEFAULT 1,
  `drive_link` text DEFAULT NULL,
  `file_path` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `variations` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `category_id`, `title`, `description`, `product_type`, `regular_price`, `offer_price`, `stock`, `drive_link`, `file_path`, `image`, `variations`) VALUES
(6, 2, 'Php top up script', 'Best topup', 'downloadable', 10000.00, 6000.00, 100, '', 'private_downloads/1789120622_file_admin.zip', 'uploads/1789117312_img_9104.jpg', 'Lifetime license Free'),
(7, 1, 'Hh', '', 'downloadable', 99.00, 96.00, 1000, 'https://drive.google.com/file/d/1in1ZmXU-lROE93YYMT5SwlshK44TWR20/view?usp=drivesdk', 'private_downloads/1789119358_file_SMM.zip', 'uploads/1789119358_img_63157.png', ''),
(8, 1, 'Hh', '', 'downloadable', 99.00, 96.00, 1000, 'https://drive.google.com/file/d/1in1ZmXU-lROE93YYMT5SwlshK44TWR20/view?usp=drivesdk', 'private_downloads/1789121151_file_SMM.zip', 'uploads/1789121151_img_63157.png', '');

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` int(11) NOT NULL DEFAULT 1,
  `site_name` varchar(100) NOT NULL DEFAULT 'Digital Shop',
  `site_tagline` varchar(255) DEFAULT 'Premium Digital Subscriptions & Downloads',
  `logo` varchar(255) DEFAULT 'uploads/jhx_digital_shop_logo_v2.svg',
  `favicon` varchar(255) DEFAULT '',
  `yt_link` varchar(255) DEFAULT '#',
  `fb_link` varchar(255) DEFAULT '#',
  `tg_link` varchar(255) DEFAULT '',
  `tg_user` varchar(100) DEFAULT '',
  `whatsapp_number` varchar(30) DEFAULT NULL,
  `site_status` tinyint(1) NOT NULL DEFAULT 1,
  `auto_approve_orders` tinyint(1) NOT NULL DEFAULT 0,
  `currency_symbol` varchar(10) NOT NULL DEFAULT '৳',
  `meta_title` text DEFAULT NULL,
  `meta_desc` text DEFAULT NULL,
  `meta_keys` text DEFAULT NULL,
  `bkash_number` varchar(30) DEFAULT NULL,
  `nagad_number` varchar(30) DEFAULT NULL,
  `rocket_number` varchar(30) DEFAULT NULL,
  `upay_number` varchar(30) DEFAULT NULL,
  `manual_payment_type` varchar(20) DEFAULT 'Personal',
  `manual_payment_note` text DEFAULT NULL,
  `enable_manual_payment` int(11) NOT NULL DEFAULT 1,
  `enable_auto_payment` int(11) NOT NULL DEFAULT 0,
  `hostneko_api_key` varchar(255) DEFAULT '',
  `hostneko_currency_rate` varchar(20) DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `site_name`, `site_tagline`, `logo`, `favicon`, `yt_link`, `fb_link`, `tg_link`, `tg_user`, `whatsapp_number`, `site_status`, `auto_approve_orders`, `currency_symbol`, `meta_title`, `meta_desc`, `meta_keys`, `bkash_number`, `nagad_number`, `rocket_number`, `upay_number`, `manual_payment_type`, `manual_payment_note`, `enable_manual_payment`, `enable_auto_payment`, `hostneko_api_key`, `hostneko_currency_rate`) VALUES
(1, 'Digital Shop', 'Premium Digital Subscriptions & Downloads', 'uploads/logo_1789121313.png', '', '#', '#', '', '', '01965813958', 1, 1, '৳', 'Digital Shop | Premium Digital Subscriptions', 'Buy premium digital subscriptions and downloadable products with fast delivery.', '', '01965813958', '01965813958', '', '01965813958', 'Personal', '', 1, 0, '', '1');

-- --------------------------------------------------------

--
-- Table structure for table `sliders`
--

CREATE TABLE `sliders` (
  `id` int(11) NOT NULL,
  `image` varchar(255) NOT NULL,
  `link` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sliders`
--

INSERT INTO `sliders` (`id`, `image`, `link`, `created_at`) VALUES
(1, 'uploads/sliders/jhx_digital_shop_slider_v2.svg', 'index.php', '2026-09-11 08:51:33');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `whatsapp` varchar(20) NOT NULL,
  `email` varchar(190) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('user','admin') NOT NULL DEFAULT 'user',
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `whatsapp`, `email`, `password`, `role`, `created_at`) VALUES
(1, 'Site Administrator', '', 'mktashin2@gmail.com', '$2y$12$Sza0jNkBLcUjCUUtLh4plen1hVVQFrYdpxjo7fnTHygI1mGH/9ti6', 'admin', '2026-09-11 08:51:33'),
(2, 'MR TASHIN', '+8801965813958', 'mrtashin09@gmail.com', '$2y$10$IJBFmKDPgGb3jVHaPNLfr.8i51PwZ4C.0/Ys/zLzvxCZFqF1gSxfq', 'user', '2026-09-11 09:22:14');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_orders_trx_id` (`trx_id`),
  ADD KEY `idx_orders_user` (`user_id`),
  ADD KEY `idx_orders_product` (`product_id`),
  ADD KEY `idx_orders_status` (`status`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_products_category` (`category_id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sliders`
--
ALTER TABLE `sliders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_users_email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `sliders`
--
ALTER TABLE `sliders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `fk_orders_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_orders_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `fk_products_category` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
