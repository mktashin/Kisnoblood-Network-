/* JX Toast Notifications */
(function (window, document) {
    'use strict';

    var icons = {
        success: 'fa-circle-check',
        error: 'fa-circle-exclamation',
        warning: 'fa-triangle-exclamation',
        info: 'fa-circle-info'
    };
    var titles = { success: 'Success', error: 'Something went wrong', warning: 'Please check', info: 'Information' };

    function getContainer() {
        var container = document.querySelector('.jx-toast-container');
        if (!container) {
            container = document.createElement('div');
            container.className = 'jx-toast-container';
            container.setAttribute('aria-live', 'polite');
            container.setAttribute('aria-atomic', 'true');
            document.body.appendChild(container);
        }
        return container;
    }

    function closeToast(toast) {
        if (!toast || toast.classList.contains('is-leaving')) return;
        toast.classList.add('is-leaving');
        window.setTimeout(function () { if (toast.parentNode) toast.parentNode.removeChild(toast); }, 260);
    }

    function show(message, type, title, duration) {
        type = icons[type] ? type : 'info';
        duration = typeof duration === 'number' ? duration : 4800;
        var text = String(message || '').trim();
        if (!text) return null;

        var toast = document.createElement('div');
        toast.className = 'jx-toast jx-toast-' + type;
        toast.setAttribute('role', type === 'error' ? 'alert' : 'status');

        var icon = document.createElement('div');
        icon.className = 'jx-toast-icon';
        icon.innerHTML = '<i class="fa-solid ' + icons[type] + '" aria-hidden="true"></i>';

        var content = document.createElement('div');
        content.className = 'jx-toast-content';
        var heading = document.createElement('p');
        heading.className = 'jx-toast-title';
        heading.textContent = title || titles[type];
        var body = document.createElement('p');
        body.className = 'jx-toast-message';
        body.textContent = text;
        content.appendChild(heading);
        content.appendChild(body);

        var close = document.createElement('button');
        close.className = 'jx-toast-close';
        close.type = 'button';
        close.setAttribute('aria-label', 'Close notification');
        close.innerHTML = '<i class="fa-solid fa-xmark" aria-hidden="true"></i>';
        close.addEventListener('click', function () { closeToast(toast); });

        var progress = document.createElement('div');
        progress.className = 'jx-toast-progress';
        progress.style.setProperty('--jx-toast-duration', duration + 'ms');

        toast.appendChild(icon);
        toast.appendChild(content);
        toast.appendChild(close);
        toast.appendChild(progress);
        getContainer().appendChild(toast);

        var timer = window.setTimeout(function () { closeToast(toast); }, duration);
        toast.addEventListener('mouseenter', function () { window.clearTimeout(timer); progress.style.animationPlayState = 'paused'; });
        toast.addEventListener('mouseleave', function () { progress.style.animationPlayState = 'running'; timer = window.setTimeout(function () { closeToast(toast); }, 1400); });
        return toast;
    }

    window.JXToast = {
        show: show,
        success: function (message, title, duration) { return show(message, 'success', title, duration); },
        error: function (message, title, duration) { return show(message, 'error', title, duration); },
        warning: function (message, title, duration) { return show(message, 'warning', title, duration); },
        info: function (message, title, duration) { return show(message, 'info', title, duration); }
    };

    function convertLegacyMessages() {
        var selectors = ['.alert-success', '.alert-success-custom', '.alert-danger', '.alert-warning', '.alert-info', '.alert-jx-error'];
        var nodes = document.querySelectorAll(selectors.join(','));
        Array.prototype.forEach.call(nodes, function (node) {
            if (node.closest('.jx-toast') || node.getAttribute('data-jx-toast-processed') === '1') return;
            node.setAttribute('data-jx-toast-processed', '1');
            var explicitType = node.getAttribute('data-jx-toast-type');
            var type = explicitType && icons[explicitType] ? explicitType :
                (node.classList.contains('alert-danger') || node.classList.contains('alert-jx-error') ? 'error' :
                node.classList.contains('alert-warning') ? 'warning' : node.classList.contains('alert-info') ? 'info' : 'success');
            var text = node.textContent.replace(/\s+/g, ' ').trim();
            node.remove();
            show(text, type);
        });
    }

    document.addEventListener('DOMContentLoaded', convertLegacyMessages);
    window.setTimeout(convertLegacyMessages, 30);
})(window, document);
