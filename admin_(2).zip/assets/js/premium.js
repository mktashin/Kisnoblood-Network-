/* ==========================================================================
   PREMIUM THEME LAYER — JHXPRO SHOP (JS)
   Additive only. Safe to include on every page via footer.php
   ========================================================================== */

document.addEventListener('DOMContentLoaded', function () {

    /* ---------- 1. Preloader ---------- */
    var pre = document.getElementById('jx-preloader');
    if (pre) {
        window.addEventListener('load', function () {
            setTimeout(function () { pre.classList.add('jx-hide'); }, 250);
        });
        // Fallback in case 'load' already fired
        setTimeout(function () { pre.classList.add('jx-hide'); }, 1800);
    }

    /* ---------- 2. Ambient gradient blobs (inject once) ---------- */
    if (!document.querySelector('.jx-blob-wrap')) {
        var wrap = document.createElement('div');
        wrap.className = 'jx-blob-wrap';
        wrap.innerHTML = '<div class="jx-blob b1"></div><div class="jx-blob b2"></div><div class="jx-blob b3"></div>';
        document.body.prepend(wrap);
    }

    /* ---------- 3. Scroll reveal using IntersectionObserver ---------- */
    var revealTargets = document.querySelectorAll(
        '.product-card, .order-card, .category-section-header, #hero, .product-details-card, .jx-pay-method-card, .settings-card'
    );
    revealTargets.forEach(function (el) { el.classList.add('jx-pop'); });

    if ('IntersectionObserver' in window) {
        var io = new IntersectionObserver(function (entries) {
            entries.forEach(function (entry) {
                if (entry.isIntersecting) {
                    entry.target.classList.add('jx-in');
                    io.unobserve(entry.target);
                }
            });
        }, { threshold: 0.08 });
        revealTargets.forEach(function (el) { io.observe(el); });
    } else {
        revealTargets.forEach(function (el) { el.classList.add('jx-in'); });
    }

    /* ---------- 4. Ripple effect on all primary buttons ---------- */
    var rippleSelectors = '.btn-buy-now, .btn-buy, .btn-download, .btn-login-top, .jx-pay-submit, .btn-update, .jx-pay-method-card, .btn-login, .btn-signup, .btn-action-green';
    document.addEventListener('click', function (e) {
        var btn = e.target.closest(rippleSelectors);
        if (!btn) return;
        btn.classList.add('jx-ripple');
        var circle = document.createElement('span');
        var size = Math.max(btn.clientWidth, btn.clientHeight);
        var rect = btn.getBoundingClientRect();
        circle.className = 'jx-ripple-circle';
        circle.style.width = circle.style.height = size + 'px';
        circle.style.left = (e.clientX - rect.left - size / 2) + 'px';
        circle.style.top = (e.clientY - rect.top - size / 2) + 'px';
        btn.appendChild(circle);
        setTimeout(function () { circle.remove(); }, 650);
    });

});

/* ---------- 5. Toast notification helper ---------- */
function jxToast(message, type) {
    var wrap = document.getElementById('jx-toast-wrap');
    if (!wrap) {
        wrap = document.createElement('div');
        wrap.id = 'jx-toast-wrap';
        document.body.appendChild(wrap);
    }
    var icon = type === 'error' ? 'fa-circle-xmark' : (type === 'warn' ? 'fa-triangle-exclamation' : 'fa-circle-check');
    var t = document.createElement('div');
    t.className = 'jx-toast';
    t.innerHTML = '<i class="fa-solid ' + icon + '"></i><span>' + message + '</span>';
    wrap.appendChild(t);
    setTimeout(function () {
        t.classList.add('jx-out');
        setTimeout(function () { t.remove(); }, 350);
    }, 3200);
}

/* ---------- 6. Copy to clipboard helper (used in manual payment page) ---------- */
function jxCopyText(text, btnEl) {
    navigator.clipboard.writeText(text).then(function () {
        if (btnEl) {
            var original = btnEl.innerHTML;
            btnEl.innerHTML = '<i class="fa-solid fa-check"></i> Copied';
            btnEl.classList.add('jx-copied');
            setTimeout(function () {
                btnEl.innerHTML = original;
                btnEl.classList.remove('jx-copied');
            }, 1500);
        }
        jxToast('Number copied to clipboard!', 'success');
    }).catch(function () {
        jxToast('Could not copy. Please copy manually.', 'warn');
    });
}

/* ---------- 7. Lightweight confetti burst (no external library needed) ---------- */
function jxConfetti() {
    var canvas = document.getElementById('jx-confetti-canvas');
    if (!canvas) {
        canvas = document.createElement('canvas');
        canvas.id = 'jx-confetti-canvas';
        document.body.appendChild(canvas);
    }
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
    var ctx = canvas.getContext('2d');
    var colors = ['#10b981', '#34d399', '#f59e0b', '#fbbf24', '#059669'];
    var pieces = [];
    for (var i = 0; i < 120; i++) {
        pieces.push({
            x: Math.random() * canvas.width,
            y: -20 - Math.random() * canvas.height * 0.5,
            w: 6 + Math.random() * 6,
            h: 8 + Math.random() * 8,
            color: colors[Math.floor(Math.random() * colors.length)],
            speed: 2 + Math.random() * 3,
            drift: -1 + Math.random() * 2,
            rot: Math.random() * 360,
            rotSpeed: -6 + Math.random() * 12
        });
    }
    var start = Date.now();
    function frame() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        var elapsed = Date.now() - start;
        pieces.forEach(function (p) {
            p.y += p.speed;
            p.x += p.drift;
            p.rot += p.rotSpeed;
            ctx.save();
            ctx.translate(p.x, p.y);
            ctx.rotate(p.rot * Math.PI / 180);
            ctx.fillStyle = p.color;
            ctx.fillRect(-p.w / 2, -p.h / 2, p.w, p.h);
            ctx.restore();
        });
        if (elapsed < 3200) {
            requestAnimationFrame(frame);
        } else {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
        }
    }
    requestAnimationFrame(frame);
}

