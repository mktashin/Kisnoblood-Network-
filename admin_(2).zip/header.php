<?php
if(!isset($set)) {
    include 'config.php';
}
// Determine relative base path
$asset_base = '';
if (preg_match('#/(payment|admin)/#', $_SERVER['PHP_SELF'])) {
    $asset_base = '../';
}
$wa_raw_hdr = (string)($set['whatsapp_number'] ?? '');
$wa_clean_hdr = preg_replace('/[^0-9]/', '', $wa_raw_hdr);
if (strlen($wa_clean_hdr) === 11 && str_starts_with($wa_clean_hdr, '01')) {
    $wa_clean_hdr = '88' . $wa_clean_hdr;
}
$wa_url = !empty($wa_clean_hdr) ? "https://wa.me/" . $wa_clean_hdr : '#';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0">
    
    <?php if(!empty($set['favicon'])): ?>
        <link rel="icon" href="<?php echo (str_starts_with($set['favicon'], 'http') ? $set['favicon'] : $asset_base . $set['favicon']); ?>">
    <?php endif; ?>

    <title><?php echo $set['meta_title'] ?? ($set['site_name'] ?? 'Digital Shop'); ?></title>
    <meta name="description" content="<?php echo $set['meta_desc'] ?? 'Premium Digital Subscriptions & Instant Delivery'; ?>">
    <meta name="keywords" content="<?php echo $set['meta_keys'] ?? 'digital subscriptions, online shop, digital assets'; ?>">

    <!-- Google Fonts: Outfit & Inter -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&family=Outfit:wght@500;600;700;800;900&display=swap" rel="stylesheet">
    
    <!-- Bootstrap & FontAwesome & Animate -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>
    <link rel="stylesheet" href="<?php echo $asset_base; ?>assets/css/premium-theme.css"/>
    <link rel="stylesheet" href="<?php echo $asset_base; ?>assets/css/jx-toast.css"/>

    <style>
        :root {
            --primary-blue: #2563eb;
            --primary-dark: #1d4ed8;
            --primary-light: #60a5fa;
            --primary-gradient: linear-gradient(135deg, #2563eb 0%, #3b82f6 100%);
            --primary-gradient-hover: linear-gradient(135deg, #1d4ed8 0%, #2563eb 100%);
            --accent-cyan: #06b6d4;
            --accent-gold: #f59e0b;
            --accent-green: #10b981;
            
            --bg-body: #f8fafc;
            --bg-card: #ffffff;
            --bg-card-subtle: #f1f5f9;
            --text-dark: #0f172a;
            --text-muted: #64748b;
            --border-color: #e2e8f0;
            --glass-bg: rgba(255, 255, 255, 0.88);
            --glass-border: rgba(255, 255, 255, 0.5);
            --shadow-sm: 0 2px 8px rgba(15, 23, 42, 0.04);
            --shadow-md: 0 8px 24px rgba(37, 99, 235, 0.08);
            --shadow-lg: 0 16px 40px rgba(15, 23, 42, 0.09);
            --radius: 16px;
            --radius-sm: 10px;
            --transition: all 0.28s cubic-bezier(0.4, 0, 0.2, 1);
        }

        /* Dark Mode Theme */
        @media (prefers-color-scheme: dark) {
            :root {
                --bg-body: #0b0f19;
                --bg-card: #131b2e;
                --bg-card-subtle: #1a243b;
                --text-dark: #f1f5f9;
                --text-muted: #94a3b8;
                --border-color: #24324f;
                --glass-bg: rgba(19, 27, 46, 0.92);
                --glass-border: rgba(255, 255, 255, 0.08);
                --shadow-sm: 0 2px 8px rgba(0, 0, 0, 0.3);
                --shadow-md: 0 8px 24px rgba(0, 0, 0, 0.4);
                --shadow-lg: 0 16px 40px rgba(0, 0, 0, 0.5);
            }
            body { background-color: var(--bg-body); color: var(--text-dark); }
            .navbar { background: var(--glass-bg) !important; border-bottom-color: var(--border-color); }
            .bottom-nav { background: var(--glass-bg); border-color: var(--border-color); }
        }

        * {
            box-sizing: border-box;
            font-style: normal !important;
        }

        body {
            font-family: 'Inter', system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
            background-color: var(--bg-body);
            color: var(--text-dark);
            margin: 0;
            padding: 0;
            padding-bottom: 74px; /* Space for mobile floating nav */
            overflow-x: hidden;
            -webkit-font-smoothing: antialiased;
        }

        @media (min-width: 992px) {
            body { padding-bottom: 0; }
        }

        h1, h2, h3, h4, h5, h6, .brand-text, .font-heading {
            font-family: 'Outfit', 'Inter', sans-serif;
        }

        /* Ambient Top Glow */
        .ambient-glow {
            position: fixed;
            top: -240px;
            left: 50%;
            transform: translateX(-50%);
            width: min(1000px, 100vw);
            height: 480px;
            background: radial-gradient(ellipse, rgba(37, 99, 235, 0.12), transparent 70%);
            border-radius: 50%;
            pointer-events: none;
            z-index: 0;
        }

        /* ====== HEADER NAVBAR ====== */
        .navbar {
            background: var(--glass-bg) !important;
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border-bottom: 1px solid var(--border-color);
            box-shadow: var(--shadow-sm);
            padding: 10px 0;
            position: sticky;
            top: 0;
            z-index: 1050;
            transition: var(--transition);
        }

        .navbar.scrolled {
            box-shadow: var(--shadow-md);
            padding: 8px 0;
        }

        .navbar .container {
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        /* Brand Logo */
        .navbar-brand {
            display: flex;
            align-items: center;
            gap: 10px;
            text-decoration: none;
            margin: 0;
            padding: 0;
        }

        .navbar-brand img {
            max-height: 44px;
            width: auto;
            object-fit: contain;
            display: block;
        }

        .brand-icon-box {
            width: 42px;
            height: 42px;
            border-radius: 12px;
            background: var(--primary-gradient);
            color: #fff;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.15rem;
            box-shadow: 0 4px 14px rgba(37, 99, 235, 0.3);
            flex-shrink: 0;
        }

        .brand-text-block {
            line-height: 1.15;
        }

        .brand-title {
            font-size: 1.25rem;
            font-weight: 900;
            color: var(--text-dark);
            letter-spacing: -0.4px;
            display: block;
        }

        .brand-title span {
            background: var(--primary-gradient);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .brand-subline {
            font-size: 0.68rem;
            font-weight: 700;
            color: var(--text-muted);
            letter-spacing: 0.8px;
            text-transform: uppercase;
            display: block;
        }

        /* Desktop Nav Items */
        .nav-links-wrap {
            display: flex;
            align-items: center;
            gap: 6px;
            list-style: none;
            margin: 0;
            padding: 0;
        }

        .nav-link-item {
            text-decoration: none;
            color: var(--text-muted);
            font-size: 0.85rem;
            font-weight: 700;
            padding: 8px 14px;
            border-radius: var(--radius-sm);
            display: inline-flex;
            align-items: center;
            gap: 6px;
            transition: var(--transition);
        }

        .nav-link-item i {
            color: var(--primary-blue);
            font-size: 0.9rem;
        }

        .nav-link-item:hover, .nav-link-item.active {
            color: var(--primary-blue);
            background: rgba(37, 99, 235, 0.08);
            transform: translateY(-1px);
        }

        /* Live Support Header Pill */
        .btn-header-support {
            display: inline-flex;
            align-items: center;
            gap: 7px;
            background: rgba(37, 99, 235, 0.08);
            border: 1px solid rgba(37, 99, 235, 0.2);
            color: var(--primary-blue) !important;
            font-size: 0.78rem;
            font-weight: 800;
            padding: 7px 14px;
            border-radius: 30px;
            text-decoration: none;
            transition: var(--transition);
        }

        .btn-header-support:hover {
            background: var(--primary-blue);
            color: #fff !important;
            box-shadow: 0 4px 14px rgba(37, 99, 235, 0.3);
            transform: translateY(-2px);
        }

        .live-dot {
            width: 7px;
            height: 7px;
            border-radius: 50%;
            background: #10b981;
            display: inline-block;
            box-shadow: 0 0 0 2px rgba(16, 185, 129, 0.3);
            animation: pulse-dot 2s infinite;
        }

        @keyframes pulse-dot {
            0%, 100% { transform: scale(1); opacity: 1; }
            50% { transform: scale(1.3); opacity: 0.7; }
        }

        /* Login / User Avatar Button */
        .btn-header-login {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            background: var(--primary-gradient);
            color: #fff !important;
            font-size: 0.84rem;
            font-weight: 800;
            padding: 8px 18px;
            border-radius: var(--radius-sm);
            text-decoration: none;
            box-shadow: 0 4px 14px rgba(37, 99, 235, 0.25);
            transition: var(--transition);
        }

        .btn-header-login:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 22px rgba(37, 99, 235, 0.35);
            color: #fff !important;
        }

        .user-avatar-pill {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            background: var(--bg-card-subtle);
            border: 1px solid var(--border-color);
            padding: 4px 12px 4px 6px;
            border-radius: 30px;
            text-decoration: none;
            color: var(--text-dark);
            font-size: 0.82rem;
            font-weight: 800;
            transition: var(--transition);
        }

        .user-avatar-pill:hover {
            border-color: var(--primary-blue);
            color: var(--primary-blue);
            transform: translateY(-1px);
        }

        .user-avatar-circle {
            width: 32px;
            height: 32px;
            border-radius: 50%;
            background: var(--primary-gradient);
            color: #fff;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 900;
            font-size: 0.85rem;
        }

        /* ====== MOBILE FLOATING BOTTOM NAV BAR ====== */
        .bottom-nav {
            position: fixed;
            bottom: 12px;
            left: 14px;
            right: 14px;
            height: 60px;
            background: var(--glass-bg);
            backdrop-filter: blur(24px);
            -webkit-backdrop-filter: blur(24px);
            border: 1px solid var(--border-color);
            border-radius: 20px;
            box-shadow: 0 10px 32px rgba(15, 23, 42, 0.12);
            z-index: 1040;
            display: flex;
            align-items: center;
            justify-content: space-around;
            padding: 4px 8px;
        }

        .bottom-nav-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            gap: 3px;
            color: var(--text-muted);
            text-decoration: none;
            font-size: 0.68rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.3px;
            flex: 1;
            height: 100%;
            border-radius: 14px;
            transition: var(--transition);
        }

        .bottom-nav-item i {
            font-size: 1.15rem;
            transition: var(--transition);
        }

        .bottom-nav-item.active {
            color: var(--primary-blue);
            font-weight: 900;
            background: rgba(37, 99, 235, 0.1);
        }

        .bottom-nav-item.active i {
            transform: translateY(-2px) scale(1.1);
            color: var(--primary-blue);
        }

        .bottom-nav-item:hover {
            color: var(--primary-blue);
        }

        @media (min-width: 992px) {
            .bottom-nav { display: none !important; }
        }
    </style>
</head>
<body>

<div class="ambient-glow"></div>

<!-- Top Main Navbar -->
<nav class="navbar" id="mainNavbar">
    <div class="container">
        <!-- Logo -->
        <a class="navbar-brand" href="<?php echo $asset_base; ?>index.php" aria-label="<?php echo htmlspecialchars($set['site_name'] ?? 'Digital Shop'); ?>">
            <?php if(!empty($set['logo'])): ?>
                <img src="<?php echo (str_starts_with($set['logo'], 'http') ? $set['logo'] : $asset_base . $set['logo']); ?>" alt="<?php echo htmlspecialchars($set['site_name'] ?? 'Digital Shop'); ?>">
            <?php else: ?>
                <div class="brand-icon-box">
                    <i class="fa-solid fa-store"></i>
                </div>
                <div class="brand-text-block">
                    <span class="brand-title">
                        <?php 
                            $site_name = $set['site_name'] ?? 'Digital Shop';
                            $words = explode(' ', $site_name, 2);
                            if(count($words) > 1) {
                                echo htmlspecialchars($words[0]) . ' <span>' . htmlspecialchars($words[1]) . '</span>';
                            } else {
                                echo '<span>' . htmlspecialchars($site_name) . '</span>';
                            }
                        ?>
                    </span>
                    <span class="brand-subline"><?php echo htmlspecialchars($set['site_tagline'] ?? 'Instant Delivery & Subscriptions'); ?></span>
                </div>
            <?php endif; ?>
        </a>

        <!-- Desktop Navigation Items -->
        <div class="d-none d-lg-flex align-items-center gap-3">
            <ul class="nav-links-wrap">
                <li>
                    <a href="<?php echo $asset_base; ?>index.php" class="nav-link-item <?php echo ($current_script == 'index.php') ? 'active' : ''; ?>">
                        <i class="fa-solid fa-house"></i> Home
                    </a>
                </li>
                <li>
                    <a href="<?php echo $asset_base; ?>index.php#products" class="nav-link-item">
                        <i class="fa-solid fa-bag-shopping"></i> Products
                    </a>
                </li>
                <?php if(isset($_SESSION['user_id'])): ?>
                    <li>
                        <a href="<?php echo $asset_base; ?>orders.php" class="nav-link-item <?php echo ($current_script == 'orders.php') ? 'active' : ''; ?>">
                            <i class="fa-solid fa-receipt"></i> My Orders
                        </a>
                    </li>
                <?php endif; ?>
            </ul>

            <!-- User Status / Login Button -->
            <?php if(isset($_SESSION['user_id'])): ?>
                <a href="<?php echo $asset_base; ?>account.php" class="user-avatar-pill" title="My Account">
                    <span class="user-avatar-circle">
                        <?= strtoupper(substr($_SESSION['username'] ?? 'U', 0, 1)) ?>
                    </span>
                    <span><?= htmlspecialchars($_SESSION['username'] ?? 'My Account') ?></span>
                </a>
            <?php else: ?>
                <a href="<?php echo $asset_base; ?>login.php" class="btn-header-login">
                    <i class="fas fa-sign-in-alt"></i> Login
                </a>
            <?php endif; ?>
        </div>

        <!-- Mobile Header Actions -->
        <div class="d-flex d-lg-none align-items-center gap-2">
            <?php if(isset($_SESSION['user_id'])): ?>
                <a href="<?php echo $asset_base; ?>account.php" class="user-avatar-pill p-1">
                    <span class="user-avatar-circle" style="width:28px; height:28px; font-size:0.75rem;">
                        <?= strtoupper(substr($_SESSION['username'] ?? 'U', 0, 1)) ?>
                    </span>
                </a>
            <?php else: ?>
                <a href="<?php echo $asset_base; ?>login.php" class="btn-header-login px-3 py-1" style="font-size:0.75rem;">
                    Login
                </a>
            <?php endif; ?>
        </div>
    </div>
</nav>

<!-- Mobile Floating Bottom Nav -->
<div class="bottom-nav d-lg-none">
    <a href="<?php echo $asset_base; ?>index.php" class="bottom-nav-item <?php echo ($current_script == 'index.php') ? 'active' : ''; ?>">
        <i class="fa-solid fa-house"></i>
        <span>Home</span>
    </a>
    <a href="<?php echo $asset_base; ?>index.php#products" class="bottom-nav-item">
        <i class="fa-solid fa-bag-shopping"></i>
        <span>Catalog</span>
    </a>
    <a href="<?php echo $asset_base; ?>orders.php" class="bottom-nav-item <?php echo ($current_script == 'orders.php') ? 'active' : ''; ?>">
        <i class="fa-solid fa-receipt"></i>
        <span>Orders</span>
    </a>
    <a href="<?php echo $asset_base; ?>account.php" class="bottom-nav-item <?php echo ($current_script == 'account.php') ? 'active' : ''; ?>">
        <i class="fa-solid fa-circle-user"></i>
        <span>Account</span>
    </a>
</div>

<main class="py-2 py-md-4">