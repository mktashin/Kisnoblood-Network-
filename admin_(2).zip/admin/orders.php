<?php
include '../config.php';

// Security Check
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

$success = null;

// Handle 1-Click Fast Actions (Approve/Activate or Reject)
if (isset($_GET['action']) && isset($_GET['id'])) {
    $order_id = (int)$_GET['id'];
    $act = $_GET['action'];
    if ($act === 'approve') {
        $pdo->prepare("UPDATE orders SET status = 'Completed' WHERE id = ?")->execute([$order_id]);
        $success = "Order #{$order_id} has been Approved & Activated! Customer can now download the ZIP file.";
    } elseif ($act === 'reject') {
        $pdo->prepare("UPDATE orders SET status = 'Rejected' WHERE id = ?")->execute([$order_id]);
        $success = "Order #{$order_id} status changed to Rejected.";
    }
}

// Update Status Form Logic
if (isset($_POST['update_status'])) {
    $order_id = (int)$_POST['order_id'];
    $new_status = $_POST['status'];
    $pdo->prepare("UPDATE orders SET status = ? WHERE id = ?")->execute([$new_status, $order_id]);
    $success = "Order #{$order_id} status updated to {$new_status}!";
}

// Filter Logic
$tab = $_GET['tab'] ?? 'all';
$sql = "SELECT orders.*, users.name as user_name, users.email, users.whatsapp, products.title as prod_title, products.file_path, products.product_type 
        FROM orders 
        JOIN users ON orders.user_id = users.id 
        JOIN products ON orders.product_id = products.id ";

if ($tab === 'pending') {
    $sql .= " WHERE orders.status = 'Pending' ";
} elseif ($tab === 'completed') {
    $sql .= " WHERE orders.status = 'Completed' ";
} elseif ($tab === 'rejected') {
    $sql .= " WHERE orders.status = 'Rejected' ";
}

$sql .= " ORDER BY orders.id DESC";
$orders = $pdo->query($sql)->fetchAll();

// Statistics Counts
$total_count = $pdo->query("SELECT COUNT(*) FROM orders")->fetchColumn();
$pending_count = $pdo->query("SELECT COUNT(*) FROM orders WHERE status = 'Pending'")->fetchColumn();
$completed_count = $pdo->query("SELECT COUNT(*) FROM orders WHERE status = 'Completed'")->fetchColumn();
$rejected_count = $pdo->query("SELECT COUNT(*) FROM orders WHERE status = 'Rejected'")->fetchColumn();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Manage Orders | Admin Panel</title>
    
    <!-- Fonts & Icons -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">

    <style>
        :root {
            --primary-blue: #1e2ab8;
            --primary-gradient: linear-gradient(135deg, #1e2ab8 0%, #4338ca 100%);
            --primary-hover: #0f172a;
            --primary-light: #e0e7ff;
            --sidebar-w: 260px;
            --dark-bg: #0f172a;
            --border-color: #e2e8f0;
            --text-slate: #64748b;
            --text-dark: #1e293b;
            --card-bg: #ffffff;
            --shadow: 0 5px 15px rgba(30, 42, 184, 0.04);
            --radius: 20px;
            --success: #059669;
            --danger: #ef4444;
            --warning: #f97316;
        }

        @media (prefers-color-scheme: dark) {
            :root {
                --dark-bg: #0f172a;
                --card-bg: #1e293b;
                --border-color: #334155;
                --text-slate: #94a3b8;
                --text-dark: #e2e8f0;
            }
            body { background: #0f172a; }
            .order-card { background: #1e293b; border-color: #334155; }
            .order-card th { background: #0f172a; color: #94a3b8; border-color: #334155; }
            .order-card td { color: #e2e8f0; border-color: #334155; }
            .order-card tr:hover td { background: #0f172a; }
            .page-header .title { color: #e2e8f0; }
            .page-header .sub { color: #94a3b8; }
            .customer-name { color: #e2e8f0; }
            .prod-title { color: #e2e8f0; }
            .status-select { background: #0f172a; color: #e2e8f0; border-color: #334155; }
            .trx-id { color: #60a5fa; }
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Inter', sans-serif;
            font-style: normal !important;
        }

        body {
            background: #f1f5f9;
            color: var(--text-dark);
            min-height: 100vh;
            overflow-x: hidden;
        }

        /* ===== SIDEBAR ===== */
        .sidebar {
            height: 100vh;
            background: var(--dark-bg);
            position: fixed;
            width: var(--sidebar-w);
            z-index: 1050;
            transition: transform 0.3s cubic-bezier(0.2, 0.9, 0.4, 1);
            overflow-y: auto;
            border-right: 1px solid rgba(255, 255, 255, 0.05);
        }
        .sidebar-brand {
            padding: 20px 24px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.06);
            color: #fff;
            font-weight: 900;
            font-size: 1.1rem;
            display: flex;
            align-items: center;
            justify-content: space-between;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        .sidebar-brand .close-btn {
            background: none;
            border: none;
            color: #94a3b8;
            font-size: 1.2rem;
            cursor: pointer;
            display: none;
        }
        .nav-link-admin {
            padding: 12px 24px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            color: #94a3b8;
            text-decoration: none;
            font-weight: 700;
            font-size: 0.84rem;
            transition: all 0.2s ease;
            border-left: 4px solid transparent;
            text-transform: uppercase;
            letter-spacing: 0.3px;
        }
        .nav-link-admin:hover,
        .nav-link-admin.active {
            color: #fff;
            background: rgba(30, 42, 184, 0.15);
            border-left-color: var(--primary-blue);
        }
        .nav-link-admin i {
            width: 22px;
            font-size: 1rem;
            margin-right: 8px;
        }

        .main-content {
            margin-left: var(--sidebar-w);
            padding: 28px 32px;
            min-height: 100vh;
            transition: margin 0.3s cubic-bezier(0.2, 0.9, 0.4, 1);
        }

        .mobile-header {
            display: none;
            background: var(--dark-bg);
            color: white;
            padding: 14px 20px;
            position: sticky;
            top: 0;
            z-index: 1000;
            border-bottom: 1px solid rgba(255, 255, 255, 0.05);
        }

        /* ===== TABS FILTER ===== */
        .filter-tabs {
            display: flex;
            gap: 10px;
            margin-bottom: 22px;
            flex-wrap: wrap;
        }
        .tab-btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 9px 18px;
            border-radius: 999px;
            background: #fff;
            border: 1px solid var(--border-color);
            color: var(--text-slate);
            font-size: 0.8rem;
            font-weight: 700;
            text-decoration: none;
            transition: 0.2s;
        }
        .tab-btn:hover {
            border-color: var(--primary-blue);
            color: var(--primary-blue);
        }
        .tab-btn.active {
            background: var(--primary-blue);
            color: #fff;
            border-color: var(--primary-blue);
            box-shadow: 0 4px 12px rgba(30, 42, 184, 0.2);
        }
        .tab-badge {
            background: rgba(0, 0, 0, 0.08);
            color: inherit;
            padding: 2px 7px;
            border-radius: 12px;
            font-size: 0.72rem;
            font-weight: 800;
        }
        .tab-btn.active .tab-badge {
            background: rgba(255, 255, 255, 0.25);
            color: #fff;
        }

        /* ===== TABLE ===== */
        .order-card {
            background: var(--card-bg);
            border-radius: var(--radius);
            box-shadow: var(--shadow);
            border: 1px solid var(--border-color);
            overflow: hidden;
        }
        .table {
            margin-bottom: 0;
            vertical-align: middle;
        }
        .table thead th {
            background: #f8fafc;
            padding: 14px 18px;
            font-size: 0.72rem;
            font-weight: 800;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            color: var(--text-slate);
            border-bottom: 1px solid var(--border-color);
        }
        .table tbody td {
            padding: 16px 18px;
            border-bottom: 1px solid var(--border-color);
            font-size: 0.85rem;
        }
        .customer-name {
            font-weight: 800;
            color: var(--text-dark);
        }
        .customer-meta {
            font-size: 0.75rem;
            color: var(--text-slate);
            display: flex;
            gap: 12px;
            margin-top: 3px;
        }
        .customer-meta a {
            color: inherit;
            text-decoration: none;
        }
        .customer-meta a:hover {
            color: var(--primary-blue);
        }
        .prod-title {
            font-weight: 700;
        }
        .amount-badge {
            font-weight: 900;
            color: var(--primary-blue);
            font-size: 1.05rem;
        }
        .trx-code {
            font-family: monospace;
            background: rgba(30, 42, 184, 0.08);
            color: var(--primary-blue);
            padding: 3px 8px;
            border-radius: 6px;
            font-weight: 700;
            font-size: 0.8rem;
        }

        /* 1-Click Action Buttons */
        .btn-approve-fast {
            background: #059669;
            color: #fff !important;
            border: none;
            padding: 6px 12px;
            border-radius: 8px;
            font-size: 0.75rem;
            font-weight: 800;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 5px;
            transition: 0.2s;
        }
        .btn-approve-fast:hover {
            background: #047857;
            transform: translateY(-1px);
        }
        .btn-reject-fast {
            background: #fee2e2;
            color: #dc2626 !important;
            border: 1px solid #fca5a5;
            padding: 6px 10px;
            border-radius: 8px;
            font-size: 0.75rem;
            font-weight: 800;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 4px;
            transition: 0.2s;
        }
        .btn-reject-fast:hover {
            background: #dc2626;
            color: #fff !important;
        }

        .status-pill {
            display: inline-flex;
            align-items: center;
            gap: 5px;
            padding: 3px 10px;
            border-radius: 999px;
            font-size: 0.68rem;
            font-weight: 800;
            text-transform: uppercase;
        }
        .status-pill.pending { background: #fef3c7; color: #b45309; }
        .status-pill.completed { background: #d1fae5; color: #065f46; }
        .status-pill.rejected { background: #fee2e2; color: #b91c1c; }

        @media (max-width: 992px) {
            .sidebar { transform: translateX(-100%); }
            .sidebar.active { transform: translateX(0); }
            .sidebar-brand .close-btn { display: block; }
            .main-content { margin-left: 0; padding: 18px; }
            .mobile-header { display: flex; justify-content: space-between; align-items: center; }
        }
    </style>
</head>
<body>

<div class="sidebar" id="adminSidebar">
    <div class="sidebar-brand">
        <span><i class="fas fa-bolt me-2 text-warning"></i> Admin Panel</span>
        <button class="close-btn" onclick="toggleMenu()"><i class="fas fa-times"></i></button>
    </div>
    <div class="mt-3">
        <a href="dashboard.php" class="nav-link-admin"><i class="fas fa-chart-pie"></i> <span>Dashboard</span></a>
        <a href="product.php" class="nav-link-admin"><i class="fas fa-box"></i> <span>Products</span></a>
        <a href="category.php" class="nav-link-admin"><i class="fas fa-tags"></i> <span>Categories</span></a>
        <a href="orders.php" class="nav-link-admin active">
            <span><i class="fas fa-shopping-cart"></i> Orders</span>
            <?php if($pending_count > 0): ?>
                <span class="badge bg-danger rounded-pill"><?= $pending_count ?></span>
            <?php endif; ?>
        </a>
        <a href="slider.php" class="nav-link-admin"><i class="fas fa-images"></i> <span>Banners / Sliders</span></a>
        <a href="reviews.php" class="nav-link-admin"><i class="fas fa-star"></i> <span>Client Reviews</span></a>
        <a href="pages.php" class="nav-link-admin"><i class="fas fa-file-contract"></i> <span>Legal & Policies</span></a>
        <a href="users.php" class="nav-link-admin"><i class="fas fa-users"></i> <span>Users</span></a>
        <a href="settings.php" class="nav-link-admin"><i class="fas fa-sliders"></i> <span>Settings</span></a>
        <a href="../index.php" target="_blank" class="nav-link-admin" style="color: #60a5fa;"><i class="fas fa-external-link-alt"></i> <span>View Store</span></a>
        <a href="../logout.php" class="nav-link-admin text-danger mt-4"><i class="fas fa-power-off"></i> <span>Logout</span></a>
    </div>
    <div class="admin-dev-credit" style="padding:14px 20px;border-top:1px solid rgba(255,255,255,0.06);font-size:0.75rem;color:#64748b;text-align:center;margin-top:auto;">Developer: <span style="color:#60a5fa;font-weight:700;">Rafi</span></div>
</div>

<div class="mobile-header">
    <span class="fw-bold"><i class="fas fa-shopping-cart me-2"></i> Order Management</span>
    <button class="btn text-white fs-4 p-0" onclick="toggleMenu()"><i class="fas fa-bars"></i></button>
</div>

<div class="main-content">
    <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
        <div>
            <h4 class="fw-bold mb-1" style="color: var(--text-dark);"><i class="fas fa-shopping-cart me-2 text-primary"></i> Customer Orders</h4>
            <p class="text-muted small mb-0">Approve and activate orders, manage payments, and verify client transactions.</p>
        </div>
        <a href="dashboard.php" class="btn btn-sm btn-outline-secondary rounded-pill px-3"><i class="fas fa-arrow-left me-1"></i> Dashboard</a>
    </div>

    <?php if(!empty($success)): ?>
        <div class="alert alert-success border-0 shadow-sm rounded-4 mb-4 py-3 d-flex align-items-center gap-2">
            <i class="fas fa-check-circle fs-5"></i>
            <div><?= htmlspecialchars($success) ?></div>
        </div>
    <?php endif; ?>

    <!-- FILTER TABS -->
    <div class="filter-tabs">
        <a href="?tab=all" class="tab-btn <?= $tab === 'all' ? 'active' : '' ?>">
            All Orders <span class="tab-badge"><?= $total_count ?></span>
        </a>
        <a href="?tab=pending" class="tab-btn <?= $tab === 'pending' ? 'active' : '' ?>" style="<?= $tab === 'pending' ? 'background:#d97706;border-color:#d97706;' : '' ?>">
            <i class="fas fa-clock"></i> Pending (Needs Approval) <span class="tab-badge"><?= $pending_count ?></span>
        </a>
        <a href="?tab=completed" class="tab-btn <?= $tab === 'completed' ? 'active' : '' ?>" style="<?= $tab === 'completed' ? 'background:#059669;border-color:#059669;' : '' ?>">
            <i class="fas fa-check-double"></i> Completed / Active <span class="tab-badge"><?= $completed_count ?></span>
        </a>
        <a href="?tab=rejected" class="tab-btn <?= $tab === 'rejected' ? 'active' : '' ?>">
            Rejected <span class="tab-badge"><?= $rejected_count ?></span>
        </a>
    </div>

    <!-- ORDERS TABLE -->
    <div class="order-card">
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>Order / Customer</th>
                        <th>Product Details</th>
                        <th>Amount</th>
                        <th>Transaction Info</th>
                        <th>Current Status</th>
                        <th class="text-end">A-to-Z Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(!empty($orders)): ?>
                        <?php foreach($orders as $o): ?>
                        <tr>
                            <td>
                                <div class="fw-bold text-dark">#<?= $o['id'] ?> — <?= htmlspecialchars($o['user_name']) ?></div>
                                <div class="customer-meta">
                                    <span><i class="fas fa-envelope me-1"></i> <?= htmlspecialchars($o['email']) ?></span>
                                    <?php if(!empty($o['whatsapp'])): ?>
                                        <span><a href="https://wa.me/<?= preg_replace('/[^0-9]/', '', $o['whatsapp']) ?>" target="_blank"><i class="fab fa-whatsapp text-success me-1"></i> <?= htmlspecialchars($o['whatsapp']) ?></a></span>
                                    <?php endif; ?>
                                </div>
                            </td>
                            <td>
                                <div class="prod-title"><?= htmlspecialchars($o['prod_title']) ?></div>
                                <div class="small text-muted">
                                    <?php if(!empty($o['file_path'])): ?>
                                        <span class="badge" style="background: #ecfdf5; color: #065f46; border: 1px solid #a7f3d0;"><i class="fas fa-file-zipper me-1"></i> ZIP File Ready</span>
                                    <?php else: ?>
                                        <span class="badge text-muted" style="background:#f1f5f9;">Service / Sub</span>
                                    <?php endif; ?>
                                    <?php if(!empty($o['sub_email'])): ?>
                                        <span class="ms-1"><i class="fas fa-at"></i> <?= htmlspecialchars($o['sub_email']) ?></span>
                                    <?php endif; ?>
                                </div>
                            </td>
                            <td>
                                <div class="amount-badge">৳<?= number_format($o['amount'], 2) ?></div>
                            </td>
                            <td>
                                <div>
                                    <code class="trx-code"><?= htmlspecialchars($o['trx_id']) ?></code>
                                    <?php if(($o['payment_method'] ?? '') === 'HostNekoPay'): ?>
                                        <span class="badge bg-primary ms-1" style="font-size:0.65rem;"><i class="fas fa-bolt"></i> Auto: HostNekoPay</span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary ms-1" style="font-size:0.65rem;">Manual</span>
                                    <?php endif; ?>
                                </div>
                                <div class="small text-muted mt-1">
                                    <i class="fas fa-phone me-1"></i> Sender: <strong><?= htmlspecialchars($o['sender_number'] ?? 'N/A') ?></strong>
                                </div>
                                <div class="small text-muted" style="font-size: 11px;">
                                    <?= date('d M Y, h:i A', strtotime($o['created_at'])) ?>
                                </div>
                            </td>
                            <td>
                                <span class="status-pill <?= strtolower($o['status']) ?>">
                                    <i class="fas <?= $o['status'] === 'Completed' ? 'fa-check-circle' : ($o['status'] === 'Pending' ? 'fa-spinner fa-spin' : 'fa-times-circle') ?>"></i>
                                    <?= htmlspecialchars($o['status']) ?>
                                </span>
                            </td>
                            <td class="text-end">
                                <div class="d-inline-flex gap-1 align-items-center flex-wrap justify-content-end">
                                    <?php if($o['status'] === 'Pending'): ?>
                                        <!-- 1-Click Fast Approve & Activate -->
                                        <a href="?action=approve&id=<?= $o['id'] ?>&tab=<?= htmlspecialchars($tab) ?>" class="btn-approve-fast" title="Verify Payment & Activate Order">
                                            <i class="fas fa-check-circle"></i> Activate
                                        </a>
                                        <a href="?action=reject&id=<?= $o['id'] ?>&tab=<?= htmlspecialchars($tab) ?>" class="btn-reject-fast" onclick="return confirm('Reject this order?');" title="Reject Order">
                                            <i class="fas fa-times"></i>
                                        </a>
                                    <?php endif; ?>

                                    <!-- Quick Invoice View -->
                                    <a href="../invoice.php?order_id=<?= $o['id'] ?>" target="_blank" class="btn btn-sm btn-outline-secondary" title="View Customer Invoice">
                                        <i class="fas fa-file-invoice"></i>
                                    </a>

                                    <!-- Status changer dropdown form -->
                                    <form method="POST" class="d-inline-flex gap-1 align-items-center">
                                        <input type="hidden" name="order_id" value="<?= $o['id'] ?>">
                                        <select name="status" class="form-select form-select-sm" style="width: auto; font-size: 0.75rem; font-weight: 700;">
                                            <option value="Pending" <?= $o['status'] === 'Pending' ? 'selected' : '' ?>>Pending</option>
                                            <option value="Completed" <?= $o['status'] === 'Completed' ? 'selected' : '' ?>>Completed</option>
                                            <option value="Rejected" <?= $o['status'] === 'Rejected' ? 'selected' : '' ?>>Rejected</option>
                                        </select>
                                        <button type="submit" name="update_status" class="btn btn-sm btn-primary py-1 px-2" title="Save Status"><i class="fas fa-save"></i></button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="6" class="text-center py-5">
                                <i class="fas fa-inbox fs-1 text-muted d-block mb-2"></i>
                                <h6 class="fw-bold">No orders found under this filter.</h6>
                                <p class="text-muted small">Customer submissions will appear here.</p>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
function toggleMenu() {
    document.getElementById('adminSidebar').classList.toggle('active');
}
</script>
</body>
</html>