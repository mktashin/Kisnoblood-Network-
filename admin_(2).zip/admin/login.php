<?php 
include '../config.php'; 

if (isset($_SESSION['role']) && $_SESSION['role'] == 'admin') {
    header("Location: dashboard.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ? AND role = 'admin'");
    $stmt->execute([$email]);
    $admin = $stmt->fetch();

    if ($admin && password_verify($password, $admin['password'])) {
        $_SESSION['user_id'] = $admin['id'];
        $_SESSION['user_name'] = $admin['name'];
        $_SESSION['role'] = 'admin';
        header("Location: dashboard.php");
    } else {
        $error = "Access Denied. Invalid Admin Credentials.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Access | <?= $set['site_name'] ?></title>
    
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/premium-theme.css">
    <link rel="stylesheet" href="../assets/css/jx-toast.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>
    <script src="../assets/js/jx-toast.js"></script>

    <style>
        :root {
            --admin-red: #ff3333;
            --dark-bg: #0f172a;
            --card-bg: rgba(30, 41, 59, 0.7);
        }

        body {
            font-family: 'Outfit', sans-serif;
            background: radial-gradient(circle at top right, #1e293b, #0f172a);
            height: 100vh;
            display: flex;
            align-items: center;
            color: #fff;
            margin: 0;
            overflow: hidden;
        }

        .admin-login-card {
            background: var(--card-bg);
            backdrop-filter: blur(12px);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 25px;
            padding: 45px 35px;
            width: 100%;
            max-width: 420px;
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5);
        }

        .portal-icon {
            width: 70px;
            height: 70px;
            background: rgba(255, 51, 51, 0.1);
            color: var(--admin-red);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 30px;
            border-radius: 20px;
            margin: 0 auto 20px;
            border: 1px solid rgba(255, 51, 51, 0.2);
        }

        h3 {
            font-weight: 700;
            letter-spacing: -0.5px;
            margin-bottom: 5px;
        }

        .text-subtitle {
            color: #94a3b8;
            font-size: 0.9rem;
            margin-bottom: 30px;
        }

        .form-label {
            font-size: 0.85rem;
            font-weight: 600;
            color: #cbd5e1;
            margin-left: 5px;
        }

        .input-group-custom {
            position: relative;
            margin-bottom: 20px;
        }

        .input-group-custom i {
            position: absolute;
            left: 18px;
            top: 50%;
            transform: translateY(-50%);
            color: #64748b;
        }

        .form-control {
            background: rgba(15, 23, 42, 0.6);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 15px;
            padding: 14px 20px 14px 50px;
            color: #fff;
            transition: 0.3s;
        }

        .form-control:focus {
            background: rgba(15, 23, 42, 0.8);
            border-color: var(--admin-red);
            box-shadow: 0 0 0 4px rgba(255, 51, 51, 0.15);
            color: #fff;
        }

        .btn-admin {
            background: var(--admin-red);
            border: none;
            border-radius: 15px;
            padding: 14px;
            font-weight: 700;
            font-size: 1rem;
            color: #fff;
            transition: 0.4s;
            margin-top: 10px;
        }

        .btn-admin:hover {
            background: #cc0000;
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(255, 51, 51, 0.3);
        }

        .alert {
            background: rgba(239, 68, 68, 0.1);
            border: 1px solid rgba(239, 68, 68, 0.2);
            color: #f87171;
            border-radius: 12px;
            font-size: 0.85rem;
            margin-bottom: 25px;
        }

        .back-link {
            color: #64748b;
            font-size: 0.85rem;
            text-decoration: none;
            transition: 0.3s;
        }

        .back-link:hover {
            color: var(--admin-red);
        }
    </style>
</head>
<body>

    <div class="container d-flex justify-content-center">
        <div class="admin-login-card animate__animated animate__fadeInDown">
            <div class="text-center">
                <div class="portal-icon">
                    <i class="fas fa-user-shield"></i>
                </div>
                <h3>Admin Portal</h3>
                <p class="text-subtitle">Secure access to control panel</p>
            </div>

            <?php if(isset($error)): ?>
                <div class="alert animate__animated animate__shakeX" data-jx-toast-type="error">
                    <i class="fas fa-shield-alt me-2"></i> <?= $error ?>
                </div>
            <?php endif; ?>

            <form method="POST">
                <div class="mb-3">
                    <label class="form-label">Administrator Email</label>
                    <div class="input-group-custom">
                        <i class="fas fa-envelope"></i>
                        <input type="email" name="email" class="form-control" placeholder="admin@domain.com" required>
                    </div>
                </div>

                <div class="mb-4">
                    <label class="form-label">Security Password</label>
                    <div class="input-group-custom">
                        <i class="fas fa-key"></i>
                        <input type="password" name="password" class="form-control" placeholder="••••••••" required>
                    </div>
                </div>

                <button type="submit" class="btn-admin w-100">
                    <i class="fas fa-unlock-alt me-2"></i> Authorized Login
                </button>
            </form>
<div style="text-align:center;margin-top:20px;font-size:0.8rem;color:#64748b;">Developer: <span style="color:#60a5fa;font-weight:700;">Rafi</span></div>

            <div class="text-center mt-4">
                <a href="../index.php" class="back-link">
                    <i class="fas fa-long-arrow-alt-left me-1"></i> Return to Storefront
                </a>
            </div>
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
<script src="../assets/js/premium.js"></script>
</body>
</html>