<?php
// সেশন শুরু করা নিশ্চিত করা হলো
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include '../config.php';

// Security Check
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

function private_download_path(?string $storedPath): ?string {
    if (!$storedPath) return null;
    $storedPath = trim($storedPath);
    if ($storedPath === '') return null;
    if (preg_match('#^https?://#i', $storedPath)) {
        return $storedPath;
    }
    $name = basename(str_replace('\\', '/', $storedPath));
    if ($name === '' || $name === '.' || $name === '..' || str_contains($name, "\0")) return null;

    $candidates = [
        (defined('JHX_PRIVATE_DOWNLOAD_DIR') ? rtrim(JHX_PRIVATE_DOWNLOAD_DIR, '/\\') . DIRECTORY_SEPARATOR . $name : ''),
        dirname(__DIR__) . DIRECTORY_SEPARATOR . 'downloads' . DIRECTORY_SEPARATOR . $name,
        dirname(__DIR__) . DIRECTORY_SEPARATOR . ltrim(str_replace('/', DIRECTORY_SEPARATOR, $storedPath), DIRECTORY_SEPARATOR),
        dirname(__DIR__) . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR . $name,
        dirname(__DIR__) . DIRECTORY_SEPARATOR . $name,
    ];
    foreach ($candidates as $c) {
        if ($c !== '' && is_file($c) && is_readable($c)) {
            return $c;
        }
    }
    $defaultRoot = defined('JHX_PRIVATE_DOWNLOAD_DIR') ? JHX_PRIVATE_DOWNLOAD_DIR : dirname(__DIR__) . DIRECTORY_SEPARATOR . 'downloads';
    return rtrim($defaultRoot, '/\\') . DIRECTORY_SEPARATOR . $name;
}

// ================= HANDLE ADMIN TEST DOWNLOAD =================
if (isset($_GET['admin_download'])) {
    $id = (int)$_GET['admin_download'];
    $stmt = $pdo->prepare("SELECT title, file_path, drive_link FROM products WHERE id = ?");
    $stmt->execute([$id]);
    $prod = $stmt->fetch();
    if ($prod) {
        $path = private_download_path($prod['file_path']);
        if ($path && is_file($path) && is_readable($path)) {
            while (ob_get_level() > 0) ob_end_clean();
            $ext = pathinfo($path, PATHINFO_EXTENSION) ?: 'zip';
            $downloadName = preg_replace('/[^A-Za-z0-9._-]+/', '_', $prod['title']) . '.' . $ext;
            header('Content-Type: application/octet-stream');
            header('Content-Disposition: attachment; filename="' . $downloadName . '"');
            header('Content-Length: ' . (string)filesize($path));
            header('Cache-Control: private, no-cache');
            readfile($path);
            exit();
        } elseif (!empty($prod['file_path']) && preg_match('#^https?://#i', trim($prod['file_path']))) {
            header('Location: ' . trim($prod['file_path']));
            exit();
        } elseif (!empty($prod['drive_link']) && preg_match('#^https?://#i', trim($prod['drive_link']))) {
            header('Location: ' . trim($prod['drive_link']));
            exit();
        } else {
            $error = "Download file not found on server and no cloud link is attached for this product.";
        }
    }
}

// ================= HANDLE DELETE PRODUCT =================
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    
    $stmt = $pdo->prepare("SELECT image, file_path FROM products WHERE id = ?");
    $stmt->execute([$id]);
    $old_data = $stmt->fetch();
    
    if ($old_data) {
        if (!empty($old_data['image'])) {
            if (file_exists("../" . $old_data['image'])) { @unlink("../" . $old_data['image']); }
            elseif (file_exists($old_data['image'])) { @unlink($old_data['image']); }
        }
        if (!empty($old_data['file_path'])) {
            $private_file = private_download_path($old_data['file_path']);
            if ($private_file && is_file($private_file)) @unlink($private_file);
        }
    }

    try {
        // disable foreign keys if needed
        if ($pdo->getAttribute(PDO::ATTR_DRIVER_NAME) === "sqlite") { $pdo->exec("PRAGMA foreign_keys = OFF;"); } else { $pdo->exec("SET FOREIGN_KEY_CHECKS = 0;"); }
        $delete_stmt = $pdo->prepare("DELETE FROM products WHERE id = ?");
        $delete_stmt->execute([$id]);
        // re-enable foreign keys
        if ($pdo->getAttribute(PDO::ATTR_DRIVER_NAME) === "sqlite") { $pdo->exec("PRAGMA foreign_keys = ON;"); } else { $pdo->exec("SET FOREIGN_KEY_CHECKS = 1;"); }
        
        header("Location: product.php?msg=deleted");
        exit();
    } catch (PDOException $e) {
        $error = "Database Error: " . $e->getMessage();
    }
}

// ================= HANDLE DELETE GALLERY IMAGE =================
if (isset($_GET['delete_gallery_img'])) {
    $img_id = (int)$_GET['delete_gallery_img'];
    $stmt = $pdo->prepare("SELECT * FROM product_images WHERE id = ?");
    $stmt->execute([$img_id]);
    $g_img = $stmt->fetch();
    if ($g_img) {
        if (!empty($g_img['image']) && file_exists(dirname(__DIR__) . '/' . $g_img['image'])) {
            @unlink(dirname(__DIR__) . '/' . $g_img['image']);
        }
        $pdo->prepare("DELETE FROM product_images WHERE id = ?")->execute([$img_id]);
    }
    header("Location: product.php?msg=gallery_deleted");
    exit();
}

// ================= HANDLE ADD PRODUCT =================
if (isset($_POST['add_product'])) {
    $title = $_POST['title'];
    $cat = $_POST['category_id'];
    $type = $_POST['product_type'];
    $r_price = $_POST['regular_price'];
    $o_price = $_POST['offer_price'];
    $drive = $_POST['drive_link'];
    $desc = $_POST['description'];
    $stock = $_POST['stock'];
    $variations = $_POST['variations'];
    
    $img_dir = dirname(__DIR__) . '/uploads/';
    $downloads_base = defined('JHX_PRIVATE_DOWNLOAD_DIR') ? JHX_PRIVATE_DOWNLOAD_DIR : dirname(__DIR__) . '/downloads';
    $file_dir = rtrim(str_replace('\\', '/', $downloads_base), '/') . '/';
    if (!file_exists($img_dir)) { @mkdir($img_dir, 0755, true); }
    if (!file_exists($file_dir)) { @mkdir($file_dir, 0755, true); }
    
    $image_uploaded = false;
    $db_image_path = "";
    $db_file_path = NULL;

    if (!empty($_FILES['image']['name'])) {
        $img_name = time() . "_img_" . preg_replace('/[^A-Za-z0-9._-]/', '_', basename($_FILES['image']['name']));
        if (move_uploaded_file($_FILES['image']['tmp_name'], $img_dir . $img_name)) {
            @chmod($img_dir . $img_name, 0644);
            $db_image_path = "uploads/" . $img_name;
            $image_uploaded = true;
        }
    }

    if (!empty($_FILES['download_file']['name'])) {
        $file_name = time() . "_file_" . preg_replace('/[^A-Za-z0-9._-]/', '_', basename($_FILES['download_file']['name']));
        $target_destination = $file_dir . $file_name;
        if (move_uploaded_file($_FILES['download_file']['tmp_name'], $target_destination)) {
            @chmod($target_destination, 0644);
            $db_file_path = "private_downloads/" . $file_name;
        }
    }

    if ($image_uploaded) {
        $sql = "INSERT INTO products (category_id, title, product_type, regular_price, offer_price, drive_link, file_path, description, stock, image, variations) VALUES (?,?,?,?,?,?,?,?,?,?,?)";
        $pdo->prepare($sql)->execute([$cat, $title, $type, $r_price, $o_price, $drive, $db_file_path, $desc, $stock, $db_image_path, $variations]);
        $new_prod_id = $pdo->lastInsertId();

        // Handle multiple gallery photos
        if (!empty($_FILES['gallery_images']['name'][0])) {
            foreach ($_FILES['gallery_images']['name'] as $key => $g_name) {
                if (!empty($g_name) && $_FILES['gallery_images']['error'][$key] === UPLOAD_ERR_OK) {
                    $g_ext = strtolower(pathinfo($g_name, PATHINFO_EXTENSION));
                    if (in_array($g_ext, ['jpg', 'jpeg', 'png', 'webp', 'gif', 'svg'])) {
                        $g_filename = time() . "_gal_" . $key . "_" . preg_replace('/[^A-Za-z0-9._-]/', '_', basename($g_name));
                        if (move_uploaded_file($_FILES['gallery_images']['tmp_name'][$key], $img_dir . $g_filename)) {
                            @chmod($img_dir . $g_filename, 0644);
                            $pdo->prepare("INSERT INTO product_images (product_id, image, sort_order) VALUES (?, ?, ?)")->execute([$new_prod_id, "uploads/" . $g_filename, $key]);
                        }
                    }
                }
            }
        }
        $success = "Product published successfully with gallery photos!";
    } else {
        $error = "Failed to upload product main image.";
    }
}

// ================= HANDLE EDIT/UPDATE PRODUCT =================
if (isset($_POST['update_product'])) {
    $id = $_POST['product_id'];
    $title = $_POST['title'];
    $cat = $_POST['category_id'];
    $type = $_POST['product_type'];
    $r_price = $_POST['regular_price'];
    $o_price = $_POST['offer_price'];
    $drive = $_POST['drive_link'];
    $desc = $_POST['description'];
    $stock = $_POST['stock'];
    $variations = $_POST['variations'];

    $stmt = $pdo->prepare("SELECT image, file_path FROM products WHERE id = ?");
    $stmt->execute([$id]);
    $current_prod = $stmt->fetch();

    $db_image_path = $current_prod['image'];
    $db_file_path = $current_prod['file_path'];

    $img_dir = dirname(__DIR__) . '/uploads/';
    $downloads_base = defined('JHX_PRIVATE_DOWNLOAD_DIR') ? JHX_PRIVATE_DOWNLOAD_DIR : dirname(__DIR__) . '/downloads';
    $file_dir = rtrim(str_replace('\\', '/', $downloads_base), '/') . '/';
    if (!file_exists($img_dir)) { @mkdir($img_dir, 0755, true); }
    if (!file_exists($file_dir)) { @mkdir($file_dir, 0755, true); }

    if (!empty($_FILES['image']['name'])) {
        if (!empty($current_prod['image']) && file_exists(dirname(__DIR__) . '/' . $current_prod['image'])) {
            @unlink(dirname(__DIR__) . '/' . $current_prod['image']);
        }
        $img_name = time() . "_img_" . preg_replace('/[^A-Za-z0-9._-]/', '_', basename($_FILES['image']['name']));
        if (move_uploaded_file($_FILES['image']['tmp_name'], $img_dir . $img_name)) {
            @chmod($img_dir . $img_name, 0644);
            $db_image_path = "uploads/" . $img_name;
        }
    }

    if (!empty($_FILES['download_file']['name'])) {
        $old_private_file = private_download_path($current_prod['file_path']);
        if ($old_private_file && is_file($old_private_file)) {
            @unlink($old_private_file);
        }
        $file_name = time() . "_file_" . preg_replace('/[^A-Za-z0-9._-]/', '_', basename($_FILES['download_file']['name']));
        $target_destination = $file_dir . $file_name;
        if (move_uploaded_file($_FILES['download_file']['tmp_name'], $target_destination)) {
            @chmod($target_destination, 0644);
            $db_file_path = "private_downloads/" . $file_name;
        }
    }

    // Handle additional gallery images on update
    if (!empty($_FILES['gallery_images']['name'][0])) {
        foreach ($_FILES['gallery_images']['name'] as $key => $g_name) {
            if (!empty($g_name) && $_FILES['gallery_images']['error'][$key] === UPLOAD_ERR_OK) {
                $g_ext = strtolower(pathinfo($g_name, PATHINFO_EXTENSION));
                if (in_array($g_ext, ['jpg', 'jpeg', 'png', 'webp', 'gif', 'svg'])) {
                    $g_filename = time() . "_gal_" . $key . "_" . preg_replace('/[^A-Za-z0-9._-]/', '_', basename($g_name));
                    if (move_uploaded_file($_FILES['gallery_images']['tmp_name'][$key], $img_dir . $g_filename)) {
                        @chmod($img_dir . $g_filename, 0644);
                        $pdo->prepare("INSERT INTO product_images (product_id, image, sort_order) VALUES (?, ?, ?)")->execute([$id, "uploads/" . $g_filename, $key]);
                    }
                }
            }
        }
    }

    $sql = "UPDATE products SET category_id=?, title=?, product_type=?, regular_price=?, offer_price=?, drive_link=?, file_path=?, description=?, stock=?, image=?, variations=? WHERE id=?";
    $pdo->prepare($sql)->execute([$cat, $title, $type, $r_price, $o_price, $drive, $db_file_path, $desc, $stock, $db_image_path, $variations, $id]);
    $success = "Product updated successfully!";
}

// ক্যাটাগরি লিস্ট এবং নোটিফিকেশন কাউন্ট তুলে আনা
$cats = $pdo->query("SELECT * FROM categories ORDER BY id ASC")->fetchAll();
$pending_orders = $pdo->query("SELECT COUNT(*) FROM orders WHERE status = 'Pending'")->fetchColumn();

// Fetch all gallery images grouped by product_id
$gallery_stmt = $pdo->query("SELECT * FROM product_images ORDER BY sort_order ASC, id ASC");
$all_gallery_images = [];
while ($row = $gallery_stmt->fetch(PDO::FETCH_ASSOC)) {
    $all_gallery_images[$row['product_id']][] = $row;
}

if (isset($_GET['msg']) && $_GET['msg'] == 'deleted') {
    $success = "Product deleted successfully!";
}
if (isset($_GET['msg']) && $_GET['msg'] == 'gallery_deleted') {
    $success = "Gallery photo removed successfully!";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Products | Admin Panel</title>
    
    <!-- ====== ফন্ট: Inter ====== -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/premium-theme.css">
    <link rel="stylesheet" href="../assets/css/jx-toast.css">
    <script src="../assets/js/jx-toast.js"></script>
    
    <style>
        /* ==========================================
           ✅ ADMIN PRODUCTS UPDATED: 11 August 2026
           📌 নীল থিম (#1e2ab8)
        ========================================== */
        
        :root {
            --primary-blue: #1e2ab8;
            --primary-gradient: linear-gradient(135deg, #1e2ab8 0%, #4338ca 100%);
            --primary-hover: #0f172a;
            --primary-light: #e0e7ff;
            --sidebar-w: 260px;
            --dark-bg: #0f172a;
            --border-color: #e2e8f0;
            --text-slate: #64748b;
        }

        /* ডার্ক মোড অটো */
        @media (prefers-color-scheme: dark) {
            :root {
                --dark-bg: #0f172a;
                --border-color: #334155;
                --text-slate: #94a3b8;
            }
            body { background: #0f172a; }
            .product-card { background: #1e293b; border-color: #334155; }
            .product-card .table-light { background: #0f172a; }
            .product-card .table-light th { color: #94a3b8; }
            .product-card td { color: #e2e8f0; border-color: #334155; }
            .product-card .text-muted { color: #94a3b8 !important; }
            .product-card .badge.bg-light { background: #0f172a !important; color: #e2e8f0 !important; border-color: #334155 !important; }
            .modal-content { background: #1e293b; border-color: #334155; }
            .modal-header { border-color: #334155; }
            .modal-header h5 { color: #e2e8f0; }
            .modal-footer { border-color: #334155; }
            .form-control, .form-select { background: #0f172a; color: #e2e8f0; border-color: #334155; }
            .form-control:focus, .form-select:focus { background: #1e293b; border-color: #60a5fa; box-shadow: 0 0 0 3px rgba(30, 42, 184, 0.15); }
            .form-control::placeholder { color: #64748b; }
        }

        * { font-style: normal !important; }
        
        body { 
            font-family: 'Inter', sans-serif; 
            background: #f1f5f9; 
            margin: 0; 
        }

        /* ====== Sidebar ====== */
        .sidebar { 
            height: 100vh; 
            background: var(--dark-bg); 
            position: fixed; 
            width: var(--sidebar-w); 
            z-index: 1050; 
            transition: 0.3s; 
        }
        
        .sidebar-brand { 
            padding: 25px; 
            border-bottom: 1px solid rgba(255,255,255,0.08); 
            color: #fff; 
            font-weight: 900; 
            font-size: 1.1rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .sidebar-brand i {
            color: #60a5fa;
        }
        
        .nav-link-admin { 
            padding: 14px 25px; 
            display: block; 
            color: #94a3b8; 
            text-decoration: none; 
            transition: 0.3s; 
            font-weight: 700; 
            border-left: 4px solid transparent;
            font-size: 0.85rem;
            text-transform: uppercase;
            letter-spacing: 0.3px;
        }
        
        .nav-link-admin:hover, 
        .nav-link-admin.active { 
            background: rgba(30, 42, 184, 0.1); 
            color: #fff; 
            border-left-color: var(--primary-blue); 
        }
        
        .nav-link-admin i {
            color: #60a5fa;
            width: 20px;
        }
        
        .nav-link-admin.active i {
            color: #93bbfc;
        }
        
        .nav-link-admin .badge {
            background: #ef4444;
            color: #fff;
            font-size: 0.65rem;
            padding: 2px 10px;
        }

        /* ====== Main Content ====== */
        .main-content { 
            margin-left: var(--sidebar-w); 
            padding: 30px; 
            transition: 0.3s; 
        }
        
        .mobile-header { 
            display: none; 
            background: var(--dark-bg); 
            color: white; 
            padding: 15px 20px; 
            position: sticky; 
            top: 0; 
            z-index: 1000; 
        }

        /* ====== Product Card ====== */
        .product-card { 
            background: #fff; 
            border-radius: 20px; 
            border: 1px solid var(--border-color); 
            box-shadow: 0 5px 15px rgba(30, 42, 184, 0.02); 
            overflow: hidden; 
        }
        
        .prod-img { 
            width: 45px; 
            height: 45px; 
            object-fit: cover; 
            border-radius: 10px; 
            border: 2px solid var(--border-color);
        }
        
        /* ====== Add Button (নীল) ====== */
        .btn-add { 
            background: var(--primary-gradient); 
            color: white; 
            border-radius: 12px; 
            font-weight: 700; 
            padding: 10px 24px; 
            border: none; 
            transition: 0.3s;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            font-size: 0.8rem;
        }
        .btn-add:hover { 
            background: var(--primary-hover); 
            transform: translateY(-2px); 
            color: white; 
            box-shadow: 0 8px 25px rgba(30, 42, 184, 0.3); 
        }

        /* ====== Form Controls ====== */
        .form-control, .form-select { 
            border-radius: 10px; 
            padding: 10px 15px; 
            border: 2px solid var(--border-color); 
            font-size: 0.9rem;
            font-weight: 600;
            transition: all 0.3s ease;
            background: #fff;
            color: var(--dark-bg);
        }
        
        .form-control:focus, .form-select:focus { 
            box-shadow: 0 0 0 3px rgba(30, 42, 184, 0.1); 
            border-color: var(--primary-blue); 
        }

        /* ====== Modal ====== */
        .modal-content {
            border-radius: 20px;
            border: 1px solid var(--border-color);
        }
        
        .modal-header {
            border-bottom: 1px solid var(--border-color);
        }
        
        .modal-header h5 {
            font-weight: 900;
            color: var(--dark-bg);
            text-transform: uppercase;
            letter-spacing: 0.3px;
            font-size: 0.95rem;
        }
        
        .modal-header h5 i {
            color: var(--primary-blue);
        }
        
        .modal-footer {
            border-top: 1px solid var(--border-color);
        }

        /* ====== বাটন ====== */
        .btn-primary {
            background: var(--primary-gradient) !important;
            border: none !important;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            font-size: 0.8rem;
            padding: 12px;
            border-radius: 12px;
            transition: all 0.3s ease;
        }
        
        .btn-primary:hover {
            background: var(--primary-hover) !important;
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(30, 42, 184, 0.3);
        }
        
        .btn-outline-primary {
            border-color: var(--primary-blue) !important;
            color: var(--primary-blue) !important;
            font-weight: 700;
        }
        
        .btn-outline-primary:hover {
            background: var(--primary-blue) !important;
            color: #fff !important;
        }
        
        .btn-outline-danger {
            font-weight: 700;
        }

        /* ====== রেসপনসিভ ====== */
        @media (max-width: 992px) {
            .sidebar { transform: translateX(-100%); }
            .sidebar.active { transform: translateX(0); }
            .main-content { margin-left: 0; padding: 20px; }
            .mobile-header { display: flex; justify-content: space-between; align-items: center; }
        }
        
        @media (max-width: 480px) {
            .main-content { padding: 12px; }
            .product-card { border-radius: 14px; }
            .btn-add { padding: 8px 16px; font-size: 0.7rem; }
            .modal-content { border-radius: 14px; }
        }
        
        .sidebar-overlay { 
            display: none; 
            position: fixed; 
            inset: 0; 
            background: rgba(0,0,0,0.5); 
            z-index: 1040; 
        }
        .sidebar-overlay.show { display: block; }
        
        .breadcrumb-item a {
            color: var(--text-slate);
            text-decoration: none;
            font-weight: 600;
        }
        .breadcrumb-item a:hover {
            color: var(--primary-blue);
        }
        .breadcrumb-item.active {
            color: var(--primary-blue);
            font-weight: 700;
        }
    </style>
</head>
<body>

<div class="sidebar-overlay" id="overlay" onclick="toggleMenu()"></div>

<!-- ====== Sidebar ====== -->
<div class="sidebar" id="adminSidebar">
    <div class="sidebar-brand d-flex align-items-center justify-content-between">
        <span><i class="fas fa-bolt me-2"></i> Admin Panel</span>
        <button class="btn text-white d-lg-none" onclick="toggleMenu()"><i class="fas fa-times"></i></button>
    </div>
    <div class="mt-3">
        <a href="dashboard.php" class="nav-link-admin"><i class="fas fa-chart-pie me-2"></i> Dashboard</a>
        <a href="product.php" class="nav-link-admin active"><i class="fas fa-box me-2"></i> Products</a>
        <a href="category.php" class="nav-link-admin"><i class="fas fa-tags me-2"></i> Categories</a>
        <a href="orders.php" class="nav-link-admin d-flex justify-content-between">
            <span><i class="fas fa-shopping-cart me-2"></i> Orders</span>
            <?php if($pending_orders > 0): ?> <span class="badge" style="background:#ef4444; color:#fff; border-radius:30px; font-size:0.65rem; padding:3px 8px;"><?= $pending_orders ?></span> <?php endif; ?>
        </a>
        <a href="slider.php" class="nav-link-admin"><i class="fas fa-images me-2"></i> Banners / Sliders</a>
        <a href="reviews.php" class="nav-link-admin"><i class="fas fa-star me-2"></i> Client Reviews</a>
        <a href="pages.php" class="nav-link-admin"><i class="fas fa-file-contract me-2"></i> Legal & Policies</a>
        <a href="users.php" class="nav-link-admin"><i class="fas fa-users me-2"></i> Users</a>
        <a href="settings.php" class="nav-link-admin"><i class="fas fa-sliders me-2"></i> Settings</a>
        <a href="../index.php" target="_blank" class="nav-link-admin" style="color: #60a5fa;"><i class="fas fa-external-link-alt me-2"></i> View Store</a>
        <a href="../logout.php" class="nav-link-admin text-danger mt-4"><i class="fas fa-power-off me-2"></i> Logout</a>
    </div>
    <div class="admin-dev-credit" style="padding:14px 20px;border-top:1px solid rgba(255,255,255,0.06);font-size:0.75rem;color:#64748b;text-align:center;">Developer: <span style="color:#60a5fa;font-weight:700;">Rafi</span></div>
</div>

<!-- ====== Mobile Header ====== -->
<div class="mobile-header d-lg-none">
    <span class="fw-bold text-uppercase" style="font-size:0.9rem; letter-spacing:0.5px;">
        <i class="fas fa-box me-2" style="color: #60a5fa;"></i> Manage Products
    </span>
    <button class="btn text-white fs-4" onclick="toggleMenu()"><i class="fas fa-bars"></i></button>
</div>

<!-- ====== Main Content ====== -->
<div class="main-content">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h4 class="fw-bold mb-0 text-uppercase" style="color: var(--dark-bg); letter-spacing: -0.3px;">
                <i class="fas fa-box me-2" style="color: var(--primary-blue);"></i> Products List
            </h4>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb small">
                    <li class="breadcrumb-item"><a href="dashboard.php"><i class="fas fa-home me-1"></i> Dashboard</a></li>
                    <li class="breadcrumb-item active">Products</li>
                </ol>
            </nav>
        </div>
        <button class="btn-add" data-bs-toggle="modal" data-bs-target="#addModal">
            <i class="fas fa-plus me-2"></i> Add Product
        </button>
    </div>

    <?php if(isset($success)): ?>
        <div class="alert alert-success border-0 shadow-sm rounded-3" style="background: #ecfdf5; border: 1px solid #d1fae5 !important; color: #065f46; font-weight: 700;">
            <i class="fas fa-check-circle me-2"></i> <?= $success ?>
        </div>
    <?php endif; ?>
    
    <?php if(isset($error)): ?>
        <div class="alert alert-danger border-0 shadow-sm rounded-3" style="background: #fef2f2; border: 1px solid #fee2e2 !important; color: #dc2626; font-weight: 700;">
            <i class="fas fa-exclamation-circle me-2"></i> <?= $error ?>
        </div>
    <?php endif; ?>

    <!-- ====== Products Table ====== -->
    <div class="product-card shadow-sm">
        <div class="table-responsive">
            <table class="table align-middle mb-0">
                <thead class="table-light" style="font-weight: 700; font-size: 0.7rem; text-transform: uppercase; letter-spacing: 0.5px;">
                    <tr>
                        <th class="ps-3">Item</th>
                        <th>Category</th>
                        <th>Type</th>
                        <th>Price</th>
                        <th>Files/Links</th>
                        <th>Gallery</th>
                        <th class="text-end pe-3">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $products = $pdo->query("SELECT products.*, categories.name as cat_name FROM products LEFT JOIN categories ON products.category_id = categories.id ORDER BY products.id DESC")->fetchAll();
                    foreach($products as $prod): 
                        $prod_gallery = $all_gallery_images[$prod['id']] ?? [];
                    ?>
                    <tr>
                        <td class="ps-3">
                            <div class="d-flex align-items-center">
                                <img src="../<?= $prod['image'] ?>" class="prod-img me-3">
                                <div>
                                    <div class="fw-bold small" style="font-weight: 700;"><?= htmlspecialchars($prod['title']) ?></div>
                                    <small class="text-muted" style="font-size:11px; font-weight:500;"><i class="fas fa-boxes me-1"></i> Stock: <?= $prod['stock'] ?></small>
                                </div>
                            </div>
                        </td>
                        <td class="small text-muted" style="font-weight: 500;"><?= htmlspecialchars($prod['cat_name']) ?></td>
                        <td><span class="badge" style="background: var(--primary-light); color: var(--primary-blue); font-weight: 700; font-size: 0.6rem; text-transform: uppercase; padding: 4px 12px; border-radius: 30px;"><?= ucfirst($prod['product_type']) ?></span></td>
                        <td class="fw-bold" style="color: var(--primary-blue);">৳<?= number_format($prod['offer_price']) ?></td>
                        <td>
                            <?php if(!empty($prod['file_path'])): ?>
                                <a href="?admin_download=<?= $prod['id'] ?>" class="badge text-white text-decoration-none me-1" style="background: #059669; font-weight: 700; padding: 4px 10px; border-radius: 30px; font-size: 0.65rem;" title="Download ZIP File Asset"><i class="fas fa-file-zipper me-1"></i> ZIP Attached <i class="fas fa-download ms-1"></i></a>
                            <?php else: ?>
                                <span class="badge text-muted" style="background: #f1f5f9; font-size: 0.65rem; border: 1px dashed #cbd5e1;">No File</span>
                            <?php endif; ?>
                            <?php if(!empty($prod['drive_link'])): ?>
                                <a href="<?= htmlspecialchars($prod['drive_link']) ?>" target="_blank" class="badge text-decoration-none text-white ms-1" style="background: #0ea5e9; font-weight: 700; padding: 4px 10px; border-radius: 30px; font-size: 0.65rem;"><i class="fas fa-link me-1"></i> Drive</a>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if(count($prod_gallery) > 0): ?>
                                <span class="badge" style="background: #e0f2fe; color: #0284c7; font-weight: 700; border-radius: 30px; font-size: 0.65rem;">
                                    <i class="fas fa-images me-1"></i> +<?= count($prod_gallery) ?> Photos
                                </span>
                            <?php else: ?>
                                <span class="badge text-muted" style="background: #f8fafc; border: 1px solid #e2e8f0; font-size: 0.65rem;">Single Photo</span>
                            <?php endif; ?>
                        </td>
                        <td class="text-end pe-3">
                            <button class="btn btn-sm btn-outline-primary me-1 edit-btn" 
                                    data-id="<?= $prod['id'] ?>"
                                    data-title="<?= htmlspecialchars($prod['title']) ?>"
                                    data-category="<?= $prod['category_id'] ?>"
                                    data-type="<?= $prod['product_type'] ?>"
                                    data-regular="<?= $prod['regular_price'] ?>"
                                    data-offer="<?= $prod['offer_price'] ?>"
                                    data-stock="<?= $prod['stock'] ?>"
                                    data-variations="<?= htmlspecialchars($prod['variations']) ?>"
                                    data-description="<?= htmlspecialchars($prod['description']) ?>"
                                    data-drive="<?= htmlspecialchars($prod['drive_link']) ?>"
                                    data-file="<?= htmlspecialchars(basename(str_replace('\\', '/', $prod['file_path'] ?? ''))) ?>"
                                    data-hasfile="<?= !empty($prod['file_path']) ? '1' : '0' ?>"
                                    data-gallery='<?= htmlspecialchars(json_encode($prod_gallery), ENT_QUOTES, 'UTF-8') ?>'
                                    data-bs-toggle="modal" data-bs-target="#editModal">
                                <i class="fas fa-edit"></i>
                            </button>
                            <a href="?delete=<?= $prod['id'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('নিশ্চিত তো? ডিলিট করলে এই প্রোডাক্টের আগের সব সেলস হিস্ট্রিও ডাটাবেজ থেকে ক্লিন হয়ে যাবে!')"><i class="fas fa-trash"></i></a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php if(empty($products)): ?>
                        <tr><td colspan="7" class="text-center p-4 text-muted small" style="font-weight: 500;">No products found. Click "Add Product" to create one.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- ====== Add Modal ====== -->
<div class="modal fade" id="addModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <form class="modal-content rounded-4 border-0" method="POST" enctype="multipart/form-data">
            <div class="modal-header border-0 pb-0">
                <h5 class="fw-bold"><i class="fas fa-box-open me-2"></i> Add New Product Asset</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-4">
                <div class="mb-3">
                    <label class="small fw-bold mb-1" style="color: var(--text-slate); text-transform: uppercase; letter-spacing: 0.3px; font-size: 0.7rem;"><i class="fas fa-heading me-1" style="color: var(--primary-blue);"></i> Product Title</label>
                    <input type="text" name="title" class="form-control" required placeholder="e.g. NextGen Premium SMM Panel Website / Adobe Master Collection">
                </div>
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="small fw-bold mb-1" style="color: var(--text-slate); text-transform: uppercase; letter-spacing: 0.3px; font-size: 0.7rem;"><i class="fas fa-tags me-1" style="color: var(--primary-blue);"></i> Category</label>
                        <select name="category_id" class="form-select">
                            <?php foreach($cats as $c) echo "<option value='{$c['id']}'>{$c['name']}</option>"; ?>
                        </select>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="small fw-bold mb-1" style="color: var(--text-slate); text-transform: uppercase; letter-spacing: 0.3px; font-size: 0.7rem;"><i class="fas fa-layer-group me-1" style="color: var(--primary-blue);"></i> Product Type</label>
                        <select name="product_type" class="form-select">
                            <option value="downloadable">📥 Downloadable / Digital ZIP</option>
                            <option value="subscription">🔄 Subscription / Account Delivery</option>
                        </select>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-4 mb-3">
                        <label class="small fw-bold mb-1" style="color: var(--text-slate); text-transform: uppercase; letter-spacing: 0.3px; font-size: 0.7rem;"><i class="fas fa-tag me-1" style="color: var(--primary-blue);"></i> Regular Price</label>
                        <input type="number" name="regular_price" class="form-control" placeholder="৳">
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="small fw-bold mb-1" style="color: var(--text-slate); text-transform: uppercase; letter-spacing: 0.3px; font-size: 0.7rem;"><i class="fas fa-tag me-1" style="color: var(--primary-blue);"></i> Offer Price</label>
                        <input type="number" name="offer_price" class="form-control" placeholder="৳" required>
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="small fw-bold mb-1" style="color: var(--text-slate); text-transform: uppercase; letter-spacing: 0.3px; font-size: 0.7rem;"><i class="fas fa-boxes me-1" style="color: var(--primary-blue);"></i> Stock</label>
                        <input type="number" name="stock" class="form-control" placeholder="Qty" value="1000" required>
                    </div>
                </div>
                <div class="mb-3">
                    <label class="small fw-bold mb-1" style="color: var(--text-slate); text-transform: uppercase; letter-spacing: 0.3px; font-size: 0.7rem;"><i class="fas fa-list me-1" style="color: var(--primary-blue);"></i> Variations (Name:Price)</label>
                    <textarea name="variations" class="form-control" rows="2" placeholder="Monthly License:450&#10;Yearly License:1200"></textarea>
                </div>
                <div class="mb-3">
                    <label class="small fw-bold mb-1" style="color: var(--text-slate); text-transform: uppercase; letter-spacing: 0.3px; font-size: 0.7rem;"><i class="fas fa-align-left me-1" style="color: var(--primary-blue);"></i> Description</label>
                    <textarea name="description" class="form-control" rows="3" placeholder="Product details and instructions..."></textarea>
                </div>
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="small fw-bold mb-1" style="color: var(--text-slate); text-transform: uppercase; letter-spacing: 0.3px; font-size: 0.7rem;"><i class="fas fa-image me-1" style="color: var(--primary-blue);"></i> Main Featured Photo</label>
                        <input type="file" name="image" class="form-control" accept="image/*" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="small fw-bold mb-1" style="color: var(--text-slate); text-transform: uppercase; letter-spacing: 0.3px; font-size: 0.7rem;"><i class="fas fa-file-zipper me-1" style="color: var(--primary-blue);"></i> Digital Product Asset (.ZIP)</label>
                        <input type="file" name="download_file" class="form-control" accept=".zip,.rar,.7z,.tar,.gz,.pdf,.txt,.apk,.iso">
                        <div class="form-text small" style="font-size:11px;">কাস্টমার পেমেন্ট করার পর এই নির্দিষ্ট ZIP ফাইলটি ডাউনলোড করতে পারবে।</div>
                    </div>
                </div>
                <div class="mb-3">
                    <label class="small fw-bold mb-1" style="color: var(--text-slate); text-transform: uppercase; letter-spacing: 0.3px; font-size: 0.7rem;"><i class="fas fa-images me-1" style="color: var(--primary-blue);"></i> Additional Gallery Photos (Multiple Photo Select)</label>
                    <input type="file" name="gallery_images[]" class="form-control" accept="image/*" multiple>
                    <div class="form-text small" style="font-size:11px;">এক সাথে একাধিক ফটো সিলেক্ট করতে পারবেন। প্রোডাক্ট ভিউ পেজে এগুলো থাম্বনেইল গ্যালারি হিসেবে শো করবে।</div>
                </div>
                <div class="mb-2">
                    <label class="small fw-bold mb-1" style="color: var(--text-slate); text-transform: uppercase; letter-spacing: 0.3px; font-size: 0.7rem;"><i class="fas fa-cloud me-1" style="color: var(--primary-blue);"></i> External Cloud / Drive Link (Optional)</label>
                    <input type="url" name="drive_link" class="form-control" placeholder="https://drive.google.com/...">
                </div>
            </div>
            <div class="modal-footer border-0 pt-0">
                <button type="submit" name="add_product" class="btn btn-primary w-100 py-2 rounded-3 fw-bold">Publish Product Asset</button>
            </div>
        </form>
    </div>
</div>

<!-- ====== Edit Modal ====== -->
<div class="modal fade" id="editModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <form class="modal-content rounded-4 border-0" method="POST" enctype="multipart/form-data">
            <input type="hidden" name="product_id" id="edit_id">
            <div class="modal-header border-0 pb-0">
                <h5 class="fw-bold"><i class="fas fa-edit me-2" style="color: var(--primary-blue);"></i> Edit Product Asset</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-4">
                <div class="mb-3">
                    <label class="small fw-bold mb-1" style="color: var(--text-slate); text-transform: uppercase; letter-spacing: 0.3px; font-size: 0.7rem;"><i class="fas fa-heading me-1" style="color: var(--primary-blue);"></i> Product Title</label>
                    <input type="text" name="title" id="edit_title" class="form-control" required>
                </div>
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="small fw-bold mb-1" style="color: var(--text-slate); text-transform: uppercase; letter-spacing: 0.3px; font-size: 0.7rem;"><i class="fas fa-tags me-1" style="color: var(--primary-blue);"></i> Category</label>
                        <select name="category_id" id="edit_category" class="form-select">
                            <?php foreach($cats as $c) echo "<option value='{$c['id']}'>{$c['name']}</option>"; ?>
                        </select>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="small fw-bold mb-1" style="color: var(--text-slate); text-transform: uppercase; letter-spacing: 0.3px; font-size: 0.7rem;"><i class="fas fa-layer-group me-1" style="color: var(--primary-blue);"></i> Product Type</label>
                        <select name="product_type" id="edit_type" class="form-select">
                            <option value="downloadable">📥 Downloadable / Digital ZIP</option>
                            <option value="subscription">🔄 Subscription / Account Delivery</option>
                        </select>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-4 mb-3">
                        <label class="small fw-bold mb-1" style="color: var(--text-slate); text-transform: uppercase; letter-spacing: 0.3px; font-size: 0.7rem;"><i class="fas fa-tag me-1" style="color: var(--primary-blue);"></i> Regular Price</label>
                        <input type="number" name="regular_price" id="edit_regular" class="form-control">
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="small fw-bold mb-1" style="color: var(--text-slate); text-transform: uppercase; letter-spacing: 0.3px; font-size: 0.7rem;"><i class="fas fa-tag me-1" style="color: var(--primary-blue);"></i> Offer Price</label>
                        <input type="number" name="offer_price" id="edit_offer" class="form-control" required>
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="small fw-bold mb-1" style="color: var(--text-slate); text-transform: uppercase; letter-spacing: 0.3px; font-size: 0.7rem;"><i class="fas fa-boxes me-1" style="color: var(--primary-blue);"></i> Stock</label>
                        <input type="number" name="stock" id="edit_stock" class="form-control" required>
                    </div>
                </div>
                <div class="mb-3">
                    <label class="small fw-bold mb-1" style="color: var(--text-slate); text-transform: uppercase; letter-spacing: 0.3px; font-size: 0.7rem;"><i class="fas fa-list me-1" style="color: var(--primary-blue);"></i> Variations</label>
                    <textarea name="variations" id="edit_variations" class="form-control" rows="2"></textarea>
                </div>
                <div class="mb-3">
                    <label class="small fw-bold mb-1" style="color: var(--text-slate); text-transform: uppercase; letter-spacing: 0.3px; font-size: 0.7rem;"><i class="fas fa-align-left me-1" style="color: var(--primary-blue);"></i> Description</label>
                    <textarea name="description" id="edit_description" class="form-control" rows="3"></textarea>
                </div>
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="small fw-bold mb-1" style="color: var(--text-slate); text-transform: uppercase; letter-spacing: 0.3px; font-size: 0.7rem;"><i class="fas fa-image me-1" style="color: var(--primary-blue);"></i> Replace Main Thumbnail <small class="text-muted">(Optional)</small></label>
                        <input type="file" name="image" class="form-control" accept="image/*">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="small fw-bold mb-1" style="color: var(--text-slate); text-transform: uppercase; letter-spacing: 0.3px; font-size: 0.7rem;"><i class="fas fa-file-zipper me-1" style="color: var(--primary-blue);"></i> Digital Product Asset (.ZIP) <small class="text-muted">(Optional)</small></label>
                        <div id="edit_file_info" class="mb-2 small" style="display:none;">
                            <span class="badge" style="background: #ecfdf5; color: #065f46; border: 1px solid #a7f3d0; padding: 5px 10px; border-radius: 8px;">
                                <i class="fas fa-file-zipper me-1"></i> Current File: <strong id="edit_current_filename">None</strong>
                            </span>
                            <a href="#" id="edit_file_download_link" class="btn btn-sm btn-outline-primary ms-1 py-0 px-2" style="font-size: 0.75rem;"><i class="fas fa-download"></i> Test Download</a>
                        </div>
                        <input type="file" name="download_file" class="form-control" accept=".zip,.rar,.7z,.tar,.gz,.pdf,.txt,.apk,.iso">
                        <div class="form-text small" style="font-size:11px;">নতুন ZIP ফাইল দিলে আগের ফাইলটি রিপ্লেস হয়ে যাবে।</div>
                    </div>
                </div>

                <!-- Gallery Manager in Edit Modal -->
                <div class="mb-3">
                    <label class="small fw-bold mb-1" style="color: var(--text-slate); text-transform: uppercase; letter-spacing: 0.3px; font-size: 0.7rem;"><i class="fas fa-images me-1" style="color: var(--primary-blue);"></i> Current Gallery Photos</label>
                    <div id="edit_gallery_preview" class="d-flex flex-wrap gap-2 p-2 rounded-3" style="background: #f8fafc; border: 1px dashed var(--border-color); min-height: 50px;">
                        <span class="text-muted small p-2">No extra gallery photos uploaded yet.</span>
                    </div>
                </div>

                <div class="mb-3">
                    <label class="small fw-bold mb-1" style="color: var(--text-slate); text-transform: uppercase; letter-spacing: 0.3px; font-size: 0.7rem;"><i class="fas fa-plus-circle me-1" style="color: var(--primary-blue);"></i> Upload More Gallery Photos</label>
                    <input type="file" name="gallery_images[]" class="form-control" accept="image/*" multiple>
                    <div class="form-text small" style="font-size:11px;">একাধিক নতুন ফটো সিলেক্ট করে সেভ করলে সেগুলো গ্যালারিতে যোগ হয়ে যাবে।</div>
                </div>

                <div class="mb-2">
                    <label class="small fw-bold mb-1" style="color: var(--text-slate); text-transform: uppercase; letter-spacing: 0.3px; font-size: 0.7rem;"><i class="fas fa-cloud me-1" style="color: var(--primary-blue);"></i> External Cloud / Drive Link</label>
                    <input type="url" name="drive_link" id="edit_drive" class="form-control" placeholder="https://drive.google.com/...">
                </div>
            </div>
            <div class="modal-footer border-0 pt-0">
                <button type="submit" name="update_product" class="btn btn-primary w-100 py-2 rounded-3 fw-bold">Save Changes</button>
            </div>
        </form>
    </div>
</div>

<!-- ====== JavaScript ====== -->
<script>
    function toggleMenu() {
        document.getElementById('adminSidebar').classList.toggle('active');
        document.getElementById('overlay').classList.toggle('show');
    }

    document.querySelectorAll('.edit-btn').forEach(button => {
        button.addEventListener('click', function() {
            const id = this.getAttribute('data-id');
            document.getElementById('edit_id').value = id;
            document.getElementById('edit_title').value = this.getAttribute('data-title');
            document.getElementById('edit_category').value = this.getAttribute('data-category');
            document.getElementById('edit_type').value = this.getAttribute('data-type');
            document.getElementById('edit_regular').value = this.getAttribute('data-regular');
            document.getElementById('edit_offer').value = this.getAttribute('data-offer');
            document.getElementById('edit_stock').value = this.getAttribute('data-stock');
            document.getElementById('edit_variations').value = this.getAttribute('data-variations');
            document.getElementById('edit_description').value = this.getAttribute('data-description');
            document.getElementById('edit_drive').value = this.getAttribute('data-drive');

            const fileName = this.getAttribute('data-file');
            const hasFile = this.getAttribute('data-hasfile') === '1';
            const fileInfo = document.getElementById('edit_file_info');
            const currentName = document.getElementById('edit_current_filename');
            const dlLink = document.getElementById('edit_file_download_link');
            if (hasFile && fileName) {
                fileInfo.style.display = 'block';
                currentName.textContent = fileName;
                dlLink.href = '?admin_download=' + id;
            } else {
                fileInfo.style.display = 'none';
            }

            // Render current gallery images
            const galleryPreview = document.getElementById('edit_gallery_preview');
            const galleryJson = this.getAttribute('data-gallery');
            try {
                const gallery = JSON.parse(galleryJson || '[]');
                if (gallery && gallery.length > 0) {
                    galleryPreview.innerHTML = '';
                    gallery.forEach(img => {
                        const item = document.createElement('div');
                        item.className = 'position-relative d-inline-block';
                        item.innerHTML = `
                            <img src="../${img.image}" style="width:70px; height:70px; object-fit:cover; border-radius:10px; border:2px solid #cbd5e1;">
                            <a href="?delete_gallery_img=${img.id}" onclick="return confirm('এই ফটোটি মুছে ফেলতে চান?')" 
                               class="position-absolute top-0 end-0 bg-danger text-white rounded-circle d-flex align-items-center justify-content-center" 
                               style="width:20px; height:20px; font-size:10px; transform:translate(30%, -30%); text-decoration:none;" title="Delete Photo">
                                <i class="fas fa-times"></i>
                            </a>
                        `;
                        galleryPreview.appendChild(item);
                    });
                } else {
                    galleryPreview.innerHTML = '<span class="text-muted small p-2">No extra gallery photos uploaded yet.</span>';
                }
            } catch (e) {
                galleryPreview.innerHTML = '<span class="text-muted small p-2">No extra gallery photos uploaded yet.</span>';
            }
        });
    });
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="../assets/js/premium.js"></script>
</body>
</html>