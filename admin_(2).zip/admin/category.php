<?php
include '../config.php';

// Security Check
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

// Add Category
if(isset($_POST['add_cat'])) {
    $name = $_POST['cat_name'];
    $pdo->prepare("INSERT INTO categories (name) VALUES (?)")->execute([$name]);
    $success = "Category added successfully!";
}

// Delete Category
if(isset($_GET['delete'])) {
    $pdo->prepare("DELETE FROM categories WHERE id = ?")->execute([$_GET['delete']]);
    header("Location: category.php");
    exit();
}

// Statistics for Sidebar
$pending_orders = $pdo->query("SELECT COUNT(*) FROM orders WHERE status = 'Pending'")->fetchColumn();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Categories | Admin</title>
    
    <!-- ====== ফন্ট: Inter ====== -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/premium-theme.css">
    <link rel="stylesheet" href="../assets/css/jx-toast.css">
    <script src="../assets/js/jx-toast.js"></script>
    
    <style>
        /* ==========================================
           ✅ ADMIN CATEGORIES UPDATED: 11 August 2026
           📌 নীল থিম (#1e2ab8)
        ========================================== */
        
        :root {
            --primary-blue: #1e2ab8;
            --primary-gradient: linear-gradient(135deg, #1e2ab8 0%, #4338ca 100%);
            --primary-hover: #0f172a;
            --primary-light: #e0e7ff;
            --sidebar-w: 260px;
            --dark-bg: #0f172a;
            --border-color: #e2e8f0;
            --text-slate: #64748b;
        }

        /* ডার্ক মোড অটো */
        @media (prefers-color-scheme: dark) {
            :root {
                --dark-bg: #0f172a;
                --border-color: #334155;
                --text-slate: #94a3b8;
            }
            body { background: #0f172a; }
            .card-custom { background: #1e293b; border-color: #334155; }
            .card-custom .bg-white { background: #1e293b !important; border-color: #334155 !important; }
            .card-custom .table-light { background: #0f172a; }
            .card-custom .table-light th { color: #94a3b8; }
            .card-custom td { color: #e2e8f0; border-color: #334155; }
            .card-custom .text-muted { color: #94a3b8 !important; }
            .form-control { background: #0f172a; color: #e2e8f0; border-color: #334155; }
            .form-control:focus { background: #1e293b; border-color: #60a5fa; box-shadow: 0 0 0 3px rgba(30, 42, 184, 0.15); }
            .form-control::placeholder { color: #64748b; }
            .breadcrumb-item a { color: #94a3b8; }
            .breadcrumb-item.active { color: #60a5fa; }
        }

        * { font-style: normal !important; }
        
        body { 
            font-family: 'Inter', sans-serif; 
            background: #f1f5f9; 
            margin: 0; 
        }

        /* ====== Sidebar ====== */
        .sidebar { 
            height: 100vh; 
            background: var(--dark-bg); 
            position: fixed; 
            width: var(--sidebar-w); 
            z-index: 1050; 
            transition: 0.3s; 
        }
        
        .sidebar-brand { 
            padding: 25px; 
            border-bottom: 1px solid rgba(255,255,255,0.08); 
            color: #fff; 
            font-weight: 900; 
            font-size: 1.1rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .sidebar-brand i {
            color: #60a5fa;
        }
        
        .nav-link-admin { 
            padding: 14px 25px; 
            display: block; 
            color: #94a3b8; 
            text-decoration: none; 
            transition: 0.3s; 
            font-weight: 700; 
            border-left: 4px solid transparent;
            font-size: 0.85rem;
            text-transform: uppercase;
            letter-spacing: 0.3px;
        }
        
        .nav-link-admin:hover, 
        .nav-link-admin.active { 
            background: rgba(30, 42, 184, 0.1); 
            color: #fff; 
            border-left-color: var(--primary-blue); 
        }
        
        .nav-link-admin i {
            color: #60a5fa;
            width: 20px;
        }
        
        .nav-link-admin.active i {
            color: #93bbfc;
        }
        
        .nav-link-admin .badge {
            background: #ef4444;
            color: #fff;
            font-size: 0.65rem;
            padding: 2px 10px;
        }

        /* ====== Main Content ====== */
        .main-content { 
            margin-left: var(--sidebar-w); 
            padding: 30px; 
            transition: 0.3s; 
        }
        
        .mobile-header { 
            display: none; 
            background: var(--dark-bg); 
            color: white; 
            padding: 15px 20px; 
            position: sticky; 
            top: 0; 
            z-index: 1000; 
        }

        /* ====== Cards ====== */
        .card-custom { 
            background: #fff; 
            border-radius: 20px; 
            border: 1px solid var(--border-color); 
            box-shadow: 0 5px 15px rgba(30, 42, 184, 0.02); 
        }
        
        .card-custom .bg-white {
            background: #fff !important;
            border-radius: 20px 20px 0 0;
        }

        /* ====== বাটন (নীল) ====== */
        .btn-blue { 
            background: var(--primary-gradient); 
            color: white; 
            border-radius: 12px; 
            font-weight: 700; 
            border: none; 
            transition: 0.3s;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            font-size: 0.8rem;
            padding: 10px;
        }
        .btn-blue:hover { 
            background: var(--primary-hover); 
            transform: translateY(-2px); 
            color: white; 
            box-shadow: 0 8px 25px rgba(30, 42, 184, 0.3); 
        }

        /* ====== Form Controls ====== */
        .form-control { 
            border-radius: 10px; 
            padding: 10px 15px; 
            border: 2px solid var(--border-color); 
            font-size: 0.9rem;
            font-weight: 600;
            transition: all 0.3s ease;
            background: #fff;
            color: var(--dark-bg);
        }
        
        .form-control:focus { 
            box-shadow: 0 0 0 3px rgba(30, 42, 184, 0.1); 
            border-color: var(--primary-blue); 
        }

        /* ====== Delete Button ====== */
        .btn-outline-danger {
            font-weight: 700;
            border-color: #fee2e2;
            color: #ef4444;
        }
        .btn-outline-danger:hover {
            background: #ef4444;
            color: #fff;
            border-color: #ef4444;
        }

        /* ====== রেসপনসিভ ====== */
        @media (max-width: 992px) {
            .sidebar { transform: translateX(-100%); }
            .sidebar.active { transform: translateX(0); }
            .main-content { margin-left: 0; padding: 20px; }
            .mobile-header { display: flex; justify-content: space-between; align-items: center; }
        }
        
        @media (max-width: 480px) {
            .main-content { padding: 12px; }
            .card-custom { border-radius: 14px; }
            .card-custom .bg-white { border-radius: 14px 14px 0 0; }
            .btn-blue { font-size: 0.7rem; padding: 8px; }
        }
        
        .sidebar-overlay { 
            display: none; 
            position: fixed; 
            inset: 0; 
            background: rgba(0,0,0,0.5); 
            z-index: 1040; 
        }
        .sidebar-overlay.show { display: block; }
        
        .breadcrumb-item a {
            color: var(--text-slate);
            text-decoration: none;
            font-weight: 600;
        }
        .breadcrumb-item a:hover {
            color: var(--primary-blue);
        }
        .breadcrumb-item.active {
            color: var(--primary-blue);
            font-weight: 700;
        }
        
        .alert-success {
            background: #ecfdf5;
            border: 1px solid #d1fae5;
            color: #065f46;
            font-weight: 700;
            border-radius: 14px;
        }
        .alert-success i {
            color: #059669;
        }
    </style>
</head>
<body>

<div class="sidebar-overlay" id="overlay" onclick="toggleMenu()"></div>

<!-- ====== Sidebar ====== -->
<div class="sidebar" id="adminSidebar">
    <div class="sidebar-brand d-flex align-items-center justify-content-between">
        <span><i class="fas fa-bolt me-2"></i> Admin Panel</span>
        <button class="btn text-white d-lg-none" onclick="toggleMenu()"><i class="fas fa-times"></i></button>
    </div>
    <div class="mt-3">
        <a href="dashboard.php" class="nav-link-admin"><i class="fas fa-chart-pie me-2"></i> Dashboard</a>
        <a href="product.php" class="nav-link-admin"><i class="fas fa-box me-2"></i> Products</a>
        <a href="category.php" class="nav-link-admin active"><i class="fas fa-tags me-2"></i> Categories</a>
        <a href="orders.php" class="nav-link-admin d-flex justify-content-between">
            <span><i class="fas fa-shopping-cart me-2"></i> Orders</span>
            <?php if($pending_orders > 0): ?> <span class="badge" style="background:#ef4444;color:#fff;border-radius:30px;padding:3px 8px;font-size:0.65rem;"><?= $pending_orders ?></span> <?php endif; ?>
        </a>
        <a href="slider.php" class="nav-link-admin"><i class="fas fa-images me-2"></i> Banners / Sliders</a>
        <a href="reviews.php" class="nav-link-admin"><i class="fas fa-star me-2"></i> Client Reviews</a>
        <a href="pages.php" class="nav-link-admin"><i class="fas fa-file-contract me-2"></i> Legal & Policies</a>
        <a href="users.php" class="nav-link-admin"><i class="fas fa-users me-2"></i> Users</a>
        <a href="settings.php" class="nav-link-admin"><i class="fas fa-sliders me-2"></i> Settings</a>
        <a href="../index.php" target="_blank" class="nav-link-admin" style="color: #60a5fa;"><i class="fas fa-external-link-alt me-2"></i> View Store</a>
        <a href="../logout.php" class="nav-link-admin text-danger mt-4"><i class="fas fa-power-off me-2"></i> Logout</a>
    </div>
    <div class="admin-dev-credit" style="padding:14px 20px;border-top:1px solid rgba(255,255,255,0.06);font-size:0.75rem;color:#64748b;text-align:center;">Developer: <span style="color:#60a5fa;font-weight:700;">Rafi</span></div>
</div>

<!-- ====== Mobile Header ====== -->
<div class="mobile-header d-lg-none">
    <span class="fw-bold text-uppercase" style="font-size:0.9rem; letter-spacing:0.5px;">
        <i class="fas fa-tags me-2" style="color: #60a5fa;"></i> Categories
    </span>
    <button class="btn text-white fs-4" onclick="toggleMenu()"><i class="fas fa-bars"></i></button>
</div>

<!-- ====== Main Content ====== -->
<div class="main-content">
    <div class="mb-4">
        <h4 class="fw-bold mb-0 text-uppercase" style="color: var(--dark-bg); letter-spacing: -0.3px;">
            <i class="fas fa-tags me-2" style="color: var(--primary-blue);"></i> Manage Categories
        </h4>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb small">
                <li class="breadcrumb-item"><a href="dashboard.php"><i class="fas fa-home me-1"></i> Dashboard</a></li>
                <li class="breadcrumb-item active">Categories</li>
            </ol>
        </nav>
    </div>

    <?php if(isset($success)): ?>
        <div class="alert alert-success rounded-3 small">
            <i class="fas fa-check-circle me-2"></i> <?= $success ?>
        </div>
    <?php endif; ?>

    <div class="row g-4">
        <!-- ====== Add Category Form ====== -->
        <div class="col-lg-4">
            <div class="card card-custom p-4">
                <h6 class="fw-bold mb-3 text-uppercase" style="color: var(--dark-bg); letter-spacing: 0.5px; font-size: 0.8rem;">
                    <i class="fas fa-plus-circle me-2" style="color: var(--primary-blue);"></i> Add New Category
                </h6>
                <form method="POST">
                    <div class="mb-3">
                        <label class="small fw-bold mb-1" style="color: var(--text-slate); text-transform: uppercase; letter-spacing: 0.3px; font-size: 0.7rem;">
                            <i class="fas fa-tag me-1" style="color: var(--primary-blue);"></i> Category Name
                        </label>
                        <input type="text" name="cat_name" class="form-control rounded-3" placeholder="e.g. Free Fire" required>
                    </div>
                    <button name="add_cat" class="btn btn-blue w-100 py-2">
                        <i class="fas fa-save me-2"></i> Save Category
                    </button>
                </form>
            </div>
        </div>

        <!-- ====== Categories List ====== -->
        <div class="col-lg-8">
            <div class="card card-custom overflow-hidden">
                <div class="p-3 bg-white border-bottom">
                    <h6 class="fw-bold mb-0 text-uppercase" style="color: var(--dark-bg); letter-spacing: 0.5px; font-size: 0.8rem;">
                        <i class="fas fa-list me-2" style="color: var(--primary-blue);"></i> All Categories
                    </h6>
                </div>
                <div class="table-responsive">
                    <table class="table align-middle mb-0">
                        <thead class="table-light" style="font-weight: 700; font-size: 0.7rem; text-transform: uppercase; letter-spacing: 0.5px;">
                            <tr>
                                <th class="ps-3" style="width: 80px;">ID</th>
                                <th>Category Name</th>
                                <th class="text-end pe-3">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            $cats = $pdo->query("SELECT * FROM categories ORDER BY id DESC")->fetchAll();
                            foreach($cats as $c): ?>
                            <tr>
                                <td class="ps-3 text-muted small" style="font-weight: 600;">#<?= $c['id'] ?></td>
                                <td class="fw-bold small" style="font-weight: 700;"><?= htmlspecialchars($c['name']) ?></td>
                                <td class="text-end pe-3">
                                    <a href="?delete=<?= $c['id'] ?>" class="btn btn-sm btn-outline-danger border-0" onclick="return confirm('Delete this category?')">
                                        <i class="fas fa-trash-alt"></i>
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                            <?php if(empty($cats)): ?>
                                <tr><td colspan="3" class="text-center p-4 text-muted small" style="font-weight: 500;">No categories found.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- ====== JavaScript ====== -->
<script>
    function toggleMenu() {
        document.getElementById('adminSidebar').classList.toggle('active');
        document.getElementById('overlay').classList.toggle('show');
    }
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="../assets/js/premium.js"></script>
</body>
</html>