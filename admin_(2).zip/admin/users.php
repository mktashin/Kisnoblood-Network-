<?php
include '../config.php';

// Security Check
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

$success = null;
$error = null;

// Handle Delete User
if (isset($_GET['delete_user'])) {
    $uid = (int)$_GET['delete_user'];
    if ($uid === (int)$_SESSION['user_id']) {
        $error = "You cannot delete your own logged-in admin account!";
    } else {
        $pdo->prepare("DELETE FROM users WHERE id = ?")->execute([$uid]);
        $success = "User #{$uid} deleted successfully.";
    }
}

// Handle Role Toggle
if (isset($_GET['toggle_role']) && isset($_GET['id'])) {
    $uid = (int)$_GET['id'];
    $new_role = $_GET['toggle_role'] === 'admin' ? 'admin' : 'user';
    if ($uid === (int)$_SESSION['user_id'] && $new_role === 'user') {
        $error = "You cannot demote your own admin account!";
    } else {
        $pdo->prepare("UPDATE users SET role = ? WHERE id = ?")->execute([$new_role, $uid]);
        $success = "User #{$uid} role updated to {$new_role}.";
    }
}

// Fetch All Registered Users with their order counts
$users = $pdo->query("SELECT users.*, COUNT(orders.id) as order_count 
                      FROM users 
                      LEFT JOIN orders ON users.id = orders.user_id 
                      GROUP BY users.id 
                      ORDER BY users.id DESC")->fetchAll();

// Statistics for Sidebar
$pending_count = $pdo->query("SELECT COUNT(*) FROM orders WHERE status = 'Pending'")->fetchColumn();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Users | Admin Panel</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        :root {
            --primary-blue: #1e2ab8;
            --primary-gradient: linear-gradient(135deg, #1e2ab8 0%, #4338ca 100%);
            --primary-hover: #0f172a;
            --sidebar-w: 260px;
            --dark-bg: #0f172a;
            --border-color: #e2e8f0;
            --text-slate: #64748b;
            --text-dark: #1e293b;
            --card-bg: #ffffff;
            --shadow: 0 5px 15px rgba(30, 42, 184, 0.04);
            --radius: 20px;
        }

        @media (prefers-color-scheme: dark) {
            :root {
                --dark-bg: #0f172a;
                --card-bg: #1e293b;
                --border-color: #334155;
                --text-slate: #94a3b8;
                --text-dark: #e2e8f0;
            }
            body { background: #0f172a; }
            .user-card { background: #1e293b; border-color: #334155; }
            .avatar-circle { background: #0f172a; color: #60a5fa; }
        }

        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Inter', sans-serif; font-style: normal !important; }
        body { background: #f1f5f9; color: var(--text-dark); min-height: 100vh; overflow-x: hidden; }

        .sidebar {
            height: 100vh;
            background: var(--dark-bg);
            position: fixed;
            width: var(--sidebar-w);
            z-index: 1050;
            transition: 0.3s;
            overflow-y: auto;
            border-right: 1px solid rgba(255, 255, 255, 0.05);
        }
        .sidebar-brand {
            padding: 20px 24px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.06);
            color: #fff;
            font-weight: 900;
            font-size: 1.1rem;
            display: flex;
            align-items: center;
            justify-content: space-between;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        .sidebar-brand .close-btn { background: none; border: none; color: #94a3b8; font-size: 1.2rem; cursor: pointer; display: none; }

        .nav-link-admin {
            padding: 12px 24px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            color: #94a3b8;
            text-decoration: none;
            font-weight: 700;
            font-size: 0.84rem;
            transition: all 0.2s ease;
            border-left: 4px solid transparent;
            text-transform: uppercase;
            letter-spacing: 0.3px;
        }
        .nav-link-admin:hover,
        .nav-link-admin.active {
            color: #fff;
            background: rgba(30, 42, 184, 0.15);
            border-left-color: var(--primary-blue);
        }
        .nav-link-admin i { width: 22px; font-size: 1rem; margin-right: 8px; }

        .main-content {
            margin-left: var(--sidebar-w);
            padding: 28px 32px;
            min-height: 100vh;
            transition: 0.3s;
        }
        .user-card {
            background: var(--card-bg);
            border-radius: var(--radius);
            box-shadow: var(--shadow);
            border: 1px solid var(--border-color);
            overflow: hidden;
        }
        .avatar-circle {
            width: 40px;
            height: 40px;
            background: #e0e7ff;
            color: var(--primary-blue);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 900;
            font-size: 15px;
        }

        @media (max-width: 992px) {
            .sidebar { transform: translateX(-100%); }
            .sidebar.active { transform: translateX(0); }
            .main-content { margin-left: 0; padding: 18px; }
            .sidebar-brand .close-btn { display: block; }
        }
    </style>
</head>
<body>

<div class="sidebar" id="adminSidebar">
    <div class="sidebar-brand">
        <span><i class="fas fa-bolt me-2 text-warning"></i> Admin Panel</span>
        <button class="close-btn" onclick="toggleMenu()"><i class="fas fa-times"></i></button>
    </div>
    <div class="mt-3">
        <a href="dashboard.php" class="nav-link-admin"><i class="fas fa-chart-pie"></i> <span>Dashboard</span></a>
        <a href="product.php" class="nav-link-admin"><i class="fas fa-box"></i> <span>Products</span></a>
        <a href="category.php" class="nav-link-admin"><i class="fas fa-tags"></i> <span>Categories</span></a>
        <a href="orders.php" class="nav-link-admin">
            <span><i class="fas fa-shopping-cart"></i> Orders</span>
            <?php if($pending_count > 0): ?> <span class="badge bg-danger rounded-pill"><?= $pending_count ?></span> <?php endif; ?>
        </a>
        <a href="slider.php" class="nav-link-admin"><i class="fas fa-images"></i> <span>Banners / Sliders</span></a>
        <a href="reviews.php" class="nav-link-admin"><i class="fas fa-star"></i> <span>Client Reviews</span></a>
        <a href="pages.php" class="nav-link-admin"><i class="fas fa-file-contract"></i> <span>Legal & Policies</span></a>
        <a href="users.php" class="nav-link-admin active"><i class="fas fa-users"></i> <span>Users</span></a>
        <a href="settings.php" class="nav-link-admin"><i class="fas fa-sliders"></i> <span>Settings</span></a>
        <a href="../index.php" target="_blank" class="nav-link-admin" style="color: #60a5fa;"><i class="fas fa-external-link-alt"></i> <span>View Store</span></a>
        <a href="../logout.php" class="nav-link-admin text-danger mt-4"><i class="fas fa-power-off"></i> <span>Logout</span></a>
    </div>
    <div class="admin-dev-credit" style="padding:14px 20px;border-top:1px solid rgba(255,255,255,0.06);font-size:0.75rem;color:#64748b;text-align:center;margin-top:auto;">Developer: <span style="color:#60a5fa;font-weight:700;">Rafi</span></div>
</div>

<div class="main-content">
    <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
        <div>
            <h4 class="fw-bold mb-1" style="color: var(--text-dark);"><i class="fas fa-users me-2 text-primary"></i> Registered Customers & Users</h4>
            <p class="text-muted small mb-0">Total active users and account management.</p>
        </div>
        <div class="badge bg-primary rounded-pill px-3 py-2 fs-6"><?= count($users) ?> Total Accounts</div>
    </div>

    <?php if(!empty($success)): ?>
        <div class="alert alert-success border-0 shadow-sm rounded-4 mb-4 py-3 d-flex align-items-center gap-2">
            <i class="fas fa-check-circle fs-5"></i>
            <div><?= htmlspecialchars($success) ?></div>
        </div>
    <?php endif; ?>

    <?php if(!empty($error)): ?>
        <div class="alert alert-danger border-0 shadow-sm rounded-4 mb-4 py-3 d-flex align-items-center gap-2">
            <i class="fas fa-exclamation-triangle fs-5"></i>
            <div><?= htmlspecialchars($error) ?></div>
        </div>
    <?php endif; ?>

    <div class="user-card shadow-sm">
        <div class="table-responsive">
            <table class="table align-middle mb-0">
                <thead class="table-light">
                    <tr class="small text-uppercase" style="font-size: 0.72rem; letter-spacing: 0.5px;">
                        <th class="ps-3 py-3">User Details</th>
                        <th>WhatsApp / Phone</th>
                        <th>Role</th>
                        <th>Orders</th>
                        <th>Joined Date</th>
                        <th class="text-end pe-3">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($users as $u): ?>
                    <tr>
                        <td class="ps-3">
                            <div class="d-flex align-items-center">
                                <div class="avatar-circle me-3">
                                    <?= strtoupper(substr($u['name'] ?: 'U', 0, 1)) ?>
                                </div>
                                <div>
                                    <div class="fw-bold small"><?= htmlspecialchars($u['name']) ?></div>
                                    <div class="text-muted" style="font-size: 11px;"><?= htmlspecialchars($u['email']) ?></div>
                                </div>
                            </div>
                        </td>
                        <td class="small fw-bold">
                            <?php if(!empty($u['whatsapp'])): ?>
                                <a href="https://wa.me/<?= preg_replace('/[^0-9]/', '', $u['whatsapp']) ?>" target="_blank" class="text-decoration-none text-success">
                                    <i class="fab fa-whatsapp me-1"></i> <?= htmlspecialchars($u['whatsapp']) ?>
                                </a>
                            <?php else: ?>
                                <span class="text-muted">N/A</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($u['role'] === 'admin'): ?>
                                <span class="badge bg-danger rounded-pill px-2">ADMIN</span>
                            <?php else: ?>
                                <span class="badge bg-secondary rounded-pill px-2">USER</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <span class="badge rounded-pill bg-light text-dark border px-2">
                                <?= (int)$u['order_count'] ?> Orders
                            </span>
                        </td>
                        <td class="text-muted small"><?= date('d M, Y', strtotime($u['created_at'])) ?></td>
                        <td class="text-end pe-3">
                            <div class="d-inline-flex gap-1 align-items-center">
                                <?php if($u['role'] === 'user'): ?>
                                    <a href="?toggle_role=admin&id=<?= $u['id'] ?>" class="btn btn-sm btn-outline-primary py-0 px-2" title="Promote to Admin" style="font-size:0.75rem;" onclick="return confirm('Promote this user to Admin?');">
                                        Make Admin
                                    </a>
                                <?php else: ?>
                                    <a href="?toggle_role=user&id=<?= $u['id'] ?>" class="btn btn-sm btn-outline-secondary py-0 px-2" title="Demote to User" style="font-size:0.75rem;" onclick="return confirm('Demote this admin to user?');">
                                        Demote
                                    </a>
                                <?php endif; ?>
                                <a href="?delete_user=<?= $u['id'] ?>" class="btn btn-sm btn-outline-danger py-0 px-2" title="Delete User" style="font-size:0.75rem;" onclick="return confirm('Delete this user account?');">
                                    <i class="fas fa-trash"></i>
                                </a>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    
                    <?php if(empty($users)): ?>
                        <tr><td colspan="6" class="text-center p-5 text-muted">No users found.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
function toggleMenu() {
    document.getElementById('adminSidebar').classList.toggle('active');
}
</script>
</body>
</html>