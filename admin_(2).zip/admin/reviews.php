<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include '../config.php';

// Security Check
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

$success = null;
$error = null;

// Handle Add Review
if (isset($_POST['add_review'])) {
    $name = trim($_POST['name'] ?? '');
    $title = trim($_POST['title'] ?? 'Verified Order');
    $comment = trim($_POST['comment'] ?? '');
    $rating = (float)($_POST['rating'] ?? 5.0);
    $is_verified = isset($_POST['is_verified']) ? 1 : 0;
    $status = (int)($_POST['status'] ?? 1);
    $sort_order = (int)($_POST['sort_order'] ?? 0);

    $avatar_path = null;
    if (!empty($_FILES['avatar']['name'])) {
        $upload_dir = dirname(__DIR__) . '/uploads/';
        if (!is_dir($upload_dir)) @mkdir($upload_dir, 0755, true);
        $ext = strtolower(pathinfo($_FILES['avatar']['name'], PATHINFO_EXTENSION));
        if (in_array($ext, ['jpg', 'jpeg', 'png', 'webp', 'gif', 'svg'])) {
            $filename = 'rev_' . time() . '.' . $ext;
            if (move_uploaded_file($_FILES['avatar']['tmp_name'], $upload_dir . $filename)) {
                $avatar_path = 'uploads/' . $filename;
            }
        }
    }

    if (!empty($name) && !empty($comment)) {
        $stmt = $pdo->prepare("INSERT INTO reviews (name, title, comment, rating, is_verified, avatar, status, sort_order) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([$name, $title, $comment, $rating, $is_verified, $avatar_path, $status, $sort_order]);
        $success = "Review added successfully!";
    } else {
        $error = "Client name and review comment are required!";
    }
}

// Handle Update Review
if (isset($_POST['update_review'])) {
    $id = (int)$_POST['review_id'];
    $name = trim($_POST['name'] ?? '');
    $title = trim($_POST['title'] ?? 'Verified Order');
    $comment = trim($_POST['comment'] ?? '');
    $rating = (float)($_POST['rating'] ?? 5.0);
    $is_verified = isset($_POST['is_verified']) ? 1 : 0;
    $status = (int)($_POST['status'] ?? 1);
    $sort_order = (int)($_POST['sort_order'] ?? 0);

    $stmt = $pdo->prepare("SELECT avatar FROM reviews WHERE id = ?");
    $stmt->execute([$id]);
    $current = $stmt->fetch();
    $avatar_path = $current['avatar'] ?? null;

    if (!empty($_FILES['avatar']['name'])) {
        $upload_dir = dirname(__DIR__) . '/uploads/';
        if (!is_dir($upload_dir)) @mkdir($upload_dir, 0755, true);
        $ext = strtolower(pathinfo($_FILES['avatar']['name'], PATHINFO_EXTENSION));
        if (in_array($ext, ['jpg', 'jpeg', 'png', 'webp', 'gif', 'svg'])) {
            $filename = 'rev_' . time() . '.' . $ext;
            if (move_uploaded_file($_FILES['avatar']['tmp_name'], $upload_dir . $filename)) {
                $avatar_path = 'uploads/' . $filename;
            }
        }
    }

    if (!empty($name) && !empty($comment)) {
        $stmt = $pdo->prepare("UPDATE reviews SET name=?, title=?, comment=?, rating=?, is_verified=?, avatar=?, status=?, sort_order=? WHERE id=?");
        $stmt->execute([$name, $title, $comment, $rating, $is_verified, $avatar_path, $status, $sort_order, $id]);
        $success = "Review updated successfully!";
    } else {
        $error = "Client name and review comment are required!";
    }
}

// Handle Delete Review
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $stmt = $pdo->prepare("SELECT avatar FROM reviews WHERE id = ?");
    $stmt->execute([$id]);
    $rev = $stmt->fetch();
    if ($rev && !empty($rev['avatar']) && file_exists(dirname(__DIR__) . '/' . $rev['avatar'])) {
        @unlink(dirname(__DIR__) . '/' . $rev['avatar']);
    }
    $pdo->prepare("DELETE FROM reviews WHERE id = ?")->execute([$id]);
    header("Location: reviews.php?msg=deleted");
    exit();
}

if (isset($_GET['msg']) && $_GET['msg'] == 'deleted') {
    $success = "Review deleted successfully!";
}

$reviews = $pdo->query("SELECT * FROM reviews ORDER BY sort_order ASC, id DESC")->fetchAll(PDO::FETCH_ASSOC);
$pending_orders = $pdo->query("SELECT COUNT(*) FROM orders WHERE status = 'Pending'")->fetchColumn();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Client Reviews | Admin Panel</title>
    
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/premium-theme.css">
    <link rel="stylesheet" href="../assets/css/jx-toast.css">
    
    <style>
        :root {
            --primary-blue: #1e2ab8;
            --primary-gradient: linear-gradient(135deg, #1e2ab8 0%, #4338ca 100%);
            --primary-hover: #0f172a;
            --primary-light: #e0e7ff;
            --sidebar-w: 260px;
            --dark-bg: #0f172a;
            --border-color: #e2e8f0;
            --text-slate: #64748b;
        }

        @media (prefers-color-scheme: dark) {
            :root {
                --dark-bg: #0f172a;
                --border-color: #334155;
                --text-slate: #94a3b8;
            }
            body { background: #0f172a; }
            .review-card { background: #1e293b; border-color: #334155; }
            .review-card .table-light { background: #0f172a; }
            .review-card .table-light th { color: #94a3b8; }
            .review-card td { color: #e2e8f0; border-color: #334155; }
            .modal-content { background: #1e293b; border-color: #334155; color:#f8fafc; }
            .modal-header { border-color: #334155; }
            .modal-footer { border-color: #334155; }
            .form-control, .form-select { background: #0f172a; color: #e2e8f0; border-color: #334155; }
        }

        * { font-style: normal !important; }
        body { font-family: 'Inter', sans-serif; background: #f1f5f9; margin: 0; }

        .sidebar { height: 100vh; background: var(--dark-bg); position: fixed; width: var(--sidebar-w); z-index: 1050; transition: 0.3s; }
        .sidebar-brand { padding: 25px; border-bottom: 1px solid rgba(255,255,255,0.08); color: #fff; font-weight: 900; font-size: 1.1rem; text-transform: uppercase; letter-spacing: 0.5px; }
        .sidebar-brand i { color: #60a5fa; }
        .nav-link-admin { padding: 14px 25px; display: block; color: #94a3b8; text-decoration: none; transition: 0.3s; font-weight: 700; border-left: 4px solid transparent; font-size: 0.85rem; text-transform: uppercase; letter-spacing: 0.3px; }
        .nav-link-admin:hover, .nav-link-admin.active { background: rgba(30, 42, 184, 0.1); color: #fff; border-left-color: var(--primary-blue); }
        .nav-link-admin i { color: #60a5fa; width: 20px; }
        .nav-link-admin.active i { color: #93bbfc; }
        .main-content { margin-left: var(--sidebar-w); padding: 30px; transition: 0.3s; }
        .mobile-header { display: none; background: var(--dark-bg); color: white; padding: 15px 20px; position: sticky; top: 0; z-index: 1000; }

        .review-card { background: #fff; border-radius: 20px; border: 1px solid var(--border-color); box-shadow: 0 5px 15px rgba(30, 42, 184, 0.02); overflow: hidden; }
        .btn-add { background: var(--primary-gradient); color: white; border-radius: 12px; font-weight: 700; padding: 10px 24px; border: none; transition: 0.3s; text-transform: uppercase; letter-spacing: 0.5px; font-size: 0.8rem; }
        .btn-add:hover { background: var(--primary-hover); transform: translateY(-2px); color: white; box-shadow: 0 8px 25px rgba(30, 42, 184, 0.3); }

        .form-control, .form-select { border-radius: 10px; padding: 10px 15px; border: 2px solid var(--border-color); font-size: 0.9rem; font-weight: 600; }
        .form-control:focus, .form-select:focus { box-shadow: 0 0 0 3px rgba(30, 42, 184, 0.1); border-color: var(--primary-blue); }

        .sidebar-overlay { display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.5); z-index: 1040; }
        .sidebar-overlay.show { display: block; }

        @media (max-width: 992px) {
            .sidebar { transform: translateX(-100%); }
            .sidebar.active { transform: translateX(0); }
            .main-content { margin-left: 0; padding: 20px; }
            .mobile-header { display: flex; justify-content: space-between; align-items: center; }
        }
    </style>
</head>
<body>

<div class="sidebar-overlay" id="overlay" onclick="toggleMenu()"></div>

<!-- ====== Sidebar ====== -->
<div class="sidebar" id="adminSidebar">
    <div class="sidebar-brand d-flex align-items-center justify-content-between">
        <span><i class="fas fa-bolt me-2"></i> Admin Panel</span>
        <button class="btn text-white d-lg-none" onclick="toggleMenu()"><i class="fas fa-times"></i></button>
    </div>
    <div class="mt-3">
        <a href="dashboard.php" class="nav-link-admin"><i class="fas fa-chart-pie me-2"></i> Dashboard</a>
        <a href="product.php" class="nav-link-admin"><i class="fas fa-box me-2"></i> Products</a>
        <a href="category.php" class="nav-link-admin"><i class="fas fa-tags me-2"></i> Categories</a>
        <a href="orders.php" class="nav-link-admin d-flex justify-content-between">
            <span><i class="fas fa-shopping-cart me-2"></i> Orders</span>
            <?php if($pending_orders > 0): ?> <span class="badge bg-danger rounded-pill"><?= $pending_orders ?></span> <?php endif; ?>
        </a>
        <a href="slider.php" class="nav-link-admin"><i class="fas fa-images me-2"></i> Banners / Sliders</a>
        <a href="reviews.php" class="nav-link-admin active"><i class="fas fa-star me-2"></i> Client Reviews</a>
        <a href="pages.php" class="nav-link-admin"><i class="fas fa-file-contract me-2"></i> Legal & Policies</a>
        <a href="users.php" class="nav-link-admin"><i class="fas fa-users me-2"></i> Users</a>
        <a href="settings.php" class="nav-link-admin"><i class="fas fa-sliders me-2"></i> Settings</a>
        <a href="../index.php" target="_blank" class="nav-link-admin" style="color: #60a5fa;"><i class="fas fa-external-link-alt me-2"></i> View Store</a>
        <a href="../logout.php" class="nav-link-admin text-danger mt-4"><i class="fas fa-power-off me-2"></i> Logout</a>
    </div>
    <div class="admin-dev-credit" style="padding:14px 20px;border-top:1px solid rgba(255,255,255,0.06);font-size:0.75rem;color:#64748b;text-align:center;">Developer: <span style="color:#60a5fa;font-weight:700;">Rafi</span></div>
</div>

<!-- ====== Mobile Header ====== -->
<div class="mobile-header d-lg-none">
    <span class="fw-bold text-uppercase" style="font-size:0.9rem; letter-spacing:0.5px;">
        <i class="fas fa-star me-2" style="color: #60a5fa;"></i> Client Reviews
    </span>
    <button class="btn text-white fs-4" onclick="toggleMenu()"><i class="fas fa-bars"></i></button>
</div>

<!-- ====== Main Content ====== -->
<div class="main-content">
    <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
        <div>
            <h4 class="fw-bold mb-0 text-uppercase" style="color: var(--dark-bg); letter-spacing: -0.3px;">
                <i class="fas fa-star me-2" style="color: var(--primary-blue);"></i> Client Reviews & Feedback
            </h4>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb small">
                    <li class="breadcrumb-item"><a href="dashboard.php">Dashboard</a></li>
                    <li class="breadcrumb-item active">Client Reviews</li>
                </ol>
            </nav>
        </div>
        <button class="btn-add" data-bs-toggle="modal" data-bs-target="#addReviewModal">
            <i class="fas fa-plus me-2"></i> Add New Review
        </button>
    </div>

    <?php if(isset($success)): ?>
        <div class="alert alert-success border-0 shadow-sm rounded-3">
            <i class="fas fa-check-circle me-2"></i> <?= $success ?>
        </div>
    <?php endif; ?>
    
    <?php if(isset($error)): ?>
        <div class="alert alert-danger border-0 shadow-sm rounded-3">
            <i class="fas fa-exclamation-circle me-2"></i> <?= $error ?>
        </div>
    <?php endif; ?>

    <!-- ====== Reviews Table ====== -->
    <div class="review-card shadow-sm">
        <div class="table-responsive">
            <table class="table align-middle mb-0">
                <thead class="table-light" style="font-weight: 700; font-size: 0.7rem; text-transform: uppercase; letter-spacing: 0.5px;">
                    <tr>
                        <th class="ps-3">Client</th>
                        <th>Rating</th>
                        <th>Comment</th>
                        <th>Status</th>
                        <th class="text-end pe-3">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($reviews as $rev): ?>
                    <tr>
                        <td class="ps-3">
                            <div class="d-flex align-items-center">
                                <?php if(!empty($rev['avatar'])): ?>
                                    <img src="../<?= htmlspecialchars($rev['avatar']) ?>" class="rounded-circle me-3" style="width:40px; height:40px; object-fit:cover;">
                                <?php else: ?>
                                    <div class="rounded-circle me-3 d-flex align-items-center justify-content-center fw-bold" style="width:40px; height:40px; background: linear-gradient(135deg, #2563eb, #38bdf8); color:#fff; font-size:0.9rem;">
                                        <?= strtoupper(substr($rev['name'], 0, 1)) ?>
                                    </div>
                                <?php endif; ?>
                                <div>
                                    <div class="fw-bold small"><?= htmlspecialchars($rev['name']) ?></div>
                                    <?php if($rev['is_verified']): ?>
                                        <span class="badge bg-success-subtle text-success" style="font-size:10px;"><i class="fas fa-check-circle me-1"></i> Verified</span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </td>
                        <td>
                            <div class="text-warning small">
                                <?php 
                                $r = round($rev['rating']); 
                                for($s=1; $s<=5; $s++) {
                                    echo $s <= $r ? '<i class="fas fa-star"></i>' : '<i class="far fa-star text-muted"></i>';
                                }
                                ?>
                                <span class="text-muted ms-1">(<?= number_format($rev['rating'], 1) ?>)</span>
                            </div>
                        </td>
                        <td class="small" style="max-width:320px;">
                            <div class="text-truncate text-muted" title="<?= htmlspecialchars($rev['comment']) ?>">
                                "<?= htmlspecialchars($rev['comment']) ?>"
                            </div>
                        </td>
                        <td>
                            <?php if($rev['status'] == 1): ?>
                                <span class="badge bg-success" style="font-size:0.65rem; border-radius:30px; padding:4px 10px;">Active</span>
                            <?php else: ?>
                                <span class="badge bg-secondary" style="font-size:0.65rem; border-radius:30px; padding:4px 10px;">Hidden</span>
                            <?php endif; ?>
                        </td>
                        <td class="text-end pe-3">
                            <button class="btn btn-sm btn-outline-primary me-1 edit-review-btn" 
                                    data-id="<?= $rev['id'] ?>"
                                    data-name="<?= htmlspecialchars($rev['name']) ?>"
                                    data-comment="<?= htmlspecialchars($rev['comment']) ?>"
                                    data-rating="<?= $rev['rating'] ?>"
                                    data-verified="<?= $rev['is_verified'] ?>"
                                    data-status="<?= $rev['status'] ?>"
                                    data-sort="<?= $rev['sort_order'] ?>"
                                    data-bs-toggle="modal" data-bs-target="#editReviewModal">
                                <i class="fas fa-edit"></i>
                            </button>
                            <a href="?delete=<?= $rev['id'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('নিশ্চিত তো? এই রিভিউটি মুছে ফেলতে চান?')"><i class="fas fa-trash"></i></a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php if(empty($reviews)): ?>
                        <tr><td colspan="5" class="text-center p-4 text-muted small">No reviews added yet. Click "Add New Review" to create one.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- ====== Add Review Modal ====== -->
<div class="modal fade" id="addReviewModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <form class="modal-content rounded-4 border-0" method="POST" enctype="multipart/form-data">
            <input type="hidden" name="title" value="Verified Order">
            <div class="modal-header border-0 pb-0">
                <h5 class="fw-bold"><i class="fas fa-star me-2 text-warning"></i> Add Client Review</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-4">
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="small fw-bold mb-1">Client Name</label>
                        <input type="text" name="name" class="form-control" required placeholder="e.g. Tanvir Hasan">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="small fw-bold mb-1">Rating (1 to 5 Stars)</label>
                        <select name="rating" class="form-select">
                            <option value="5.0" selected>⭐⭐⭐⭐⭐ 5.0 (Excellent)</option>
                            <option value="4.8">⭐⭐⭐⭐⭐ 4.8</option>
                            <option value="4.5">⭐⭐⭐⭐ 4.5</option>
                            <option value="4.0">⭐⭐⭐⭐ 4.0</option>
                        </select>
                    </div>
                </div>
                <div class="mb-3">
                    <label class="small fw-bold mb-1">Review Comment</label>
                    <textarea name="comment" class="form-control" rows="3" required placeholder="Very fast delivery and friendly support!"></textarea>
                </div>
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="small fw-bold mb-1">Client Photo (Optional)</label>
                        <input type="file" name="avatar" class="form-control" accept="image/*">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="small fw-bold mb-1">Status</label>
                        <select name="status" class="form-select">
                            <option value="1">Active (Show in Store)</option>
                            <option value="0">Hidden</option>
                        </select>
                    </div>
                </div>
                <div class="form-check form-switch mt-2">
                    <input class="form-check-input" type="checkbox" name="is_verified" value="1" id="add_verified" checked>
                    <label class="form-check-label small fw-bold" for="add_verified">Mark as Verified Buyer</label>
                </div>
            </div>
            <div class="modal-footer border-0 pt-0">
                <button type="submit" name="add_review" class="btn btn-primary w-100 py-2 rounded-3 fw-bold">Publish Review</button>
            </div>
        </form>
    </div>
</div>

<!-- ====== Edit Review Modal ====== -->
<div class="modal fade" id="editReviewModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <form class="modal-content rounded-4 border-0" method="POST" enctype="multipart/form-data">
            <input type="hidden" name="review_id" id="edit_rev_id">
            <input type="hidden" name="title" value="Verified Order">
            <div class="modal-header border-0 pb-0">
                <h5 class="fw-bold"><i class="fas fa-edit me-2" style="color: var(--primary-blue);"></i> Edit Review</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-4">
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="small fw-bold mb-1">Client Name</label>
                        <input type="text" name="name" id="edit_rev_name" class="form-control" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="small fw-bold mb-1">Rating</label>
                        <select name="rating" id="edit_rev_rating" class="form-select">
                            <option value="5.0">⭐⭐⭐⭐⭐ 5.0 (Excellent)</option>
                            <option value="4.8">⭐⭐⭐⭐⭐ 4.8</option>
                            <option value="4.5">⭐⭐⭐⭐ 4.5</option>
                            <option value="4.0">⭐⭐⭐⭐ 4.0</option>
                        </select>
                    </div>
                </div>
                <div class="mb-3">
                    <label class="small fw-bold mb-1">Review Comment</label>
                    <textarea name="comment" id="edit_rev_comment" class="form-control" rows="3" required></textarea>
                </div>
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="small fw-bold mb-1">Replace Photo (Optional)</label>
                        <input type="file" name="avatar" class="form-control" accept="image/*">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="small fw-bold mb-1">Status</label>
                        <select name="status" id="edit_rev_status" class="form-select">
                            <option value="1">Active</option>
                            <option value="0">Hidden</option>
                        </select>
                    </div>
                </div>
                <div class="form-check form-switch mt-2">
                    <input class="form-check-input" type="checkbox" name="is_verified" value="1" id="edit_rev_verified">
                    <label class="form-check-label small fw-bold" for="edit_rev_verified">Mark as Verified Buyer</label>
                </div>
            </div>
            <div class="modal-footer border-0 pt-0">
                <button type="submit" name="update_review" class="btn btn-primary w-100 py-2 rounded-3 fw-bold">Save Changes</button>
            </div>
        </form>
    </div>
</div>

<script>
function toggleMenu() {
    document.getElementById('adminSidebar').classList.toggle('active');
    document.getElementById('overlay').classList.toggle('show');
}

document.querySelectorAll('.edit-review-btn').forEach(btn => {
    btn.addEventListener('click', function() {
        document.getElementById('edit_rev_id').value = this.getAttribute('data-id');
        document.getElementById('edit_rev_name').value = this.getAttribute('data-name');
        document.getElementById('edit_rev_comment').value = this.getAttribute('data-comment');
        document.getElementById('edit_rev_rating').value = this.getAttribute('data-rating');
        document.getElementById('edit_rev_status').value = this.getAttribute('data-status');
        document.getElementById('edit_rev_verified').checked = this.getAttribute('data-verified') === '1';
    });
});
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
