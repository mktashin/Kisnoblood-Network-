<?php
include '../config.php';

// Security Check
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

$success = null;
$error = null;

// Defensive column upgrade
try { $pdo->exec("ALTER TABLE settings ADD COLUMN site_tagline VARCHAR(255) DEFAULT 'Premium Digital Subscriptions & Downloads'"); } catch (Throwable $e) {}
try { $pdo->exec("ALTER TABLE settings ADD COLUMN auto_approve_orders INT NOT NULL DEFAULT 0"); } catch (Throwable $e) {}
try { $pdo->exec("ALTER TABLE settings ADD COLUMN currency_symbol VARCHAR(10) NOT NULL DEFAULT '৳'"); } catch (Throwable $e) {}
try { $pdo->exec("ALTER TABLE settings ADD COLUMN upay_number VARCHAR(30) DEFAULT NULL"); } catch (Throwable $e) {}
try { $pdo->exec("ALTER TABLE settings ADD COLUMN whatsapp_number VARCHAR(30) DEFAULT NULL"); } catch (Throwable $e) {}
try { $pdo->exec("ALTER TABLE settings ADD COLUMN favicon VARCHAR(255) DEFAULT ''"); } catch (Throwable $e) {}
try { $pdo->exec("ALTER TABLE settings ADD COLUMN enable_manual_payment INT NOT NULL DEFAULT 1"); } catch (Throwable $e) {}
try { $pdo->exec("ALTER TABLE settings ADD COLUMN enable_auto_payment INT NOT NULL DEFAULT 0"); } catch (Throwable $e) {}
try { $pdo->exec("ALTER TABLE settings ADD COLUMN hostneko_api_key VARCHAR(255) DEFAULT ''"); } catch (Throwable $e) {}
try { $pdo->exec("ALTER TABLE settings ADD COLUMN hostneko_currency_rate VARCHAR(20) DEFAULT '1'"); } catch (Throwable $e) {}
try { $pdo->exec("ALTER TABLE settings ADD COLUMN manual_payment_type VARCHAR(20) DEFAULT 'Personal'"); } catch (Throwable $e) {}
try { $pdo->exec("ALTER TABLE settings ADD COLUMN manual_payment_note TEXT DEFAULT NULL"); } catch (Throwable $e) {}

// Update Settings Logic
if (isset($_POST['update_settings'])) {
    $name = trim($_POST['site_name'] ?? '');
    $tagline = trim($_POST['site_tagline'] ?? '');
    $currency = trim($_POST['currency_symbol'] ?? '৳');
    $auto_approve = !empty($_POST['auto_approve_orders']) ? 1 : 0;
    $status = (int)($_POST['site_status'] ?? 1);
    $yt = trim($_POST['yt_link'] ?? '');
    $fb = trim($_POST['fb_link'] ?? '');
    $tg = trim($_POST['tg_link'] ?? '');
    $tg_user = trim($_POST['tg_user'] ?? '');
    $whatsapp = trim($_POST['whatsapp_number'] ?? '');
    $meta_t = trim($_POST['meta_title'] ?? '');
    $meta_d = trim($_POST['meta_desc'] ?? '');
    $meta_k = trim($_POST['meta_keys'] ?? '');

    // Current settings
    $cur = $pdo->query("SELECT * FROM settings WHERE id=1 LIMIT 1")->fetch() ?: [];
    $logo_path = $cur['logo'] ?? 'uploads/jhx_digital_shop_logo_v2.svg';
    $favicon_path = $cur['favicon'] ?? '';

    // Handle Custom Logo URL or Upload
    if (!empty($_POST['logo_url'])) {
        $logo_path = trim($_POST['logo_url']);
    }
    if (!empty($_FILES['logo_file']['name'])) {
        $upload_dir = __DIR__ . '/../uploads/';
        if (!is_dir($upload_dir)) @mkdir($upload_dir, 0755, true);
        $ext = strtolower(pathinfo($_FILES['logo_file']['name'], PATHINFO_EXTENSION));
        if (in_array($ext, ['png', 'jpg', 'jpeg', 'svg', 'webp', 'gif', 'ico'])) {
            $filename = 'logo_' . time() . '.' . $ext;
            if (move_uploaded_file($_FILES['logo_file']['tmp_name'], $upload_dir . $filename)) {
                $logo_path = 'uploads/' . $filename;
            }
        }
    }

    // Handle Custom Favicon URL or Upload
    if (!empty($_POST['favicon_url'])) {
        $favicon_path = trim($_POST['favicon_url']);
    }
    if (!empty($_FILES['favicon_file']['name'])) {
        $upload_dir = __DIR__ . '/../uploads/';
        if (!is_dir($upload_dir)) @mkdir($upload_dir, 0755, true);
        $ext = strtolower(pathinfo($_FILES['favicon_file']['name'], PATHINFO_EXTENSION));
        if (in_array($ext, ['png', 'jpg', 'jpeg', 'svg', 'webp', 'ico'])) {
            $filename = 'favicon_' . time() . '.' . $ext;
            if (move_uploaded_file($_FILES['favicon_file']['tmp_name'], $upload_dir . $filename)) {
                $favicon_path = 'uploads/' . $filename;
            }
        }
    }

    // Payment gateway settings
    $enable_manual = isset($_POST['enable_manual_payment']) ? (int)$_POST['enable_manual_payment'] : 1;
    $enable_auto = isset($_POST['enable_auto_payment']) ? (int)$_POST['enable_auto_payment'] : 0;
    $hostneko_api = trim($_POST['hostneko_api_key'] ?? '');
    $hostneko_rate = trim($_POST['hostneko_currency_rate'] ?? '1');

    // Manual payment settings
    $bkash = trim($_POST['bkash_number'] ?? '');
    $nagad = trim($_POST['nagad_number'] ?? '');
    $rocket = trim($_POST['rocket_number'] ?? '');
    $upay = trim($_POST['upay_number'] ?? '');
    $manual_type = trim($_POST['manual_payment_type'] ?? 'Personal');
    $manual_note = trim($_POST['manual_payment_note'] ?? '');

    $sql = "UPDATE settings SET 
        site_name=?, 
        site_tagline=?,
        currency_symbol=?,
        auto_approve_orders=?,
        enable_manual_payment=?,
        enable_auto_payment=?,
        hostneko_api_key=?,
        hostneko_currency_rate=?,
        logo=?, 
        favicon=?, 
        site_status=?, 
        yt_link=?, 
        fb_link=?, 
        tg_link=?, 
        tg_user=?, 
        whatsapp_number=?,
        meta_title=?, 
        meta_desc=?, 
        meta_keys=?, 
        bkash_number=?, 
        nagad_number=?, 
        rocket_number=?, 
        upay_number=?,
        manual_payment_type=?, 
        manual_payment_note=? 
        WHERE id=1";
    
    $pdo->prepare($sql)->execute([
        $name, $tagline, $currency, $auto_approve,
        $enable_manual, $enable_auto, $hostneko_api, $hostneko_rate,
        $logo_path, $favicon_path, $status, 
        $yt, $fb, $tg, $tg_user, $whatsapp, $meta_t, $meta_d, $meta_k,
        $bkash, $nagad, $rocket, $upay, $manual_type, $manual_note
    ]);

    // Admin Credentials Update if provided
    $adm_name = trim($_POST['admin_account_name'] ?? '');
    $adm_email = trim($_POST['admin_account_email'] ?? '');
    $adm_pass = (string)($_POST['admin_account_password'] ?? '');

    if ($adm_email !== '' && filter_var($adm_email, FILTER_VALIDATE_EMAIL)) {
        if (!empty($adm_pass)) {
            if (strlen($adm_pass) >= 6) {
                $hPass = password_hash($adm_pass, PASSWORD_DEFAULT);
                $pdo->prepare("UPDATE users SET name = ?, email = ?, password = ? WHERE id = ? AND role = 'admin'")->execute([$adm_name, $adm_email, $hPass, $_SESSION['user_id']]);
                $_SESSION['user_name'] = $adm_name;
            } else {
                $error = "Admin password must be at least 6 characters.";
            }
        } else {
            $pdo->prepare("UPDATE users SET name = ?, email = ? WHERE id = ? AND role = 'admin'")->execute([$adm_name, $adm_email, $_SESSION['user_id']]);
            $_SESSION['user_name'] = $adm_name;
        }
    }
    
    if (!$error) {
        $success = "System settings, payments, branding, and credentials updated successfully!";
    }
}

// Fetch Current Settings
$set = $pdo->query("SELECT * FROM settings WHERE id=1 LIMIT 1")->fetch() ?: [];

// Fetch Current Admin Info
$curAdmin = $pdo->prepare("SELECT * FROM users WHERE id = ? LIMIT 1");
$curAdmin->execute([$_SESSION['user_id'] ?? 0]);
$adminUser = $curAdmin->fetch() ?: ['name' => $_SESSION['user_name'] ?? 'Admin', 'email' => ''];

// Statistics for Sidebar
$pending_count = $pdo->query("SELECT COUNT(*) FROM orders WHERE status = 'Pending'")->fetchColumn();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Site Settings | Admin Panel</title>
    
    <!-- Fonts & CSS -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        :root {
            --primary-blue: #1e2ab8;
            --primary-gradient: linear-gradient(135deg, #1e2ab8 0%, #4338ca 100%);
            --primary-hover: #0f172a;
            --primary-light: #e0e7ff;
            --sidebar-w: 260px;
            --dark-bg: #0f172a;
            --border-color: #e2e8f0;
            --text-slate: #64748b;
            --text-dark: #1e293b;
            --card-bg: #ffffff;
            --shadow: 0 5px 15px rgba(30, 42, 184, 0.04);
            --radius: 20px;
        }

        @media (prefers-color-scheme: dark) {
            :root {
                --dark-bg: #0f172a;
                --card-bg: #1e293b;
                --border-color: #334155;
                --text-slate: #94a3b8;
                --text-dark: #e2e8f0;
            }
            body { background: #0f172a; }
            .settings-card { background: #1e293b; border-color: #334155; }
            .form-control, .form-select { background: #0f172a; color: #e2e8f0; border-color: #334155; }
            .form-control:focus, .form-select:focus { background: #1e293b; border-color: #60a5fa; color: #fff; }
        }

        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Inter', sans-serif; font-style: normal !important; }
        body { background: #f1f5f9; color: var(--text-dark); min-height: 100vh; overflow-x: hidden; }

        .sidebar {
            height: 100vh;
            background: var(--dark-bg);
            position: fixed;
            width: var(--sidebar-w);
            z-index: 1050;
            transition: 0.3s;
            overflow-y: auto;
            border-right: 1px solid rgba(255, 255, 255, 0.05);
        }
        .sidebar-brand {
            padding: 20px 24px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.06);
            color: #fff;
            font-weight: 900;
            font-size: 1.1rem;
            display: flex;
            align-items: center;
            justify-content: space-between;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        .sidebar-brand .close-btn { background: none; border: none; color: #94a3b8; font-size: 1.2rem; cursor: pointer; display: none; }

        .nav-link-admin {
            padding: 12px 24px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            color: #94a3b8;
            text-decoration: none;
            font-weight: 700;
            font-size: 0.84rem;
            transition: all 0.2s ease;
            border-left: 4px solid transparent;
            text-transform: uppercase;
            letter-spacing: 0.3px;
        }
        .nav-link-admin:hover,
        .nav-link-admin.active {
            color: #fff;
            background: rgba(30, 42, 184, 0.15);
            border-left-color: var(--primary-blue);
        }
        .nav-link-admin i { width: 22px; font-size: 1rem; margin-right: 8px; }

        .main-content {
            margin-left: var(--sidebar-w);
            padding: 28px 32px;
            min-height: 100vh;
            transition: 0.3s;
        }
        .settings-card {
            background: var(--card-bg);
            border-radius: var(--radius);
            border: 1px solid var(--border-color);
            box-shadow: var(--shadow);
            padding: 28px;
        }
        .form-label {
            font-weight: 700;
            font-size: 0.75rem;
            color: var(--text-slate);
            text-transform: uppercase;
            letter-spacing: 0.3px;
            margin-bottom: 6px;
        }
        .form-label i { color: var(--primary-blue); }
        .form-control, .form-select {
            border-radius: 10px;
            padding: 10px 14px;
            border: 1.5px solid var(--border-color);
            font-size: 0.9rem;
            font-weight: 600;
        }
        .btn-update {
            background: var(--primary-gradient);
            color: white;
            border-radius: 12px;
            font-weight: 900;
            padding: 14px 24px;
            border: none;
            width: 100%;
            transition: 0.3s;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            font-size: 0.88rem;
            cursor: pointer;
        }
        .btn-update:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(30, 42, 184, 0.25);
            color: white;
        }

        @media (max-width: 992px) {
            .sidebar { transform: translateX(-100%); }
            .sidebar.active { transform: translateX(0); }
            .main-content { margin-left: 0; padding: 18px; }
            .sidebar-brand .close-btn { display: block; }
        }
    </style>
</head>
<body>

<div class="sidebar" id="adminSidebar">
    <div class="sidebar-brand">
        <span><i class="fas fa-bolt me-2 text-warning"></i> Admin Panel</span>
        <button class="close-btn" onclick="toggleMenu()"><i class="fas fa-times"></i></button>
    </div>
    <div class="mt-3">
        <a href="dashboard.php" class="nav-link-admin"><i class="fas fa-chart-pie"></i> <span>Dashboard</span></a>
        <a href="product.php" class="nav-link-admin"><i class="fas fa-box"></i> <span>Products</span></a>
        <a href="category.php" class="nav-link-admin"><i class="fas fa-tags"></i> <span>Categories</span></a>
        <a href="orders.php" class="nav-link-admin">
            <span><i class="fas fa-shopping-cart"></i> Orders</span>
            <?php if($pending_count > 0): ?> <span class="badge bg-danger rounded-pill"><?= $pending_count ?></span> <?php endif; ?>
        </a>
        <a href="slider.php" class="nav-link-admin"><i class="fas fa-images"></i> <span>Banners / Sliders</span></a>
        <a href="reviews.php" class="nav-link-admin"><i class="fas fa-star"></i> <span>Client Reviews</span></a>
        <a href="pages.php" class="nav-link-admin"><i class="fas fa-file-contract"></i> <span>Legal & Policies</span></a>
        <a href="users.php" class="nav-link-admin"><i class="fas fa-users"></i> <span>Users</span></a>
        <a href="settings.php" class="nav-link-admin active"><i class="fas fa-sliders"></i> <span>Settings</span></a>
        <a href="../index.php" target="_blank" class="nav-link-admin" style="color: #60a5fa;"><i class="fas fa-external-link-alt"></i> <span>View Store</span></a>
        <a href="../logout.php" class="nav-link-admin text-danger mt-4"><i class="fas fa-power-off"></i> <span>Logout</span></a>
    </div>
    <div class="admin-dev-credit" style="padding:14px 20px;border-top:1px solid rgba(255,255,255,0.06);font-size:0.75rem;color:#64748b;text-align:center;margin-top:auto;">Developer: <span style="color:#60a5fa;font-weight:700;">Rafi</span></div>
</div>

<div class="main-content">
    <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
        <div>
            <h4 class="fw-bold mb-1" style="color: var(--text-dark);"><i class="fas fa-sliders me-2 text-primary"></i> Site Settings & Administration</h4>
            <p class="text-muted small mb-0">Manage complete A to Z site controls, payment gateways, delivery automation, and admin profile.</p>
        </div>
        <button class="btn btn-outline-secondary d-lg-none" onclick="toggleMenu()"><i class="fas fa-bars"></i></button>
    </div>

    <?php if(!empty($success)): ?>
        <div class="alert alert-success border-0 shadow-sm rounded-4 mb-4 py-3 d-flex align-items-center gap-2">
            <i class="fas fa-check-circle fs-5"></i>
            <div><?= htmlspecialchars($success) ?></div>
        </div>
    <?php endif; ?>

    <?php if(!empty($error)): ?>
        <div class="alert alert-danger border-0 shadow-sm rounded-4 mb-4 py-3 d-flex align-items-center gap-2">
            <i class="fas fa-exclamation-triangle fs-5"></i>
            <div><?= htmlspecialchars($error) ?></div>
        </div>
    <?php endif; ?>

    <form method="POST" enctype="multipart/form-data" class="settings-card">
        <div class="row g-4">

            <!-- 1. BRANDING & BASIC SETTINGS -->
            <div class="col-12">
                <h6 class="fw-bold text-uppercase" style="color: var(--primary-blue); letter-spacing: 0.5px;">
                    <i class="fas fa-palette me-2"></i> 1. Store Branding & Identity
                </h6>
            </div>
            <div class="col-md-5">
                <label class="form-label"><i class="fas fa-globe me-1"></i> Website Name</label>
                <input type="text" name="site_name" class="form-control" value="<?= htmlspecialchars($set['site_name'] ?? '') ?>" required>
            </div>
            <div class="col-md-5">
                <label class="form-label"><i class="fas fa-tag me-1"></i> Tagline / Subtitle</label>
                <input type="text" name="site_tagline" class="form-control" value="<?= htmlspecialchars($set['site_tagline'] ?? '') ?>">
            </div>
            <div class="col-md-2">
                <label class="form-label"><i class="fas fa-coins me-1"></i> Currency</label>
                <input type="text" name="currency_symbol" class="form-control" value="<?= htmlspecialchars($set['currency_symbol'] ?? '৳') ?>">
            </div>

            <div class="col-md-6">
                <label class="form-label"><i class="fas fa-image me-1"></i> Store Logo</label>
                <input type="file" name="logo_file" class="form-control mb-2" accept="image/*">
                <input type="text" name="logo_url" class="form-control" value="<?= htmlspecialchars($set['logo'] ?? '') ?>" placeholder="Or enter logo file URL">
            </div>
            <div class="col-md-6">
                <label class="form-label"><i class="fas fa-star me-1"></i> Favicon</label>
                <input type="file" name="favicon_file" class="form-control mb-2" accept="image/*">
                <input type="text" name="favicon_url" class="form-control" value="<?= htmlspecialchars($set['favicon'] ?? '') ?>" placeholder="Or enter favicon URL">
            </div>

            <div class="col-md-6">
                <label class="form-label"><i class="fas fa-power-off me-1"></i> Site Status (Maintenance Mode)</label>
                <select name="site_status" class="form-select">
                    <option value="1" <?= ($set['site_status'] ?? 1) == 1 ? 'selected' : '' ?>>✅ Website Online (Live)</option>
                    <option value="0" <?= ($set['site_status'] ?? 1) == 0 ? 'selected' : '' ?>>🔧 Maintenance Mode (Under Construction)</option>
                </select>
            </div>

            <!-- 2. AUTOMATION & ORDER ACTIVATION -->
            <div class="col-md-6">
                <label class="form-label"><i class="fas fa-bolt me-1 text-warning"></i> Instant Order Activation (Auto-Approve)</label>
                <select name="auto_approve_orders" class="form-select">
                    <option value="1" <?= ($set['auto_approve_orders'] ?? 0) == 1 ? 'selected' : '' ?>>⚡ Auto-Activate Orders (User instantly gets download access after submitting TrxID)</option>
                    <option value="0" <?= ($set['auto_approve_orders'] ?? 0) == 0 ? 'selected' : '' ?>>🔒 Manual Approval (Admin manually activates each order in Orders page)</option>
                </select>
            </div>

            <div class="col-12"><hr class="my-2"></div>

            <!-- 3. PAYMENT GATEWAYS & CHECKOUT CONTROLS -->
            <div class="col-12">
                <h6 class="fw-bold text-uppercase" style="color: var(--primary-blue); letter-spacing: 0.5px;">
                    <i class="fas fa-credit-card me-2"></i> 2. Payment Gateways & Checkout Controls
                </h6>
                <p class="text-muted small mb-3">Enable or disable Manual Payment and Auto Payment Gateway (HostNekoPay) independently.</p>
            </div>

            <!-- Master Payment Switches -->
            <div class="col-md-6">
                <div class="p-3 rounded-3" style="background: rgba(30, 42, 184, 0.04); border: 1.5px solid rgba(30, 42, 184, 0.15);">
                    <label class="form-label d-flex justify-content-between align-items-center">
                        <span><i class="fas fa-mobile-screen-button me-1"></i> Manual Payment (bKash/Nagad/Rocket)</span>
                        <span class="badge <?= ($set['enable_manual_payment'] ?? 1) == 1 ? 'bg-success' : 'bg-secondary' ?>">
                            <?= ($set['enable_manual_payment'] ?? 1) == 1 ? 'ACTIVE' : 'OFF' ?>
                        </span>
                    </label>
                    <select name="enable_manual_payment" class="form-select">
                        <option value="1" <?= ($set['enable_manual_payment'] ?? 1) == 1 ? 'selected' : '' ?>>✅ Enabled (ON) - Customers can submit TrxID manually</option>
                        <option value="0" <?= ($set['enable_manual_payment'] ?? 1) == 0 ? 'selected' : '' ?>>❌ Disabled (OFF) - Hide manual payment option</option>
                    </select>
                    <small class="text-muted mt-1 d-block" style="font-size:0.75rem;">Allows buyers to send money to your numbers and enter their Transaction ID.</small>
                </div>
            </div>

            <div class="col-md-6">
                <div class="p-3 rounded-3" style="background: rgba(16, 185, 129, 0.04); border: 1.5px solid rgba(16, 185, 129, 0.25);">
                    <label class="form-label d-flex justify-content-between align-items-center">
                        <span style="color: #059669;"><i class="fas fa-bolt me-1 text-warning"></i> Auto Pay Gateway (HostNekoPay)</span>
                        <span class="badge <?= (!empty($set['hostneko_api_key']) && ($set['enable_auto_payment'] ?? 0) == 1) ? 'bg-success' : 'bg-secondary' ?>">
                            <?= (!empty($set['hostneko_api_key']) && ($set['enable_auto_payment'] ?? 0) == 1) ? 'ACTIVE' : 'OFF' ?>
                        </span>
                    </label>
                    <select name="enable_auto_payment" class="form-select">
                        <option value="1" <?= ($set['enable_auto_payment'] ?? 0) == 1 ? 'selected' : '' ?>>⚡ Enabled (ON) - Instant auto payment via HostNekoPay</option>
                        <option value="0" <?= ($set['enable_auto_payment'] ?? 0) == 0 ? 'selected' : '' ?>>❌ Disabled (OFF) - Turn off HostNekoPay gateway</option>
                    </select>
                    <small class="text-muted mt-1 d-block" style="font-size:0.75rem;">Customers pay automatically via bKash, Nagad, Rocket, Cards & orders activate instantly.</small>
                </div>
            </div>

            <!-- HostNekoPay Configuration Box -->
            <div class="col-12">
                <div class="p-4 rounded-4" style="background: linear-gradient(135deg, #f8fafc 0%, #eff6ff 100%); border: 1.5px solid #bfdbfe;">
                    <div class="d-flex align-items-center justify-content-between mb-3 flex-wrap gap-2">
                        <div class="d-flex align-items-center gap-2">
                            <span style="background: #1e2ab8; color: #fff; border-radius: 10px; width: 34px; height: 34px; display: inline-flex; align-items: center; justify-content: center;">
                                <i class="fas fa-bolt"></i>
                            </span>
                            <div>
                                <h6 class="fw-bold mb-0" style="color: #1e2ab8;">WHMCS-HostNekoPay Auto Payment Gateway</h6>
                                <span class="text-muted" style="font-size: 0.78rem;">Automatic bKash, Nagad, Rocket, Upay & Card Payment Gateway</span>
                            </div>
                        </div>
                        <?php if (!empty($set['hostneko_api_key']) && ($set['enable_auto_payment'] ?? 0) == 1): ?>
                            <span class="badge bg-success px-3 py-2 rounded-pill"><i class="fas fa-check-circle me-1"></i> Gateway Ready & Connected</span>
                        <?php elseif(empty($set['hostneko_api_key'])): ?>
                            <span class="badge bg-warning text-dark px-3 py-2 rounded-pill"><i class="fas fa-key me-1"></i> API Key Required</span>
                        <?php else: ?>
                            <span class="badge bg-secondary px-3 py-2 rounded-pill"><i class="fas fa-pause me-1"></i> Gateway Disabled</span>
                        <?php endif; ?>
                    </div>

                    <div class="row g-3">
                        <div class="col-md-9">
                            <label class="form-label" style="color: #1e2ab8;">
                                <i class="fas fa-key me-1"></i> HostNekoPay API Key <span class="text-danger">*</span>
                            </label>
                            <input type="text" name="hostneko_api_key" class="form-control" value="<?= htmlspecialchars($set['hostneko_api_key'] ?? '') ?>" placeholder="Enter your HostNekoPay API Key from pay.hostneko.com">
                            <small class="text-muted mt-1 d-block" style="font-size: 0.78rem;">
                                শুধুমাত্র এই একটি <strong>API Key</strong> দিলেই অটো পেমেন্ট গেটওয়ে সম্পূর্ণ সেটআপ হয়ে যাবে।
                            </small>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label"><i class="fas fa-exchange-alt me-1"></i> Currency Rate</label>
                            <input type="text" name="hostneko_currency_rate" class="form-control" value="<?= htmlspecialchars($set['hostneko_currency_rate'] ?? '1') ?>" placeholder="1">
                            <small class="text-muted mt-1 d-block" style="font-size: 0.78rem;">BDT এর জন্য 1 রাখুন</small>
                        </div>
                        <div class="col-12">
                            <?php
                            $proto = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') ? 'https://' : 'http://';
                            $hostUrl = $proto . ($_SERVER['HTTP_HOST'] ?? 'localhost') . rtrim(dirname(dirname($_SERVER['SCRIPT_NAME'] ?? '')), '/\\');
                            $cbUrl = $hostUrl . '/payment/hostneko_callback.php';
                            ?>
                            <div class="p-2 px-3 rounded-3 bg-white border d-flex align-items-center justify-content-between flex-wrap gap-2">
                                <small class="text-muted" style="font-size: 0.75rem;">
                                    <i class="fas fa-link me-1 text-primary"></i> <strong>Webhook / Callback URL:</strong> <code><?= htmlspecialchars($cbUrl) ?></code>
                                </small>
                                <span class="badge bg-light text-dark border" style="font-size: 0.7rem;"><i class="fas fa-robot me-1 text-success"></i> Auto-Configured</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Manual Payment Accounts Details -->
            <div class="col-12 mt-4">
                <h6 class="fw-bold text-uppercase" style="color: var(--primary-blue); letter-spacing: 0.5px;">
                    <i class="fas fa-mobile-screen-button me-2"></i> Manual Payment Accounts
                </h6>
            </div>
            <div class="col-md-3">
                <label class="form-label" style="color: #e2136e;"><i class="fas fa-mobile-screen me-1"></i> bKash Number</label>
                <input type="text" name="bkash_number" class="form-control" value="<?= htmlspecialchars($set['bkash_number'] ?? '') ?>" placeholder="01XXXXXXXXX">
            </div>
            <div class="col-md-3">
                <label class="form-label" style="color: #f97316;"><i class="fas fa-mobile-screen me-1"></i> Nagad Number</label>
                <input type="text" name="nagad_number" class="form-control" value="<?= htmlspecialchars($set['nagad_number'] ?? '') ?>" placeholder="01XXXXXXXXX">
            </div>
            <div class="col-md-3">
                <label class="form-label" style="color: #6d28d9;"><i class="fas fa-mobile-screen me-1"></i> Rocket Number</label>
                <input type="text" name="rocket_number" class="form-control" value="<?= htmlspecialchars($set['rocket_number'] ?? '') ?>" placeholder="01XXXXXXXXX">
            </div>
            <div class="col-md-3">
                <label class="form-label" style="color: #0284c7;"><i class="fas fa-mobile-screen me-1"></i> Upay Number</label>
                <input type="text" name="upay_number" class="form-control" value="<?= htmlspecialchars($set['upay_number'] ?? '') ?>" placeholder="01XXXXXXXXX">
            </div>

            <div class="col-md-4">
                <label class="form-label">Payment Account Type</label>
                <select name="manual_payment_type" class="form-select">
                    <option value="Personal" <?= ($set['manual_payment_type'] ?? '') === 'Personal' ? 'selected' : '' ?>>Personal (Send Money)</option>
                    <option value="Merchant" <?= ($set['manual_payment_type'] ?? '') === 'Merchant' ? 'selected' : '' ?>>Merchant (Make Payment)</option>
                    <option value="Agent" <?= ($set['manual_payment_type'] ?? '') === 'Agent' ? 'selected' : '' ?>>Agent (Cash Out)</option>
                </select>
            </div>
            <div class="col-md-8">
                <label class="form-label">Payment Instruction / Guidelines for Customers</label>
                <input type="text" name="manual_payment_note" class="form-control" value="<?= htmlspecialchars($set['manual_payment_note'] ?? '') ?>" placeholder="e.g. Send money to any of the numbers above and enter your TrxID.">
            </div>

            <div class="col-12"><hr class="my-2"></div>

            <!-- 4. CUSTOMER SUPPORT -->
            <div class="col-12">
                <h6 class="fw-bold text-uppercase" style="color: var(--primary-blue); letter-spacing: 0.5px;">
                    <i class="fab fa-whatsapp text-success me-2"></i> 3. Official WhatsApp Customer Support
                </h6>
                <p class="text-muted small mb-3">গ্রাহকরা ওয়েবসাইটের নিচে থাকা ফ্লোটিং সাপোর্ট বাটনে ক্লিক করলে সরাসরি আপনার এই WhatsApp নম্বরে মেসেজ পাঠাবে।</p>
            </div>
            <div class="col-md-6">
                <label class="form-label fw-bold" style="color: #128c7e;">
                    <i class="fab fa-whatsapp me-1 text-success"></i> WhatsApp Support Number <span class="text-danger">*</span>
                </label>
                <div class="input-group">
                    <span class="input-group-text bg-light text-success fw-bold"><i class="fab fa-whatsapp"></i></span>
                    <input type="text" name="whatsapp_number" class="form-control" value="<?= htmlspecialchars($set['whatsapp_number'] ?? '') ?>" placeholder="017XXXXXXXX or 88017XXXXXXXX">
                </div>
                <small class="text-muted mt-1 d-block" style="font-size:0.76rem;">যেকোনো ফরম্যাটে নম্বর দিতে পারেন (যেমন: <code>017XXXXXXXX</code> বা <code>88017XXXXXXXX</code>)</small>
            </div>
            <div class="col-md-6">
                <div class="p-3 rounded-3 bg-light border">
                    <small class="text-dark fw-bold d-block mb-1"><i class="fas fa-info-circle text-primary me-1"></i> Live WhatsApp Button Preview:</small>
                    <small class="text-muted d-block" style="font-size: 0.78rem;">
                        বর্তমান সাপোর্ট নম্বর: <strong><?= !empty($set['whatsapp_number']) ? htmlspecialchars($set['whatsapp_number']) : '<span class="text-danger">নম্বর সেট করা হয়নি</span>' ?></strong>
                    </small>
                </div>
            </div>

            <div class="col-12"><hr class="my-2"></div>

            <!-- 5. ADMIN ACCOUNT CREDENTIALS -->
            <div class="col-12">
                <h6 class="fw-bold text-uppercase" style="color: var(--primary-blue); letter-spacing: 0.5px;">
                    <i class="fas fa-user-shield me-2"></i> 4. Admin Profile & Login Credentials
                </h6>
                <p class="text-muted small mb-3">Update your administrative login email and password anytime directly.</p>
            </div>
            <div class="col-md-4">
                <label class="form-label">Admin Full Name</label>
                <input type="text" name="admin_account_name" class="form-control" value="<?= htmlspecialchars($adminUser['name'] ?? 'Admin') ?>" required>
            </div>
            <div class="col-md-4">
                <label class="form-label">Admin Login Email</label>
                <input type="email" name="admin_account_email" class="form-control" value="<?= htmlspecialchars($adminUser['email'] ?? '') ?>" required>
            </div>
            <div class="col-md-4">
                <label class="form-label">Change Password <small class="text-muted">(Leave blank to keep current)</small></label>
                <input type="password" name="admin_account_password" class="form-control" placeholder="Min 6 characters">
            </div>

            <div class="col-12"><hr class="my-2"></div>

            <!-- 6. SEO -->
            <div class="col-12">
                <h6 class="fw-bold text-uppercase" style="color: var(--primary-blue); letter-spacing: 0.5px;">
                    <i class="fas fa-search me-2"></i> 5. Search Engine Optimization (SEO)
                </h6>
            </div>
            <div class="col-md-6">
                <label class="form-label">Meta Title</label>
                <input type="text" name="meta_title" class="form-control" value="<?= htmlspecialchars($set['meta_title'] ?? '') ?>">
            </div>
            <div class="col-md-6">
                <label class="form-label">Meta Keywords</label>
                <input type="text" name="meta_keys" class="form-control" value="<?= htmlspecialchars($set['meta_keys'] ?? '') ?>">
            </div>
            <div class="col-12">
                <label class="form-label">Meta Description</label>
                <textarea name="meta_desc" class="form-control" rows="2"><?= htmlspecialchars($set['meta_desc'] ?? '') ?></textarea>
            </div>

            <div class="col-12 mt-4">
                <button type="submit" name="update_settings" class="btn-update">
                    <i class="fas fa-save me-2"></i> Save All Settings & Updates
                </button>
            </div>

        </div>
    </form>
</div>

<script>
function toggleMenu() {
    document.getElementById('adminSidebar').classList.toggle('active');
}
</script>
</body>
</html>
