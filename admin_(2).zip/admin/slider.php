<?php
include '../config.php';

// Security
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

// Handle Delete Slider
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    
    // Get image path to delete file
    $stmt = $pdo->prepare("SELECT image FROM sliders WHERE id = ?");
    $stmt->execute([$id]);
    $slider = $stmt->fetch();
    
    if ($slider && !empty($slider['image'])) {
        $file_path = "../" . $slider['image'];
        if (file_exists($file_path)) {
            @unlink($file_path);
        }
    }
    
    $pdo->prepare("DELETE FROM sliders WHERE id = ?")->execute([$id]);
    header("Location: slider.php?msg=deleted");
    exit();
}

// Handle Add Slider
if (isset($_POST['add_slider'])) {
    $link = $_POST['link'];
    $target_dir = "../uploads/sliders/";
    if (!file_exists($target_dir)) { mkdir($target_dir, 0777, true); }
    
    $file_name = time() . "_" . basename($_FILES['image']['name']);
    $target_file = $target_dir . $file_name;
    $db_path = "uploads/sliders/" . $file_name;

    if (move_uploaded_file($_FILES['image']['tmp_name'], $target_file)) {
        $pdo->prepare("INSERT INTO sliders (image, link) VALUES (?,?)")->execute([$db_path, $link]);
        $success = "Slider added successfully!";
    } else {
        $error = "Failed to upload image.";
    }
}

// Get pending orders count for sidebar
$pending_orders = $pdo->query("SELECT COUNT(*) FROM orders WHERE status = 'Pending'")->fetchColumn();

// Get success message from URL
if (isset($_GET['msg']) && $_GET['msg'] == 'deleted') {
    $success = "Slider deleted successfully!";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Sliders | Admin</title>
    
    <!-- ====== ফন্ট: Inter ====== -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/premium-theme.css">
    <link rel="stylesheet" href="../assets/css/jx-toast.css">
    <script src="../assets/js/jx-toast.js"></script>
    
    <style>
        /* ==========================================
           ✅ ADMIN SLIDER UPDATED: 11 August 2026
           📌 নীল থিম (#1e2ab8)
        ========================================== */
        
        :root {
            --primary-blue: #1e2ab8;
            --primary-gradient: linear-gradient(135deg, #1e2ab8 0%, #4338ca 100%);
            --primary-hover: #0f172a;
            --primary-light: #e0e7ff;
            --sidebar-w: 260px;
            --dark-bg: #0f172a;
            --border-color: #e2e8f0;
            --text-slate: #64748b;
        }

        /* ডার্ক মোড অটো */
        @media (prefers-color-scheme: dark) {
            :root {
                --dark-bg: #0f172a;
                --border-color: #334155;
                --text-slate: #94a3b8;
            }
            body { background: #0f172a; }
            .slider-card { background: #1e293b; border-color: #334155; }
            .slider-card .text-muted { color: #94a3b8 !important; }
            .card.border-0 { background: #1e293b; border-color: #334155 !important; }
            .card.border-0 .form-control { background: #0f172a; color: #e2e8f0; border-color: #334155; }
            .card.border-0 .form-control:focus { background: #1e293b; border-color: #60a5fa; box-shadow: 0 0 0 3px rgba(30, 42, 184, 0.15); }
            .card.border-0 .form-control::placeholder { color: #64748b; }
            .card.border-0 label { color: #94a3b8; }
            .breadcrumb-item a { color: #94a3b8; }
            .breadcrumb-item.active { color: #60a5fa; }
        }

        * { font-style: normal !important; }
        
        body { 
            font-family: 'Inter', sans-serif; 
            background: #f1f5f9; 
            margin: 0; 
        }

        /* ====== Sidebar ====== */
        .sidebar { 
            height: 100vh; 
            background: var(--dark-bg); 
            position: fixed; 
            width: var(--sidebar-w); 
            z-index: 1050; 
            transition: 0.3s; 
        }
        
        .sidebar-brand { 
            padding: 25px; 
            border-bottom: 1px solid rgba(255,255,255,0.08); 
            color: #fff; 
            font-weight: 900; 
            font-size: 1.1rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .sidebar-brand i {
            color: #60a5fa;
        }
        
        .nav-link-admin { 
            padding: 14px 25px; 
            display: block; 
            color: #94a3b8; 
            text-decoration: none; 
            transition: 0.3s; 
            font-weight: 700; 
            border-left: 4px solid transparent;
            font-size: 0.85rem;
            text-transform: uppercase;
            letter-spacing: 0.3px;
        }
        
        .nav-link-admin:hover, 
        .nav-link-admin.active { 
            background: rgba(30, 42, 184, 0.1); 
            color: #fff; 
            border-left-color: var(--primary-blue); 
        }
        
        .nav-link-admin i {
            color: #60a5fa;
            width: 20px;
        }
        
        .nav-link-admin.active i {
            color: #93bbfc;
        }
        
        .nav-link-admin .badge {
            background: #ef4444;
            color: #fff;
            font-size: 0.65rem;
            padding: 2px 10px;
        }

        /* ====== Main Content ====== */
        .main-content { 
            margin-left: var(--sidebar-w); 
            padding: 30px; 
            transition: 0.3s; 
        }
        
        .mobile-header { 
            display: none; 
            background: var(--dark-bg); 
            color: white; 
            padding: 15px 20px; 
            position: sticky; 
            top: 0; 
            z-index: 1000; 
        }

        /* ====== Slider Card ====== */
        .slider-card { 
            background: #fff; 
            border-radius: 16px; 
            overflow: hidden; 
            border: 1px solid var(--border-color); 
            transition: 0.3s; 
            box-shadow: 0 5px 15px rgba(30, 42, 184, 0.02);
        }
        .slider-card:hover { 
            transform: translateY(-5px); 
            box-shadow: 0 10px 30px rgba(30, 42, 184, 0.06);
            border-color: var(--primary-blue);
        }
        .slider-img { 
            height: 160px; 
            object-fit: cover; 
            width: 100%; 
        }
        .slider-id {
            font-weight: 700;
            font-size: 0.7rem;
            color: var(--text-slate);
            text-transform: uppercase;
            letter-spacing: 0.3px;
        }

        /* ====== বাটন ====== */
        .btn-add-slider { 
            background: var(--primary-gradient); 
            color: white; 
            border-radius: 12px; 
            font-weight: 700; 
            border: none; 
            transition: 0.3s;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            font-size: 0.8rem;
            padding: 10px 20px;
        }
        .btn-add-slider:hover { 
            background: var(--primary-hover); 
            transform: translateY(-2px); 
            color: white; 
            box-shadow: 0 8px 25px rgba(30, 42, 184, 0.3); 
        }

        .btn-back-dash {
            background: var(--dark-bg);
            color: #fff;
            border: none;
            border-radius: 10px;
            font-weight: 700;
            padding: 8px 20px;
            font-size: 0.8rem;
            text-transform: uppercase;
            letter-spacing: 0.3px;
            transition: 0.3s;
            text-decoration: none;
        }
        .btn-back-dash:hover {
            background: var(--primary-blue);
            color: #fff;
            transform: translateY(-2px);
        }

        .btn-delete-slider {
            color: #ef4444;
            transition: 0.3s;
            padding: 6px 12px;
            border-radius: 8px;
            background: #fef2f2;
            border: 1px solid #fee2e2;
            text-decoration: none;
            font-weight: 700;
            font-size: 0.75rem;
        }
        .btn-delete-slider:hover {
            background: #ef4444;
            color: #fff;
            border-color: #ef4444;
        }

        /* ====== Form Controls ====== */
        .form-control { 
            border-radius: 10px; 
            padding: 10px 15px; 
            border: 2px solid var(--border-color); 
            font-size: 0.9rem;
            font-weight: 600;
            transition: all 0.3s ease;
            background: #fff;
            color: var(--dark-bg);
        }
        
        .form-control:focus { 
            box-shadow: 0 0 0 3px rgba(30, 42, 184, 0.1); 
            border-color: var(--primary-blue); 
        }
        
        .form-control::placeholder {
            color: var(--text-slate);
            font-weight: 400;
        }

        /* ====== রেসপনসিভ ====== */
        @media (max-width: 992px) {
            .sidebar { transform: translateX(-100%); }
            .sidebar.active { transform: translateX(0); }
            .main-content { margin-left: 0; padding: 20px; }
            .mobile-header { display: flex; justify-content: space-between; align-items: center; }
        }
        
        @media (max-width: 480px) {
            .main-content { padding: 12px; }
            .slider-card { border-radius: 12px; }
            .slider-img { height: 120px; }
            .btn-add-slider { font-size: 0.7rem; padding: 8px 16px; }
            .btn-back-dash { font-size: 0.65rem; padding: 6px 14px; }
        }
        
        .sidebar-overlay { 
            display: none; 
            position: fixed; 
            inset: 0; 
            background: rgba(0,0,0,0.5); 
            z-index: 1040; 
        }
        .sidebar-overlay.show { display: block; }
        
        .breadcrumb-item a {
            color: var(--text-slate);
            text-decoration: none;
            font-weight: 600;
        }
        .breadcrumb-item a:hover {
            color: var(--primary-blue);
        }
        .breadcrumb-item.active {
            color: var(--primary-blue);
            font-weight: 700;
        }
        
        .alert-success {
            background: #ecfdf5;
            border: 1px solid #d1fae5;
            color: #065f46;
            font-weight: 700;
            border-radius: 14px;
        }
        .alert-success i {
            color: #059669;
        }
        
        .alert-danger {
            background: #fef2f2;
            border: 1px solid #fee2e2;
            color: #dc2626;
            font-weight: 700;
            border-radius: 14px;
        }
        .alert-danger i {
            color: #ef4444;
        }
    </style>
</head>
<body>

<div class="sidebar-overlay" id="overlay" onclick="toggleMenu()"></div>

<!-- ====== Sidebar ====== -->
<div class="sidebar" id="adminSidebar">
    <div class="sidebar-brand d-flex align-items-center justify-content-between">
        <span><i class="fas fa-bolt me-2"></i> Admin Panel</span>
        <button class="btn text-white d-lg-none" onclick="toggleMenu()"><i class="fas fa-times"></i></button>
    </div>
    <div class="mt-3">
        <a href="dashboard.php" class="nav-link-admin"><i class="fas fa-chart-pie me-2"></i> Dashboard</a>
        <a href="product.php" class="nav-link-admin"><i class="fas fa-box me-2"></i> Products</a>
        <a href="category.php" class="nav-link-admin"><i class="fas fa-tags me-2"></i> Categories</a>
        <a href="slider.php" class="nav-link-admin active"><i class="fas fa-images me-2"></i> Banners / Sliders</a>
        <a href="reviews.php" class="nav-link-admin"><i class="fas fa-star me-2"></i> Client Reviews</a>
        <a href="pages.php" class="nav-link-admin"><i class="fas fa-file-contract me-2"></i> Legal & Policies</a>
        <a href="orders.php" class="nav-link-admin d-flex justify-content-between">
            <span><i class="fas fa-shopping-cart me-2"></i> Orders</span>
            <?php if($pending_orders > 0): ?> <span class="badge" style="background:#ef4444;color:#fff;border-radius:30px;padding:3px 8px;font-size:0.65rem;"><?= $pending_orders ?></span> <?php endif; ?>
        </a>
        <a href="users.php" class="nav-link-admin"><i class="fas fa-users me-2"></i> Users</a>
        <a href="settings.php" class="nav-link-admin"><i class="fas fa-sliders me-2"></i> Settings</a>
        <a href="../index.php" target="_blank" class="nav-link-admin" style="color: #60a5fa;"><i class="fas fa-external-link-alt me-2"></i> View Store</a>
        <a href="../logout.php" class="nav-link-admin text-danger mt-4"><i class="fas fa-power-off me-2"></i> Logout</a>
    </div>
    <div class="admin-dev-credit" style="padding:14px 20px;border-top:1px solid rgba(255,255,255,0.06);font-size:0.75rem;color:#64748b;text-align:center;">Developer: <span style="color:#60a5fa;font-weight:700;">Rafi</span></div>
</div>

<!-- ====== Mobile Header ====== -->
<div class="mobile-header d-lg-none">
    <span class="fw-bold text-uppercase" style="font-size:0.9rem; letter-spacing:0.5px;">
        <i class="fas fa-images me-2" style="color: #60a5fa;"></i> Manage Sliders
    </span>
    <button class="btn text-white fs-4" onclick="toggleMenu()"><i class="fas fa-bars"></i></button>
</div>

<!-- ====== Main Content ====== -->
<div class="main-content">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h4 class="fw-bold mb-0 text-uppercase" style="color: var(--dark-bg); letter-spacing: -0.3px;">
                <i class="fas fa-images me-2" style="color: var(--primary-blue);"></i> Manage Sliders
            </h4>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb small">
                    <li class="breadcrumb-item"><a href="dashboard.php"><i class="fas fa-home me-1"></i> Dashboard</a></li>
                    <li class="breadcrumb-item active">Sliders</li>
                </ol>
            </nav>
        </div>
        <a href="dashboard.php" class="btn-back-dash">
            <i class="fas fa-arrow-left me-1"></i> Dashboard
        </a>
    </div>

    <?php if(isset($success)): ?>
        <div class="alert alert-success rounded-3 small">
            <i class="fas fa-check-circle me-2"></i> <?= $success ?>
        </div>
    <?php endif; ?>
    
    <?php if(isset($error)): ?>
        <div class="alert alert-danger rounded-3 small">
            <i class="fas fa-exclamation-circle me-2"></i> <?= $error ?>
        </div>
    <?php endif; ?>

    <!-- ====== Add Slider Form ====== -->
    <div class="card border-0 shadow-sm p-4 mb-4" style="border-radius: 16px; border: 1px solid var(--border-color); background: #fff;">
        <h6 class="fw-bold mb-3 text-uppercase" style="color: var(--dark-bg); letter-spacing: 0.5px; font-size: 0.8rem;">
            <i class="fas fa-plus-circle me-2" style="color: var(--primary-blue);"></i> Add New Slider
        </h6>
        <form method="POST" enctype="multipart/form-data" class="row g-3">
            <div class="col-md-5">
                <label class="small fw-bold mb-1" style="color: var(--text-slate); text-transform: uppercase; letter-spacing: 0.3px; font-size: 0.7rem;">
                    <i class="fas fa-image me-1" style="color: var(--primary-blue);"></i> Slider Image
                </label>
                <input type="file" name="image" class="form-control" accept="image/*" required>
            </div>
            <div class="col-md-5">
                <label class="small fw-bold mb-1" style="color: var(--text-slate); text-transform: uppercase; letter-spacing: 0.3px; font-size: 0.7rem;">
                    <i class="fas fa-link me-1" style="color: var(--primary-blue);"></i> Link (Optional)
                </label>
                <input type="text" name="link" class="form-control" placeholder="https://example.com">
            </div>
            <div class="col-md-2 d-flex align-items-end">
                <button type="submit" name="add_slider" class="btn-add-slider w-100">
                    <i class="fas fa-plus me-1"></i> Add
                </button>
            </div>
        </form>
    </div>

    <!-- ====== Sliders List ====== -->
    <div class="row">
        <?php
        $sliders = $pdo->query("SELECT * FROM sliders ORDER BY id DESC")->fetchAll();
        if(empty($sliders)): ?>
            <div class="col-12">
                <div class="text-center p-5 bg-white rounded-4 border" style="border-color: var(--border-color) !important;">
                    <i class="fas fa-images text-muted mb-3" style="font-size: 2.5rem; opacity: 0.3;"></i>
                    <h6 class="fw-bold" style="color: var(--text-slate);">No Sliders Found</h6>
                    <p class="text-muted small" style="font-weight: 500;">Add your first slider using the form above.</p>
                </div>
            </div>
        <?php else: ?>
            <?php foreach($sliders as $s): ?>
            <div class="col-md-4 col-sm-6 mb-3">
                <div class="slider-card shadow-sm">
                    <img src="../<?= $s['image'] ?>" class="slider-img" alt="Slider">
                    <div class="p-3 d-flex justify-content-between align-items-center">
                        <div>
                            <span class="slider-id"><i class="fas fa-hashtag me-1"></i> <?= $s['id'] ?></span>
                            <?php if(!empty($s['link'])): ?>
                                <a href="<?= htmlspecialchars($s['link']) ?>" target="_blank" class="small ms-2" style="color: var(--primary-blue); font-weight: 600; text-decoration: none;">
                                    <i class="fas fa-external-link-alt"></i>
                                </a>
                            <?php endif; ?>
                        </div>
                        <a href="?delete=<?= $s['id'] ?>" class="btn-delete-slider" onclick="return confirm('Delete this slider?')">
                            <i class="fas fa-trash"></i>
                        </a>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>

<!-- ====== JavaScript ====== -->
<script>
    function toggleMenu() {
        document.getElementById('adminSidebar').classList.toggle('active');
        document.getElementById('overlay').classList.toggle('show');
    }
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="../assets/js/premium.js"></script>
</body>
</html>