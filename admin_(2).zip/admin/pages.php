<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include '../config.php';

// Security Check
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

$success = null;
$error = null;

// Ensure default pages exist in database
$default_pages = [
    'privacy-policy' => [
        'title' => 'Privacy Policy',
        'content' => "<h3>1. Information We Collect</h3>\n<p>We only collect essential information required to fulfill your digital orders, including your name, email address, and order payment details.</p>\n<h3>2. How We Use Your Information</h3>\n<p>Your details are used strictly for order delivery, authentication, and customer support. We never share or sell your information to third parties.</p>\n<h3>3. Data Security</h3>\n<p>We implement secure encryption and access protocols to protect your accounts and transactions.</p>"
    ],
    'terms-of-service' => [
        'title' => 'Terms of Service',
        'content' => "<h3>1. Digital Product Delivery</h3>\n<p>Products and subscriptions are delivered instantly or via manual verification as stated on each product page. Access credentials or downloadable files are accessible in your account upon order completion.</p>\n<h3>2. Usage License</h3>\n<p>Digital subscriptions and downloadable assets are for individual or authorized use only. Reselling or unauthorized redistribution is strictly prohibited.</p>\n<h3>3. Account Security</h3>\n<p>You are responsible for maintaining the confidentiality of your account credentials.</p>"
    ],
    'refund-policy' => [
        'title' => 'Refund Policy',
        'content' => "<h3>1. Replacement & Refund Eligibility</h3>\n<p>Our priority is 100% satisfaction. If you encounter any technical defect, invalid subscription credential, or delivery failure within the guaranteed warranty period, contact our live support for an immediate replacement or full refund.</p>\n<h3>2. Non-Refundable Situations</h3>\n<p>Refunds are not granted in cases of policy violation or change of mind after successful delivery and activation.</p>\n<h3>3. Contact Support</h3>\n<p>For any refund requests, contact our live WhatsApp support with your Order ID.</p>"
    ]
];

foreach ($default_pages as $slug => $data) {
    $chk = $pdo->prepare("SELECT COUNT(*) FROM pages WHERE slug = ?");
    $chk->execute([$slug]);
    if ($chk->fetchColumn() == 0) {
        $ins = $pdo->prepare("INSERT INTO pages (slug, title, content) VALUES (?, ?, ?)");
        $ins->execute([$slug, $data['title'], $data['content']]);
    }
}

// Handle Update Page Content
if (isset($_POST['update_page'])) {
    $slug = trim($_POST['slug'] ?? '');
    $title = trim($_POST['title'] ?? '');
    $content = trim($_POST['content'] ?? '');

    if (!empty($slug) && !empty($title)) {
        $stmt = $pdo->prepare("UPDATE pages SET title = ?, content = ? WHERE slug = ?");
        $stmt->execute([$title, $content, $slug]);
        $success = "Page '{$title}' updated successfully!";
    } else {
        $error = "Page title and content are required!";
    }
}

// Fetch all pages
$pages = $pdo->query("SELECT * FROM pages ORDER BY id ASC")->fetchAll(PDO::FETCH_ASSOC);
$pending_orders = $pdo->query("SELECT COUNT(*) FROM orders WHERE status = 'Pending'")->fetchColumn();

// Active tab
$active_slug = $_GET['tab'] ?? ($pages[0]['slug'] ?? 'privacy-policy');
$current_page = null;
foreach ($pages as $pg) {
    if ($pg['slug'] === $active_slug) {
        $current_page = $pg;
        break;
    }
}
if (!$current_page && !empty($pages)) {
    $current_page = $pages[0];
    $active_slug = $current_page['slug'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Legal & Policies | Admin Panel</title>
    
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/premium-theme.css">
    
    <style>
        :root {
            --primary-blue: #1e2ab8;
            --primary-gradient: linear-gradient(135deg, #1e2ab8 0%, #4338ca 100%);
            --primary-hover: #0f172a;
            --primary-light: #e0e7ff;
            --sidebar-w: 260px;
            --dark-bg: #0f172a;
            --border-color: #e2e8f0;
            --text-slate: #64748b;
        }

        @media (prefers-color-scheme: dark) {
            :root {
                --dark-bg: #0f172a;
                --border-color: #334155;
                --text-slate: #94a3b8;
            }
            body { background: #0f172a; }
            .policy-card { background: #1e293b; border-color: #334155; }
            .nav-pills .nav-link { color: #94a3b8; }
            .nav-pills .nav-link.active { background: #1e2ab8; color: #fff; }
            .form-control { background: #0f172a; color: #e2e8f0; border-color: #334155; }
            .preview-box { background: #0f172a; border-color: #334155; color: #e2e8f0; }
        }

        * { font-style: normal !important; }
        body { font-family: 'Inter', sans-serif; background: #f1f5f9; margin: 0; }

        .sidebar { height: 100vh; background: var(--dark-bg); position: fixed; width: var(--sidebar-w); z-index: 1050; transition: 0.3s; }
        .sidebar-brand { padding: 25px; border-bottom: 1px solid rgba(255,255,255,0.08); color: #fff; font-weight: 900; font-size: 1.1rem; text-transform: uppercase; letter-spacing: 0.5px; }
        .sidebar-brand i { color: #60a5fa; }
        .nav-link-admin { padding: 14px 25px; display: block; color: #94a3b8; text-decoration: none; transition: 0.3s; font-weight: 700; border-left: 4px solid transparent; font-size: 0.85rem; text-transform: uppercase; letter-spacing: 0.3px; }
        .nav-link-admin:hover, .nav-link-admin.active { background: rgba(30, 42, 184, 0.1); color: #fff; border-left-color: var(--primary-blue); }
        .nav-link-admin i { color: #60a5fa; width: 20px; }
        .nav-link-admin.active i { color: #93bbfc; }
        .main-content { margin-left: var(--sidebar-w); padding: 30px; transition: 0.3s; }
        .mobile-header { display: none; background: var(--dark-bg); color: white; padding: 15px 20px; position: sticky; top: 0; z-index: 1000; }

        .policy-card { background: #fff; border-radius: 20px; border: 1px solid var(--border-color); box-shadow: 0 5px 15px rgba(30, 42, 184, 0.02); padding: 28px; }
        .form-control { border-radius: 12px; padding: 12px 16px; border: 2px solid var(--border-color); font-size: 0.95rem; font-weight: 600; }
        .form-control:focus { box-shadow: 0 0 0 3px rgba(30, 42, 184, 0.1); border-color: var(--primary-blue); }

        .sidebar-overlay { display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.5); z-index: 1040; }
        .sidebar-overlay.show { display: block; }

        .preview-box { border-radius: 14px; border: 1px dashed var(--border-color); padding: 20px; background: #f8fafc; font-size: 0.9rem; line-height: 1.6; }

        @media (max-width: 992px) {
            .sidebar { transform: translateX(-100%); }
            .sidebar.active { transform: translateX(0); }
            .main-content { margin-left: 0; padding: 20px; }
            .mobile-header { display: flex; justify-content: space-between; align-items: center; }
        }
    </style>
</head>
<body>

<div class="sidebar-overlay" id="overlay" onclick="toggleMenu()"></div>

<!-- ====== Sidebar ====== -->
<div class="sidebar" id="adminSidebar">
    <div class="sidebar-brand d-flex align-items-center justify-content-between">
        <span><i class="fas fa-bolt me-2"></i> Admin Panel</span>
        <button class="btn text-white d-lg-none" onclick="toggleMenu()"><i class="fas fa-times"></i></button>
    </div>
    <div class="mt-3">
        <a href="dashboard.php" class="nav-link-admin"><i class="fas fa-chart-pie me-2"></i> Dashboard</a>
        <a href="product.php" class="nav-link-admin"><i class="fas fa-box me-2"></i> Products</a>
        <a href="category.php" class="nav-link-admin"><i class="fas fa-tags me-2"></i> Categories</a>
        <a href="orders.php" class="nav-link-admin d-flex justify-content-between">
            <span><i class="fas fa-shopping-cart me-2"></i> Orders</span>
            <?php if($pending_orders > 0): ?> <span class="badge bg-danger rounded-pill"><?= $pending_orders ?></span> <?php endif; ?>
        </a>
        <a href="slider.php" class="nav-link-admin"><i class="fas fa-images me-2"></i> Banners / Sliders</a>
        <a href="reviews.php" class="nav-link-admin"><i class="fas fa-star me-2"></i> Client Reviews</a>
        <a href="pages.php" class="nav-link-admin active"><i class="fas fa-file-contract me-2"></i> Legal & Policies</a>
        <a href="users.php" class="nav-link-admin"><i class="fas fa-users me-2"></i> Users</a>
        <a href="settings.php" class="nav-link-admin"><i class="fas fa-sliders me-2"></i> Settings</a>
        <a href="../index.php" target="_blank" class="nav-link-admin" style="color: #60a5fa;"><i class="fas fa-external-link-alt me-2"></i> View Store</a>
        <a href="../logout.php" class="nav-link-admin text-danger mt-4"><i class="fas fa-power-off me-2"></i> Logout</a>
    </div>
    <div class="admin-dev-credit" style="padding:14px 20px;border-top:1px solid rgba(255,255,255,0.06);font-size:0.75rem;color:#64748b;text-align:center;">Developer: <span style="color:#60a5fa;font-weight:700;">Rafi</span></div>
</div>

<!-- ====== Mobile Header ====== -->
<div class="mobile-header d-lg-none">
    <span class="fw-bold text-uppercase" style="font-size:0.9rem; letter-spacing:0.5px;">
        <i class="fas fa-file-contract me-2" style="color: #60a5fa;"></i> Legal Pages
    </span>
    <button class="btn text-white fs-4" onclick="toggleMenu()"><i class="fas fa-bars"></i></button>
</div>

<!-- ====== Main Content ====== -->
<div class="main-content">
    <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
        <div>
            <h4 class="fw-bold mb-0 text-uppercase" style="color: var(--dark-bg); letter-spacing: -0.3px;">
                <i class="fas fa-file-contract me-2" style="color: var(--primary-blue);"></i> Legal & Policy Pages
            </h4>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb small">
                    <li class="breadcrumb-item"><a href="dashboard.php">Dashboard</a></li>
                    <li class="breadcrumb-item active">Legal & Policies</li>
                </ol>
            </nav>
        </div>
        <div>
            <a href="../page.php?slug=<?= htmlspecialchars($active_slug) ?>" target="_blank" class="btn btn-outline-primary fw-bold" style="border-radius:12px; font-size:0.8rem;">
                <i class="fas fa-external-link-alt me-1"></i> Preview Live Page
            </a>
        </div>
    </div>

    <?php if(isset($success)): ?>
        <div class="alert alert-success border-0 shadow-sm rounded-3">
            <i class="fas fa-check-circle me-2"></i> <?= $success ?>
        </div>
    <?php endif; ?>
    
    <?php if(isset($error)): ?>
        <div class="alert alert-danger border-0 shadow-sm rounded-3">
            <i class="fas fa-exclamation-circle me-2"></i> <?= $error ?>
        </div>
    <?php endif; ?>

    <!-- ====== Policy Tabs ====== -->
    <ul class="nav nav-pills mb-4 gap-2">
        <?php foreach($pages as $pg): ?>
            <li class="nav-item">
                <a class="nav-link <?= $pg['slug'] === $active_slug ? 'active fw-bold' : 'fw-bold' ?>" 
                   style="border-radius: 12px; padding: 10px 20px;" 
                   href="pages.php?tab=<?= htmlspecialchars($pg['slug']) ?>">
                    <i class="fas fa-file-alt me-2"></i> <?= htmlspecialchars($pg['title']) ?>
                </a>
            </li>
        <?php endforeach; ?>
    </ul>

    <!-- ====== Editor Form ====== -->
    <?php if($current_page): ?>
    <div class="policy-card shadow-sm">
        <form method="POST">
            <input type="hidden" name="slug" value="<?= htmlspecialchars($current_page['slug']) ?>">
            
            <div class="mb-3">
                <label class="form-label fw-bold small text-uppercase" style="letter-spacing: 0.5px;">Page Title</label>
                <input type="text" name="title" class="form-control" value="<?= htmlspecialchars($current_page['title']) ?>" required>
            </div>

            <div class="mb-4">
                <label class="form-label fw-bold small text-uppercase" style="letter-spacing: 0.5px;">Page Content (HTML / Text Supported)</label>
                <textarea name="content" class="form-control" rows="12" required style="font-family: monospace; font-size: 0.9rem; line-height: 1.6;"><?= htmlspecialchars($current_page['content']) ?></textarea>
                <div class="form-text small mt-2">
                    <i class="fas fa-info-circle me-1"></i> আপনি এখানে সাধারণ লেখা বা HTML ট্যাগ (যেমন: <code>&lt;h3&gt;</code>, <code>&lt;p&gt;</code>, <code>&lt;ul&gt;</code>) ব্যবহার করতে পারেন।
                </div>
            </div>

            <div class="d-flex justify-content-between align-items-center flex-wrap gap-2">
                <button type="submit" name="update_page" class="btn btn-primary px-4 py-2 rounded-3 fw-bold" style="background:var(--primary-gradient); border:none;">
                    <i class="fas fa-save me-2"></i> Save <?= htmlspecialchars($current_page['title']) ?>
                </button>
                <span class="text-muted small">
                    Last Updated: <?= date('d M, Y h:i A', strtotime($current_page['updated_at'] ?? 'now')) ?>
                </span>
            </div>
        </form>

        <hr class="my-4">

        <!-- Live Content Preview -->
        <h6 class="fw-bold mb-3"><i class="fas fa-eye me-2 text-primary"></i> Content Live Preview:</h6>
        <div class="preview-box">
            <h2 class="fw-bold mb-3" style="color:var(--primary-blue);"><?= htmlspecialchars($current_page['title']) ?></h2>
            <div>
                <?= $current_page['content'] ?>
            </div>
        </div>
    </div>
    <?php endif; ?>
</div>

<script>
function toggleMenu() {
    document.getElementById('adminSidebar').classList.toggle('active');
    document.getElementById('overlay').classList.toggle('show');
}
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
