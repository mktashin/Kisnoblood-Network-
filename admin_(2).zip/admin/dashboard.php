<?php
include '../config.php';

// Security: Check if Admin is logged in
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

// --- All Statistics Calculations ---
$total_users = $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'user'")->fetchColumn();
$total_products = $pdo->query("SELECT COUNT(*) FROM products")->fetchColumn();
$total_categories = $pdo->query("SELECT COUNT(*) FROM categories")->fetchColumn();
$total_orders = $pdo->query("SELECT COUNT(*) FROM orders")->fetchColumn();
$pending_orders = $pdo->query("SELECT COUNT(*) FROM orders WHERE status = 'Pending'")->fetchColumn();
$completed_orders = $pdo->query("SELECT COUNT(*) FROM orders WHERE status = 'Completed'")->fetchColumn();
$total_revenue = $pdo->query("SELECT SUM(amount) FROM orders WHERE status = 'Completed'")->fetchColumn() ?: 0;
$total_sliders = $pdo->query("SELECT COUNT(*) FROM sliders")->fetchColumn();

// Recent Orders Fetch
$recent_orders = $pdo->query("SELECT orders.*, users.name as user_name, products.title as product_name 
                             FROM orders 
                             JOIN users ON orders.user_id = users.id 
                             JOIN products ON orders.product_id = products.id 
                             ORDER BY orders.id DESC LIMIT 6")->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard | <?= $set['site_name'] ?></title>
    
    <!-- ====== ফন্ট: Inter ====== -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/premium-theme.css">
    <link rel="stylesheet" href="../assets/css/jx-toast.css">
    <script src="../assets/js/jx-toast.js"></script>
    
    <style>
        /* ==========================================
           ✅ ADMIN DASHBOARD UPDATED: 11 August 2026
           📌 নীল থিম (#1e2ab8)
        ========================================== */
        
        :root {
            --primary-blue: #1e2ab8;
            --primary-gradient: linear-gradient(135deg, #1e2ab8 0%, #4338ca 100%);
            --primary-hover: #0f172a;
            --primary-light: #e0e7ff;
            --sidebar-w: 260px;
            --dark-bg: #0f172a;
            --border-color: #e2e8f0;
            --text-slate: #64748b;
        }

        /* ডার্ক মোড অটো */
        @media (prefers-color-scheme: dark) {
            :root {
                --dark-bg: #0f172a;
                --border-color: #334155;
                --text-slate: #94a3b8;
            }
            body { background: #0f172a; }
            .stat-card { background: #1e293b; border-color: #334155; }
            .stat-card .text-muted { color: #94a3b8 !important; }
            .stat-card h5 { color: #e2e8f0; }
            .table-card { background: #1e293b; border-color: #334155; }
            .table-card .bg-dark { background: #0f172a !important; }
            .table-card .table-light { background: #0f172a; }
            .table-card .table-light th { color: #94a3b8; }
            .table-card td { color: #e2e8f0; border-color: #334155; }
            .table-card .text-muted { color: #94a3b8 !important; }
            .card { background: #1e293b !important; border-color: #334155 !important; }
            .card h6 { color: #e2e8f0; }
            .card .text-muted { color: #94a3b8 !important; }
            .btn-outline-dark { color: #e2e8f0; border-color: #334155; }
            .btn-outline-dark:hover { background: #1e2ab8; border-color: #1e2ab8; color: #fff; }
        }

        * { font-style: normal !important; }
        
        body { 
            font-family: 'Inter', sans-serif; 
            background: #f1f5f9; 
            margin: 0; 
        }

        /* ====== Sidebar ====== */
        .sidebar { 
            height: 100vh; 
            background: var(--dark-bg); 
            position: fixed; 
            width: var(--sidebar-w); 
            z-index: 1050; 
            transition: 0.3s; 
        }
        
        .sidebar-brand { 
            padding: 25px; 
            border-bottom: 1px solid rgba(255,255,255,0.08); 
            color: #fff; 
            font-weight: 900; 
            font-size: 1.1rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .sidebar-brand i {
            color: #60a5fa;
        }
        
        .nav-link-admin { 
            padding: 14px 25px; 
            display: block; 
            color: #94a3b8; 
            text-decoration: none; 
            transition: 0.3s; 
            font-weight: 700; 
            border-left: 4px solid transparent;
            font-size: 0.85rem;
            text-transform: uppercase;
            letter-spacing: 0.3px;
        }
        
        .nav-link-admin:hover, 
        .nav-link-admin.active { 
            background: rgba(30, 42, 184, 0.1); 
            color: #fff; 
            border-left-color: var(--primary-blue); 
        }
        
        .nav-link-admin i {
            color: #60a5fa;
            width: 20px;
        }
        
        .nav-link-admin.active i {
            color: #93bbfc;
        }
        
        .nav-link-admin .badge {
            background: #ef4444;
            color: #fff;
            font-size: 0.65rem;
            padding: 2px 10px;
        }

        /* ====== Main Content ====== */
        .main-content { 
            margin-left: var(--sidebar-w); 
            padding: clamp(18px, 3vw, 34px);
            transition: 0.3s; 
        }

        .dashboard-shell { width: min(100%, 1440px); margin: 0 auto; }
        .dashboard-hero {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 18px;
            padding: clamp(20px, 3vw, 30px);
            margin-bottom: 22px;
            border: 1px solid #dbeafe;
            border-radius: 24px;
            background: linear-gradient(135deg, #ffffff 0%, #f5f8ff 68%, #eef2ff 100%);
            box-shadow: 0 12px 30px rgba(30, 42, 184, .07);
        }
        .dashboard-hero-copy { min-width: 0; }
        .dashboard-eyebrow { margin: 0 0 7px; color: var(--primary-blue); font-size: .68rem; font-weight: 900; letter-spacing: 1.3px; text-transform: uppercase; }
        .dashboard-subtitle { margin: 0; color: var(--text-slate); font-size: .86rem; font-weight: 600; line-height: 1.5; }
        .dashboard-status { flex: 0 0 auto; display: inline-flex; align-items: center; gap: 8px; padding: 11px 15px; border-radius: 999px; background: #ecfdf5; border: 1px solid #bbf7d0; color: #047857; font-size: .68rem; font-weight: 900; letter-spacing: .6px; text-transform: uppercase; }
        .dashboard-status i { font-size: .55rem; }
        .stat-card::after { content: ""; position: absolute; width: 100px; height: 100px; right: -35px; bottom: -44px; border-radius: 50%; background: rgba(219, 234, 254, .42); pointer-events: none; }
        .stat-card > * { position: relative; z-index: 1; }
        
        .mobile-header { 
            display: none; 
            background: var(--dark-bg); 
            color: white; 
            padding: 15px 20px; 
            position: sticky; 
            top: 0; 
            z-index: 1000; 
        }

        /* ====== Stat Cards ====== */
        .stat-card { 
            background: #fff; 
            border-radius: 20px; 
            padding: 20px; 
            border: 1px solid var(--border-color); 
            box-shadow: 0 5px 15px rgba(30, 42, 184, 0.02); 
            height: 100%; 
            transition: 0.3s; 
            position: relative; 
            overflow: hidden;
        }
        .stat-card:hover { 
            transform: translateY(-5px); 
            box-shadow: 0 10px 30px rgba(30, 42, 184, 0.06); 
            border-color: var(--primary-blue);
        }
        .stat-icon { 
            width: 45px; 
            height: 45px; 
            border-radius: 12px; 
            display: flex; 
            align-items: center; 
            justify-content: center; 
            font-size: 18px; 
            margin-bottom: 15px; 
        }
        
        .bg-blue-light { background: #e0e7ff; color: #1e2ab8; }
        .bg-green-light { background: #ecfdf5; color: #059669; }
        .bg-red-light { background: #fef2f2; color: #ef4444; }
        .bg-purple-light { background: #faf5ff; color: #7c3aed; }
        .bg-orange-light { background: #fff7ed; color: #f97316; }

        /* ====== Table Card ====== */
        .table-card { 
            background: #fff; 
            border-radius: 20px; 
            border: 1px solid var(--border-color); 
            box-shadow: 0 5px 15px rgba(30, 42, 184, 0.02); 
        }
        
        .table-card .bg-dark {
            background: var(--dark-bg) !important;
            border-radius: 20px 20px 0 0;
        }
        
        .table-card .bg-dark h6 {
            color: #fff;
            font-weight: 900;
            font-size: 0.8rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .badge-soft-danger { 
            background: rgba(30, 42, 184, 0.1); 
            color: var(--primary-blue); 
            font-weight: 700; 
        }

        /* ====== Quick Action Buttons ====== */
        .btn-outline-blue {
            color: var(--primary-blue);
            border-color: var(--primary-blue);
        }
        .btn-outline-blue:hover {
            background: var(--primary-blue);
            color: #fff;
        }

        /* ====== রেসপনসিভ ====== */
        @media (max-width: 992px) {
            .sidebar { transform: translateX(-100%); }
            .sidebar.active { transform: translateX(0); }
            .main-content { margin-left: 0; padding: 20px; }
            .mobile-header { display: flex; justify-content: space-between; align-items: center; }
            .dashboard-hero { border-radius: 20px; }
        }
        
        @media (max-width: 480px) {
            .main-content { padding: 12px; }
            .dashboard-hero { display: block; padding: 17px; border-radius: 17px; }
            .dashboard-status { margin-top: 15px; }
            .dashboard-subtitle { font-size: .75rem; }
            .stat-card { padding: 15px; border-radius: 14px; }
            .stat-icon { width: 38px; height: 38px; font-size: 15px; }
            .stat-card h5 { font-size: 1.1rem; }
            .table-card { border-radius: 14px; }
            .table-card .bg-dark { border-radius: 14px 14px 0 0; }
        }
        
        .sidebar-overlay { 
            display: none; 
            position: fixed; 
            inset: 0; 
            background: rgba(0,0,0,0.5); 
            z-index: 1040; 
        }
        .sidebar-overlay.show { display: block; }
    </style>
</head>
<body>

<div class="sidebar-overlay" id="overlay" onclick="toggleMenu()"></div>

<!-- ====== Sidebar ====== -->
<div class="sidebar" id="adminSidebar">
    <div class="sidebar-brand d-flex align-items-center justify-content-between">
        <span><i class="fas fa-bolt me-2"></i> Admin Panel</span>
        <button class="btn text-white d-lg-none" onclick="toggleMenu()"><i class="fas fa-times"></i></button>
    </div>
    <div class="mt-3">
        <a href="dashboard.php" class="nav-link-admin active"><i class="fas fa-chart-pie me-2"></i> Dashboard</a>
        <a href="product.php" class="nav-link-admin"><i class="fas fa-box me-2"></i> Products</a>
        <a href="category.php" class="nav-link-admin"><i class="fas fa-tags me-2"></i> Categories</a>
        <a href="slider.php" class="nav-link-admin"><i class="fas fa-images me-2"></i> Manage Sliders</a>
        <a href="reviews.php" class="nav-link-admin"><i class="fas fa-star me-2"></i> Client Reviews</a>
        <a href="pages.php" class="nav-link-admin"><i class="fas fa-file-contract me-2"></i> Legal & Policies</a>
        <a href="orders.php" class="nav-link-admin d-flex justify-content-between">
            <span><i class="fas fa-shopping-cart me-2"></i> Orders</span>
            <?php if($pending_orders > 0): ?>
                <span class="badge"><?= $pending_orders ?></span>
            <?php endif; ?>
        </a>
        <a href="users.php" class="nav-link-admin"><i class="fas fa-users me-2"></i> Users List</a>
        <a href="settings.php" class="nav-link-admin"><i class="fas fa-sliders me-2"></i> Site Settings</a>
        <a href="../index.php" target="_blank" class="nav-link-admin" style="color: #60a5fa;"><i class="fas fa-external-link-alt me-2"></i> View Store</a>
        <a href="../logout.php" class="nav-link-admin text-danger mt-4"><i class="fas fa-power-off me-2"></i> Logout</a>
    </div>
    <div class="admin-dev-credit" style="padding:14px 20px;border-top:1px solid rgba(255,255,255,0.06);font-size:0.75rem;color:#64748b;text-align:center;">Developer: <span style="color:#60a5fa;font-weight:700;">Rafi</span></div>
</div>

<!-- ====== Mobile Header ====== -->
<div class="mobile-header d-lg-none">
    <span class="fw-bold text-uppercase" style="font-size:0.9rem; letter-spacing:0.5px;">
        <i class="fas fa-bolt me-2" style="color: #60a5fa;"></i> Admin Panel
    </span>
    <button class="btn text-white fs-4" onclick="toggleMenu()"><i class="fas fa-bars"></i></button>
</div>

<!-- ====== Main Content ====== -->
<div class="main-content">
    <div class="dashboard-shell">
        <div class="dashboard-hero">
            <div class="dashboard-hero-copy">
                <p class="dashboard-eyebrow">Control center</p>
                <h4 class="fw-bold mb-2 text-uppercase" style="color: var(--dark-bg); letter-spacing: -0.3px;">
                    <i class="fas fa-chart-pie me-2" style="color: var(--primary-blue);"></i> Business Overview
                </h4>
                <p class="dashboard-subtitle">Welcome back, <b><?= htmlspecialchars($_SESSION['user_name']) ?></b>. Here is your shop performance at a glance.</p>
            </div>
            <div class="dashboard-status"><i class="fas fa-circle"></i> Store is live</div>
        </div>

    <!-- ====== Stat Cards ====== -->
    <div class="row g-3 mb-4">
        <div class="col-6 col-md-4 col-lg-3">
            <div class="stat-card">
                <div class="stat-icon bg-green-light"><i class="fas fa-sack-dollar"></i></div>
                <p class="text-muted small mb-1" style="font-weight: 700; text-transform: uppercase; letter-spacing: 0.3px; font-size: 0.65rem;">Total Revenue</p>
                <h5 class="fw-bold mb-0" style="color: var(--dark-bg);">৳<?= number_format($total_revenue) ?></h5>
            </div>
        </div>
        <div class="col-6 col-md-4 col-lg-3">
            <div class="stat-card">
                <div class="stat-icon bg-blue-light"><i class="fas fa-clipboard-check"></i></div>
                <p class="text-muted small mb-1" style="font-weight: 700; text-transform: uppercase; letter-spacing: 0.3px; font-size: 0.65rem;">Total Sales</p>
                <h5 class="fw-bold mb-0" style="color: var(--dark-bg);"><?= $completed_orders ?></h5>
            </div>
        </div>
        <div class="col-6 col-md-4 col-lg-3">
            <div class="stat-card">
                <div class="stat-icon bg-red-light"><i class="fas fa-spinner"></i></div>
                <p class="text-muted small mb-1" style="font-weight: 700; text-transform: uppercase; letter-spacing: 0.3px; font-size: 0.65rem;">Pending Orders</p>
                <h5 class="fw-bold mb-0" style="color: var(--dark-bg);"><?= $pending_orders ?></h5>
            </div>
        </div>
        <div class="col-6 col-md-4 col-lg-3">
            <div class="stat-card">
                <div class="stat-icon bg-purple-light"><i class="fas fa-users"></i></div>
                <p class="text-muted small mb-1" style="font-weight: 700; text-transform: uppercase; letter-spacing: 0.3px; font-size: 0.65rem;">Customers</p>
                <h5 class="fw-bold mb-0" style="color: var(--dark-bg);"><?= $total_users ?></h5>
            </div>
        </div>
    </div>

    <!-- ====== Recent Orders + Quick Actions ====== -->
    <div class="row g-4">
        <div class="col-lg-8">
            <div class="table-card overflow-hidden">
                <div class="p-3 border-bottom d-flex justify-content-between align-items-center bg-dark">
                    <h6 class="fw-bold mb-0 small text-white"><i class="fas fa-clock me-2"></i> Recent Orders</h6>
                    <a href="orders.php" class="btn btn-sm btn-outline-light rounded-pill px-3" style="font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.3px;">View All</a>
                </div>
                <div class="table-responsive">
                    <table class="table align-middle mb-0">
                        <thead class="table-light small text-uppercase" style="font-weight: 700; font-size: 0.7rem; letter-spacing: 0.5px;">
                            <tr>
                                <th class="ps-3">Customer</th>
                                <th>Amount</th>
                                <th>Status</th>
                                <th class="text-end pe-3">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($recent_orders as $order): ?>
                            <tr>
                                <td class="ps-3">
                                    <div class="fw-bold small" style="font-weight: 700;"><?= htmlspecialchars($order['user_name']) ?></div>
                                    <div class="text-muted" style="font-size: 10px; font-weight: 500;"><?= date('d M, Y', strtotime($order['created_at'])) ?></div>
                                </td>
                                <td class="small fw-bold">৳<?= number_format($order['amount']) ?></td>
                                <td>
                                    <span class="badge bg-<?= ($order['status'] == 'Completed') ? 'success' : 'warning' ?> bg-opacity-10 text-<?= ($order['status'] == 'Completed') ? 'success' : 'warning' ?> extra-small" style="font-size: 10px; font-weight: 700; padding: 4px 12px; border-radius: 30px;">
                                        <?= $order['status'] ?>
                                    </span>
                                </td>
                                <td class="text-end pe-3">
                                    <a href="orders.php" class="btn btn-sm" style="background: var(--primary-gradient); color: #fff; font-size: 10px; font-weight: 700; border-radius: 8px; padding: 4px 14px; border: none;">
                                        <i class="fas fa-arrow-right me-1"></i> View
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                            <?php if(empty($recent_orders)): ?>
                                <tr><td colspan="4" class="text-center p-4 text-muted small" style="font-weight: 500;">No recent orders.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        
        <!-- ====== Sidebar Stats ====== -->
        <div class="col-lg-4">
            <div class="card border-0 rounded-4 shadow-sm p-3 mb-4" style="border: 1px solid var(--border-color);">
                <h6 class="fw-bold mb-3 small text-uppercase" style="color: var(--dark-bg); letter-spacing: 0.5px;">
                    <i class="fas fa-database me-2" style="color: var(--primary-blue);"></i> Store Content
                </h6>
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <span class="small text-muted" style="font-weight: 600;"><i class="fas fa-images me-2" style="color: var(--primary-blue);"></i> Active Sliders</span>
                    <span class="badge" style="background: var(--primary-light); color: var(--primary-blue); font-weight: 700; padding: 4px 12px; border-radius: 30px;"><?= $total_sliders ?></span>
                </div>
                <div class="d-flex justify-content-between align-items-center">
                    <span class="small text-muted" style="font-weight: 600;"><i class="fas fa-box-open me-2" style="color: var(--primary-blue);"></i> Total Products</span>
                    <span class="badge" style="background: var(--primary-light); color: var(--primary-blue); font-weight: 700; padding: 4px 12px; border-radius: 30px;"><?= $total_products ?></span>
                </div>
            </div>

            <!-- ====== Quick Actions ====== -->
            <div class="card border-0 rounded-4 shadow-sm p-3" style="border: 1px solid var(--border-color);">
                <h6 class="fw-bold mb-3 small text-uppercase" style="color: var(--dark-bg); letter-spacing: 0.5px;">
                    <i class="fas fa-bolt me-2" style="color: var(--primary-blue);"></i> Quick Actions
                </h6>
                <div class="d-grid gap-2">
                    <a href="slider.php" class="btn btn-sm text-start py-2" style="background: var(--primary-light); color: var(--primary-blue); font-weight: 700; border: none; border-radius: 10px;">
                        <i class="fas fa-image me-2"></i> Add Promo Slider
                    </a>
                    <a href="product.php" class="btn btn-sm text-start py-2" style="background: var(--dark-bg); color: #fff; font-weight: 700; border: none; border-radius: 10px;">
                        <i class="fas fa-plus-circle me-2"></i> Add New Product
                    </a>
                    <a href="users.php" class="btn btn-sm text-start py-2" style="background: var(--primary-blue); color: #fff; font-weight: 700; border: none; border-radius: 10px;">
                        <i class="fas fa-user-plus me-2"></i> Manage Customers
                    </a>
                    <hr class="my-1 opacity-5">
                    <a href="../index.php" target="_blank" class="btn btn-sm py-2" style="background: var(--primary-gradient); color: #fff; font-weight: 700; border: none; border-radius: 10px;">
                        <i class="fas fa-external-link-alt me-2"></i> View Live Store
                    </a>
                </div>
            </div>
        </div>
    </div>
    </div>
</div>

<!-- ====== JavaScript ====== -->
<script>
    function toggleMenu() {
        document.getElementById('adminSidebar').classList.toggle('active');
        document.getElementById('overlay').classList.toggle('show');
    }
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="../assets/js/premium.js"></script>
</body>
</html>