<?php 
// 1. ডাটাবেস কনফিগারেশন
include 'config.php'; 

// 2. ফর্ম সাবমিট লজিক
$error = null;
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = trim($_POST['name'] ?? '');
    $whatsapp = trim($_POST['whatsapp'] ?? '');
    $email = strtolower(trim($_POST['email'] ?? ''));
    $raw_pass = (string)($_POST['password'] ?? '');

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Please enter a valid email address.";
    } elseif (strlen($raw_pass) < 6) {
        $error = "Password must be at least 6 characters long.";
    } else {
        try {
            $pass = password_hash($raw_pass, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("INSERT INTO users (name, whatsapp, email, password) VALUES (?, ?, ?, ?)");
            $stmt->execute([$name, $whatsapp, $email, $pass]);
            header("Location: login.php?registered=1");
            exit();
        } catch (PDOException $e) {
            if ($e->getCode() == 23000 || str_contains($e->getMessage(), 'UNIQUE') || str_contains($e->getMessage(), 'Duplicate')) {
                $error = "This email is already registered. Please login or use a different email.";
            } else {
                $error = "Registration error: " . $e->getMessage();
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Account - Register</title>
    
    <!-- ====== ফন্ট: Inter ====== -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>
    <link rel="stylesheet" href="assets/css/premium-theme.css"/>

    <style>
        /* =========================================
           ✅ SIGNUP PAGE UPDATED: 11 August 2026
           📌 Exact Match with Previous Blue Theme
           🔧 কালার পরিবর্তন: সবুজ → নীল (#1e2ab8)
        ========================================= */
        
        :root {
            --primary-blue: #1e2ab8;
            --primary-gradient: linear-gradient(135deg, #1e2ab8 0%, #4338ca 100%);
            --primary-hover: #0f172a;
            --primary-light: #e0e7ff;
            --border-color: #e2e8f0;
            --dark-bg: #0f172a;
            --text-slate: #64748b;
            --light-bg: #f8fafc;
            --card-bg: #ffffff;
        }

        /* ডার্ক মোড অটো */
        @media (prefers-color-scheme: dark) {
            :root {
                --card-bg: #1e293b;
                --light-bg: #0f172a;
                --dark-bg: #e2e8f0;
                --text-slate: #94a3b8;
                --border-color: #334155;
            }
            body { 
                background: radial-gradient(circle at 0% 0%, #0f172a 0%, #1e293b 100%) !important; 
            }
            .signup-card { 
                background: #1e293b; 
                border-color: #334155 !important; 
            }
            .signup-card::before { 
                background: linear-gradient(90deg, #1e2ab8, #4338ca) !important; 
            }
            .signup-header h2 { color: #e2e8f0; }
            .signup-header p { color: #94a3b8; }
            .brand-icon-wrapper { 
                background: #0f172a; 
                color: #60a5fa; 
                box-shadow: inset 0 0 0 1px rgba(30, 42, 184, 0.2);
            }
            .input-box input { 
                background: #0f172a; 
                border-color: #334155; 
                color: #e2e8f0; 
            }
            .input-box input:focus { 
                border-color: #60a5fa; 
                background: #1e293b; 
                box-shadow: 0 0 0 4px rgba(30, 42, 184, 0.15);
            }
            .input-box i { color: #64748b; }
            .input-box input:focus + i { color: #60a5fa; }
            .footer-links { border-top-color: #334155; }
            .footer-links a { color: #60a5fa; }
            .footer-links a:hover { color: #93bbfc; }
            .btn-back-store { color: #94a3b8 !important; }
            .btn-back-store:hover { color: #60a5fa !important; }
        }

        * { font-style: normal !important; }

        body {
            font-family: 'Inter', sans-serif;
            background: radial-gradient(circle at 0% 0%, #ffffff 0%, var(--light-bg) 100%);
            min-height: 100vh;
            margin: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px 0;
        }

        /* ====== মেইন কন্টেইনার ====== */
        .signup-wrapper {
            width: 100%;
            max-width: 460px;
            padding: 15px;
        }

        /* ====== সাইনআপ কার্ড ====== */
        .signup-card {
            background: var(--card-bg);
            border-radius: 24px;
            padding: 40px 35px;
            box-shadow: 0 15px 35px rgba(30, 42, 184, 0.04), 0 5px 15px rgba(0, 0, 0, 0.02);
            border: 1px solid var(--border-color);
            position: relative;
            overflow: hidden;
        }

        /* ====== টপ বর্ডার (নীল) ====== */
        .signup-card::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 5px;
            background: var(--primary-gradient);
        }

        /* ====== ব্র্যান্ড আইকন ====== */
        .brand-icon-wrapper {
            width: 65px;
            height: 65px;
            background: var(--primary-light);
            color: var(--primary-blue);
            border-radius: 18px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.8rem;
            margin: 0 auto 20px auto;
            box-shadow: inset 0 0 0 1px rgba(30, 42, 184, 0.1);
        }

        /* ====== হেডার ====== */
        .signup-header h2 {
            font-weight: 900;
            font-size: 1.75rem;
            color: var(--dark-bg);
            margin-bottom: 8px;
            letter-spacing: -0.5px;
            text-transform: uppercase;
        }

        .signup-header p {
            color: var(--text-slate);
            font-size: 0.95rem;
            margin-bottom: 30px;
            font-weight: 500;
        }

        /* ====== ইনপুট বক্স ====== */
        .input-box {
            position: relative;
            margin-bottom: 20px;
        }

        .input-box i {
            position: absolute;
            left: 18px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--text-slate);
            transition: all 0.25s ease;
            font-size: 0.95rem;
        }

        .input-box input {
            width: 100%;
            padding: 15px 20px 15px 50px;
            background: var(--light-bg);
            border: 1.5px solid var(--border-color);
            border-radius: 14px;
            font-size: 0.95rem;
            transition: all 0.25s ease;
            outline: none;
            color: var(--dark-bg);
            font-weight: 600;
        }

        .input-box input::placeholder {
            color: var(--text-slate);
            font-weight: 400;
        }

        .input-box input:focus {
            border-color: var(--primary-blue);
            background: var(--card-bg);
            box-shadow: 0 0 0 4px rgba(30, 42, 184, 0.08);
        }

        .input-box input:focus + i {
            color: var(--primary-blue);
        }

        /* ====== সাইনআপ বাটন (নীল) ====== */
        .btn-signup {
            background: var(--primary-gradient);
            color: #fff;
            padding: 15px;
            border: none;
            border-radius: 14px;
            width: 100%;
            font-weight: 900;
            font-size: 0.95rem;
            transition: all 0.3s ease;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            margin-top: 10px;
            box-shadow: 0 4px 15px rgba(30, 42, 184, 0.15);
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .btn-signup:hover {
            background: var(--primary-hover);
            transform: translateY(-2px);
            box-shadow: 0 8px 30px rgba(30, 42, 184, 0.25);
            color: #fff;
        }

        /* ====== ফুটার লিংক ====== */
        .footer-links {
            margin-top: 30px;
            text-align: center;
            font-size: 0.88rem;
            border-top: 1px solid var(--border-color);
            padding-top: 20px;
            font-weight: 600;
        }

        .footer-links p {
            color: var(--text-slate);
            margin-bottom: 8px;
        }

        .footer-links a {
            color: var(--primary-blue);
            text-decoration: none;
            font-weight: 700;
            transition: color 0.2s ease;
        }

        .footer-links a:hover {
            color: var(--primary-hover);
            text-decoration: underline;
        }

        .btn-back-store {
            color: var(--text-slate) !important;
            font-weight: 600 !important;
            text-decoration: none !important;
            display: inline-block;
            transition: all 0.2s ease;
        }
        
        .btn-back-store:hover {
            color: var(--primary-blue) !important;
            text-decoration: underline !important;
        }

        /* ====== রেসপনসিভ ====== */
        @media (max-width: 480px) {
            .signup-wrapper { padding: 10px; }
            .signup-card {
                padding: 30px 20px;
                border-radius: 20px;
            }
            .signup-header h2 {
                font-size: 1.4rem;
            }
            .brand-icon-wrapper {
                width: 55px;
                height: 55px;
                font-size: 1.5rem;
            }
            .input-box input {
                padding: 13px 16px 13px 44px;
                font-size: 0.85rem;
            }
            .btn-signup {
                padding: 13px;
                font-size: 0.85rem;
            }
            .footer-links {
                font-size: 0.8rem;
            }
        }
    </style>
</head>
<body>

<div class="signup-wrapper">
    <div class="signup-card animate__animated animate__fadeInUp">
        
        <!-- ====== ব্র্যান্ড আইকন ====== -->
        <div class="brand-icon-wrapper">
            <i class="fas fa-user-plus"></i>
        </div>

        <!-- ====== হেডার ====== -->
        <div class="signup-header text-center">
            <h2>Create Account</h2>
            <p>Join us to start shopping</p>
        </div>

        <?php if(!empty($error)): ?>
            <div class="alert alert-danger py-2 small mb-3 border-0 rounded-3 text-center" style="background: rgba(239, 68, 68, 0.12); color: #ef4444; font-weight: 700;">
                <i class="fas fa-exclamation-circle me-1"></i> <?= htmlspecialchars($error) ?>
            </div>
        <?php endif; ?>

        <!-- ====== সাইনআপ ফর্ম ====== -->
        <form method="POST">
            <div class="input-box">
                <i class="fas fa-user"></i>
                <input type="text" name="name" placeholder="Full Name" required autocomplete="name">
            </div>

            <div class="input-box">
                <i class="fab fa-whatsapp"></i>
                <input type="text" name="whatsapp" placeholder="WhatsApp Number" required autocomplete="tel">
            </div>

            <div class="input-box">
                <i class="fas fa-envelope"></i>
                <input type="email" name="email" placeholder="Email Address" required autocomplete="email">
            </div>

            <div class="input-box">
                <i class="fas fa-lock"></i>
                <input type="password" name="password" placeholder="Create Password" required>
            </div>

            <button type="submit" class="btn-signup">
                <span>Sign Up</span> <i class="fas fa-arrow-right"></i>
            </button>
        </form>

        <!-- ====== ফুটার লিংক ====== -->
        <div class="footer-links">
            <p>Already have an account? <a href="login.php">Login</a></p>
            <a href="index.php" class="btn-back-store">
                <i class="fas fa-chevron-left me-1"></i> Back to Store
            </a>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="assets/js/premium.js"></script>
</body>
</html>