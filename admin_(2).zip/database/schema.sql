SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

CREATE TABLE IF NOT EXISTS `categories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `whatsapp` varchar(20) NOT NULL,
  `email` varchar(190) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('user','admin') NOT NULL DEFAULT 'user',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_users_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `products` (
  `id` int NOT NULL AUTO_INCREMENT,
  `category_id` int DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `product_type` enum('downloadable','subscription') NOT NULL,
  `regular_price` decimal(10,2) NOT NULL,
  `offer_price` decimal(10,2) NOT NULL,
  `stock` int NOT NULL DEFAULT 1,
  `drive_link` text DEFAULT NULL,
  `file_path` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `variations` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_products_category` (`category_id`),
  CONSTRAINT `fk_products_category` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `orders` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `product_id` int NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `status` enum('Pending','Processing','Completed','Rejected') NOT NULL DEFAULT 'Pending',
  `payment_method` varchar(50) NOT NULL DEFAULT 'Manual',
  `sub_email` varchar(190) DEFAULT NULL,
  `sender_number` varchar(30) DEFAULT NULL,
  `trx_id` varchar(100) NOT NULL,
  `payment_data` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_orders_user` (`user_id`),
  KEY `idx_orders_product` (`product_id`),
  KEY `idx_orders_status` (`status`),
  UNIQUE KEY `uq_orders_trx_id` (`trx_id`),
  CONSTRAINT `fk_orders_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_orders_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `settings` (
  `id` int NOT NULL DEFAULT 1,
  `site_name` varchar(100) NOT NULL DEFAULT 'Digital Shop',
  `site_tagline` varchar(255) DEFAULT 'Premium Digital Subscriptions & Downloads',
  `logo` varchar(255) DEFAULT 'uploads/jhx_digital_shop_logo_v2.svg',
  `favicon` varchar(255) DEFAULT '',
  `yt_link` varchar(255) DEFAULT '#',
  `fb_link` varchar(255) DEFAULT '#',
  `tg_link` varchar(255) DEFAULT '',
  `tg_user` varchar(100) DEFAULT '',
  `whatsapp_number` varchar(30) DEFAULT NULL,
  `site_status` tinyint(1) NOT NULL DEFAULT 1,
  `auto_approve_orders` tinyint(1) NOT NULL DEFAULT 0,
  `enable_manual_payment` tinyint(1) NOT NULL DEFAULT 1,
  `enable_auto_payment` tinyint(1) NOT NULL DEFAULT 0,
  `hostneko_api_key` varchar(255) DEFAULT '',
  `hostneko_currency_rate` varchar(20) DEFAULT '1',
  `currency_symbol` varchar(10) NOT NULL DEFAULT '৳',
  `meta_title` text,
  `meta_desc` text,
  `meta_keys` text,
  `bkash_number` varchar(30) DEFAULT NULL,
  `nagad_number` varchar(30) DEFAULT NULL,
  `rocket_number` varchar(30) DEFAULT NULL,
  `upay_number` varchar(30) DEFAULT NULL,
  `manual_payment_type` varchar(20) DEFAULT 'Personal',
  `manual_payment_note` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `sliders` (
  `id` int NOT NULL AUTO_INCREMENT,
  `image` varchar(255) NOT NULL,
  `link` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `settings` (`id`, `site_name`, `site_tagline`, `logo`, `tg_link`, `tg_user`, `site_status`, `auto_approve_orders`, `enable_manual_payment`, `enable_auto_payment`, `hostneko_api_key`, `currency_symbol`, `meta_title`, `meta_desc`, `meta_keys`, `manual_payment_type`)
VALUES (1, 'Digital Shop', 'Premium Digital Subscriptions & Downloads', 'uploads/jhx_digital_shop_logo_v2.svg', '', '', 1, 0, 1, 0, '', '৳', 'Digital Shop | Premium Subscriptions', 'Premium digital subscriptions and downloadable products with instant delivery.', 'digital products, subscriptions, downloads, manual payment', 'Personal')
ON DUPLICATE KEY UPDATE `id` = `id`;

SET FOREIGN_KEY_CHECKS = 1;
