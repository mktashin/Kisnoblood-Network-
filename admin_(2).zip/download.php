<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require __DIR__ . '/config.php';

function download_notice(string $title, string $message, int $statusCode = 404, string $color = 'red', string $icon = 'fa-circle-exclamation', ?int $orderId = null): never {
    http_response_code($statusCode);
    $siteName = htmlspecialchars($GLOBALS['set']['site_name'] ?? 'Digital Shop');
    $accentBg = $color === 'amber' ? 'rgba(245, 158, 11, 0.12)' : 'rgba(239, 68, 68, 0.12)';
    $accentBorder = $color === 'amber' ? '#f59e0b' : '#ef4444';
    $accentColor = $color === 'amber' ? '#fbbf24' : '#f87171';
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title><?= htmlspecialchars($title) ?> | <?= $siteName ?></title>
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800;900&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
        <style>
            * { box-sizing: border-box; }
            body { font-family: 'Inter', sans-serif; background: #0b0f19; color: #f8fafc; min-height: 100vh; display: grid; place-items: center; margin: 0; padding: 24px; }
            .card { max-width: 500px; width: 100%; background: #131d31; border: 1px solid rgba(255,255,255,0.08); border-radius: 26px; padding: 40px 32px; text-align: center; box-shadow: 0 25px 60px rgba(0,0,0,0.5); }
            .icon-box { width: 72px; height: 72px; border-radius: 50%; background: <?= $accentBg ?>; border: 2px solid <?= $accentBorder ?>; color: <?= $accentColor ?>; display: grid; place-items: center; margin: 0 auto 22px; font-size: 2rem; }
            h2 { font-size: 1.35rem; margin: 0 0 12px; font-weight: 800; color: #fff; letter-spacing: -0.3px; }
            p { font-size: 0.94rem; color: #94a3b8; line-height: 1.65; margin: 0 0 28px; }
            .btn-group { display: flex; gap: 12px; justify-content: center; flex-wrap: wrap; }
            .btn { display: inline-flex; align-items: center; gap: 8px; background: #2563eb; color: #fff; padding: 12px 24px; border-radius: 14px; font-weight: 700; text-decoration: none; font-size: 0.9rem; transition: all 0.2s ease; box-shadow: 0 6px 18px rgba(37, 99, 235, 0.35); }
            .btn:hover { background: #1d4ed8; transform: translateY(-2px); }
            .btn-outline { background: rgba(255,255,255,0.06); border: 1px solid rgba(255,255,255,0.12); color: #cbd5e1; box-shadow: none; }
            .btn-outline:hover { background: rgba(255,255,255,0.12); color: #fff; transform: translateY(-2px); }
        </style>
    </head>
    <body>
        <div class="card">
            <div class="icon-box"><i class="fa-solid <?= htmlspecialchars($icon) ?>"></i></div>
            <h2><?= htmlspecialchars($title) ?></h2>
            <p><?= htmlspecialchars($message) ?></p>
            <div class="btn-group">
                <a href="orders.php" class="btn"><i class="fas fa-arrow-left"></i> View My Orders</a>
                <?php if($orderId): ?>
                    <a href="invoice.php?order_id=<?= (int)$orderId ?>" class="btn btn-outline"><i class="fas fa-file-invoice"></i> View Invoice</a>
                <?php endif; ?>
            </div>
        </div>
    </body>
    </html>
    <?php
    exit();
}

function download_error(string $message, int $status = 404): never {
    download_notice('Download Unavailable', $message, $status, 'red', 'fa-circle-exclamation');
}

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$orderId = isset($_GET['order_id']) && is_numeric($_GET['order_id']) ? (int)$_GET['order_id'] : (int)(filter_input(INPUT_GET, 'order_id', FILTER_VALIDATE_INT) ?: 0);
if (!$orderId || !$pdo) {
    download_notice('Invalid Request', 'Order ID was not provided or database connection is not established.', 404, 'red', 'fa-circle-exclamation');
}

$stmt = $pdo->prepare("SELECT orders.id, orders.status, orders.trx_id, products.title, products.product_type, products.file_path, products.drive_link
                      FROM orders JOIN products ON products.id = orders.product_id
                      WHERE orders.id = ? AND orders.user_id = ? LIMIT 1");
$stmt->execute([$orderId, (int)$_SESSION['user_id']]);
$order = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$order) {
    download_notice('Order Not Found', 'The requested order could not be found under your account. Please check your orders page.', 404, 'red', 'fa-circle-question');
}

// 1. Check order approval status
if ($order['status'] === 'Pending') {
    download_notice(
        'Payment Under Verification',
        'Your manual payment for Order #' . $orderId . ' is currently pending admin verification (Trx ID: ' . htmlspecialchars($order['trx_id'] ?: 'Pending') . '). Once the admin verifies your transaction and activates your order, your digital download will be unlocked immediately!',
        200,
        'amber',
        'fa-clock',
        $orderId
    );
} elseif ($order['status'] === 'Rejected') {
    download_notice(
        'Order Rejected',
        'This order has been marked as Rejected. Please contact support or submit a new order with valid transaction details.',
        403,
        'red',
        'fa-circle-xmark',
        $orderId
    );
} elseif ($order['status'] !== 'Completed') {
    download_notice(
        'Order Not Active',
        'This order is currently ' . htmlspecialchars($order['status']) . '. Once payment is confirmed and the order is activated by the admin, your download will become active.',
        403,
        'red',
        'fa-circle-exclamation',
        $orderId
    );
}

// 2. Order is Completed! Resolve download asset
$storedPath = trim((string)($order['file_path'] ?? ''));
$driveLink = trim((string)($order['drive_link'] ?? ''));

// If file_path is an external cloud link (Drive, Mega, etc.)
if (preg_match('#^https?://#i', $storedPath)) {
    header('Location: ' . $storedPath, true, 302);
    exit();
}

$file = null;
if ($storedPath !== '') {
    $normalizedStoredPath = str_replace('\\', '/', $storedPath);
    $fileName = basename($normalizedStoredPath);

    if ($fileName !== '' && $fileName !== '.' && $fileName !== '..' && !str_contains($fileName, "\0")) {
        // Candidates for where the file could be located on disk
        $candidates = [
            dirname(__DIR__) . '/downloads/' . $fileName,
            __DIR__ . '/downloads/' . $fileName,
            __DIR__ . '/' . ltrim($normalizedStoredPath, '/'),
            __DIR__ . '/uploads/' . $fileName,
            __DIR__ . '/' . $fileName,
        ];
        if (defined('JHX_PRIVATE_DOWNLOAD_DIR')) {
            $candidates[] = rtrim(JHX_PRIVATE_DOWNLOAD_DIR, '/\\') . DIRECTORY_SEPARATOR . $fileName;
        }

        foreach ($candidates as $cand) {
            $candReal = @realpath($cand);
            if ($candReal && is_file($candReal) && is_readable($candReal)) {
                $file = $candReal;
                break;
            }
        }
    }
}

// 3. Fallback to Drive Link if local file is absent or not attached
if (!$file) {
    if ($driveLink !== '' && preg_match('#^https?://#i', $driveLink)) {
        header('Location: ' . $driveLink, true, 302);
        exit();
    }

    download_notice(
        'Digital Asset Unavailable',
        'The digital product file has not been uploaded yet or cloud drive link is missing. Please contact store support to receive your file.',
        404,
        'red',
        'fa-box-open',
        $orderId
    );
}

// 4. Stream physical file safely
$downloadName = preg_replace('/[^A-Za-z0-9._-]+/', '_', (string)$order['title']) ?: 'digital-product';
$extension = strtolower(pathinfo($file, PATHINFO_EXTENSION));
if ($extension !== '' && !str_ends_with(strtolower($downloadName), '.' . $extension)) {
    $downloadName .= '.' . $extension;
}

$mimeTypes = [
    'zip'  => 'application/zip',
    'rar'  => 'application/x-rar-compressed',
    '7z'   => 'application/x-7z-compressed',
    'tar'  => 'application/x-tar',
    'gz'   => 'application/gzip',
    'pdf'  => 'application/pdf',
    'txt'  => 'text/plain',
    'apk'  => 'application/vnd.android.package-archive',
    'iso'  => 'application/x-iso9660-image',
    'json' => 'application/json',
];
$mimeType = $mimeTypes[$extension] ?? 'application/octet-stream';
$fileSize = (int)@filesize($file);

while (ob_get_level() > 0) {
    ob_end_clean();
}

header('Content-Description: File Transfer');
header('Content-Type: ' . $mimeType);
header('Content-Disposition: attachment; filename="' . $downloadName . '"');
header('Content-Transfer-Encoding: binary');
header('Expires: 0');
header('Cache-Control: must-revalidate, post-check=0, pre-check=0, private');
header('Pragma: public');
if ($fileSize > 0) {
    header('Content-Length: ' . $fileSize);
}
header('X-Content-Type-Options: nosniff');

readfile($file);
exit();
