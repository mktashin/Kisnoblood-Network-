<?php 
include 'config.php'; 
include 'header.php'; 
?>

<style>
    /* =========================================
       ✨ ULTRA-MODERN PREMIUM HOMEPAGE STYLING
       📌 Desktop & Mobile Optimized
    ========================================= */
    .home-container {
        width: min(100%, 1280px);
        padding: clamp(10px, 2.5vw, 24px) clamp(12px, 2.5vw, 24px);
        margin: 0 auto;
    }

    /* ====== HERO SLIDER ====== */
    #heroSlider {
        width: 100%;
        border-radius: clamp(14px, 2.5vw, 24px);
        overflow: hidden;
        box-shadow: var(--shadow-md);
        margin-bottom: clamp(20px, 3.5vw, 36px);
        border: 1px solid var(--border-color);
        background: var(--bg-card);
        aspect-ratio: 2.5 / 1;
        position: relative;
    }

    @media (max-width: 768px) {
        #heroSlider {
            aspect-ratio: 2.1 / 1;
            border-radius: 16px;
        }
    }

    .carousel-inner, .carousel-item {
        height: 100%;
        width: 100%;
    }

    .carousel-item img {
        width: 100%;
        height: 100%;
        object-fit: cover;
        object-position: center;
        transition: transform 0.6s ease;
    }

    .carousel-item:hover img {
        transform: scale(1.02);
    }

    .carousel-control-prev, .carousel-control-next {
        width: 44px;
        height: 44px;
        background: rgba(15, 23, 42, 0.6);
        backdrop-filter: blur(8px);
        border-radius: 50%;
        top: 50%;
        transform: translateY(-50%);
        margin: 0 16px;
        opacity: 0;
        transition: all 0.3s ease;
    }

    #heroSlider:hover .carousel-control-prev,
    #heroSlider:hover .carousel-control-next {
        opacity: 1;
    }

    /* ====== TRUST / FEATURE HIGHLIGHTS BAR ====== */
    .trust-features-bar {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        gap: 12px;
        margin-bottom: clamp(24px, 4vw, 42px);
    }

    @media (max-width: 992px) {
        .trust-features-bar {
            grid-template-columns: repeat(2, 1fr);
            gap: 10px;
        }
    }

    @media (max-width: 480px) {
        .trust-features-bar {
            grid-template-columns: repeat(2, 1fr);
            gap: 8px;
        }
    }

    .trust-card {
        background: var(--bg-card);
        border: 1px solid var(--border-color);
        border-radius: var(--radius);
        padding: clamp(10px, 1.8vw, 16px);
        display: flex;
        align-items: center;
        gap: 12px;
        box-shadow: var(--shadow-sm);
        transition: var(--transition);
    }

    .trust-card:hover {
        transform: translateY(-2px);
        border-color: var(--primary-light);
        box-shadow: var(--shadow-md);
    }

    .trust-icon {
        width: clamp(38px, 4.5vw, 46px);
        height: clamp(38px, 4.5vw, 46px);
        border-radius: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.15rem;
        flex-shrink: 0;
    }

    .trust-icon.bolt { background: #eff6ff; color: #2563eb; }
    .trust-icon.shield { background: #ecfdf5; color: #059669; }
    .trust-icon.headset { background: #fdf4ff; color: #c026d3; }
    .trust-icon.wallet { background: #fffbeb; color: #d97706; }

    .trust-text h6 {
        font-weight: 800;
        margin: 0;
        font-size: clamp(0.78rem, 1.2vw, 0.9rem);
        color: var(--text-dark);
    }

    .trust-text p {
        margin: 0;
        font-size: clamp(0.65rem, 1vw, 0.74rem);
        color: var(--text-muted);
        font-weight: 600;
    }

    /* ====== SEARCH & CATEGORY FILTER BAR ====== */
    .filter-header-bar {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 14px;
        flex-wrap: wrap;
        margin-bottom: 24px;
    }

    .live-search-box {
        position: relative;
        flex: 1;
        min-width: 240px;
        max-width: 420px;
    }

    .live-search-box input {
        width: 100%;
        padding: 10px 16px 10px 42px;
        border-radius: 30px;
        border: 1.5px solid var(--border-color);
        background: var(--bg-card);
        color: var(--text-dark);
        font-size: 0.88rem;
        font-weight: 600;
        transition: var(--transition);
    }

    .live-search-box input:focus {
        border-color: var(--primary-blue);
        box-shadow: 0 0 0 4px rgba(37, 99, 235, 0.12);
        outline: none;
    }

    .live-search-box i {
        position: absolute;
        left: 16px;
        top: 50%;
        transform: translateY(-50%);
        color: var(--text-muted);
        font-size: 0.95rem;
    }

    .category-pills-scroll {
        display: flex;
        gap: 8px;
        overflow-x: auto;
        padding-bottom: 6px;
        scrollbar-width: none;
        -webkit-overflow-scrolling: touch;
    }

    .category-pills-scroll::-webkit-scrollbar { display: none; }

    .category-pill-btn {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        padding: 8px 16px;
        border-radius: 30px;
        border: 1px solid var(--border-color);
        background: var(--bg-card);
        color: var(--text-muted);
        font-size: 0.8rem;
        font-weight: 700;
        text-decoration: none;
        white-space: nowrap;
        transition: var(--transition);
    }

    .category-pill-btn:hover, .category-pill-btn.active {
        background: var(--primary-gradient);
        color: #fff !important;
        border-color: transparent;
        box-shadow: 0 4px 14px rgba(37, 99, 235, 0.25);
        transform: translateY(-1px);
    }

    /* ====== CATEGORY SECTION HEADER ====== */
    .category-section-header {
        display: flex;
        align-items: center;
        gap: 12px;
        margin: clamp(28px, 4.5vw, 44px) 0 18px;
    }

    .category-icon-indicator {
        width: 38px;
        height: 38px;
        border-radius: 12px;
        background: var(--primary-gradient);
        color: #fff;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.05rem;
        box-shadow: 0 4px 14px rgba(37, 99, 235, 0.3);
        flex-shrink: 0;
        transition: var(--transition);
    }

    .category-section-header:hover .category-icon-indicator {
        transform: scale(1.08) rotate(5deg);
    }

    .category-section-header h4 {
        font-weight: 900;
        font-size: clamp(1.15rem, 2vw, 1.4rem);
        margin: 0;
        color: var(--text-dark);
        letter-spacing: -0.3px;
    }

    .category-line {
        flex: 1;
        height: 2px;
        background: linear-gradient(90deg, var(--border-color) 0%, transparent 100%);
    }

    /* ====== PRODUCT CARDS GRID ====== */
    .product-card {
        background: var(--bg-card);
        border: 1px solid var(--border-color);
        border-radius: var(--radius);
        overflow: hidden;
        box-shadow: var(--shadow-sm);
        transition: var(--transition);
        display: flex;
        flex-direction: column;
        height: 100%;
        position: relative;
    }

    .product-card:hover {
        transform: translateY(-4px);
        box-shadow: var(--shadow-md);
        border-color: rgba(37, 99, 235, 0.4);
    }

    .card-img-wrap {
        position: relative;
        width: 100%;
        aspect-ratio: 1 / 1;
        overflow: hidden;
        background: #0f172a;
    }

    .card-img-wrap img {
        width: 100%;
        height: 100%;
        object-fit: cover;
        transition: transform 0.4s ease;
        display: block;
    }

    .product-card:hover .card-img-wrap img {
        transform: scale(1.05);
    }

    /* Discount Badge */
    .badge-discount-tag {
        position: absolute;
        top: 10px;
        left: 10px;
        background: linear-gradient(135deg, #ef4444 0%, #f97316 100%);
        color: #fff;
        font-size: 0.68rem;
        font-weight: 800;
        padding: 4px 10px;
        border-radius: 30px;
        letter-spacing: 0.3px;
        box-shadow: 0 4px 10px rgba(239, 68, 68, 0.35);
        z-index: 2;
    }

    .badge-type-tag {
        position: absolute;
        top: 10px;
        right: 10px;
        background: rgba(15, 23, 42, 0.75);
        backdrop-filter: blur(6px);
        color: #fff;
        font-size: 0.65rem;
        font-weight: 700;
        padding: 4px 9px;
        border-radius: 20px;
        z-index: 2;
        border: 1px solid rgba(255, 255, 255, 0.15);
    }

    .product-card-body {
        padding: clamp(12px, 2vw, 16px);
        display: flex;
        flex-direction: column;
        flex: 1;
    }

    .product-card-title {
        font-size: clamp(0.85rem, 1.2vw, 0.98rem);
        font-weight: 800;
        color: var(--text-dark);
        line-height: 1.35;
        margin-bottom: 8px;
        display: -webkit-box;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
        overflow: hidden;
        min-height: 2.7em;
    }

    .product-price-row {
        display: flex;
        align-items: baseline;
        gap: 8px;
        margin-top: auto;
        margin-bottom: 12px;
    }

    .price-offer {
        font-size: clamp(1.1rem, 1.6vw, 1.3rem);
        font-weight: 900;
        color: var(--primary-blue);
        letter-spacing: -0.3px;
    }

    .price-regular {
        font-size: 0.8rem;
        font-weight: 700;
        color: var(--text-muted);
        text-decoration: line-through;
    }

    .btn-card-buy {
        width: 100%;
        background: var(--primary-gradient);
        color: #fff !important;
        border: none;
        border-radius: var(--radius-sm);
        padding: 10px 14px;
        font-size: 0.84rem;
        font-weight: 800;
        text-transform: uppercase;
        letter-spacing: 0.4px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 7px;
        text-decoration: none;
        box-shadow: 0 4px 12px rgba(37, 99, 235, 0.2);
        transition: var(--transition);
    }

    .btn-card-buy:hover {
        background: var(--primary-gradient-hover);
        transform: translateY(-2px);
        box-shadow: 0 6px 18px rgba(37, 99, 235, 0.35);
        color: #fff !important;
    }

    /* ====== CUSTOMER REVIEWS AUTO SLIDER ====== */
    .reviews-section-card {
        background: var(--bg-card);
        border: 1px solid var(--border-color);
        border-radius: var(--radius);
        padding: clamp(20px, 3.5vw, 36px);
        margin-top: clamp(36px, 5vw, 56px);
        box-shadow: var(--shadow-sm);
        overflow: hidden;
    }

    .reviews-slider-viewport {
        display: flex;
        gap: 16px;
        overflow-x: auto;
        scroll-behavior: smooth;
        scrollbar-width: none;
        -webkit-overflow-scrolling: touch;
        padding: 8px 4px 14px;
    }

    .reviews-slider-viewport::-webkit-scrollbar {
        display: none;
    }

    .review-slide-card {
        flex: 0 0 360px;
        max-width: 86vw;
        min-height: 200px;
    }

    @media (max-width: 576px) {
        .review-slide-card {
            flex: 0 0 290px;
            max-width: 84vw;
        }
    }

    .review-bubble {
        background: var(--bg-card-subtle);
        border: 1px solid var(--border-color);
        border-radius: 18px;
        padding: 20px;
        height: 100%;
        display: flex;
        flex-direction: column;
        transition: var(--transition);
    }

    .review-bubble:hover {
        transform: translateY(-4px);
        border-color: var(--primary-blue);
        box-shadow: var(--shadow-md);
    }

    .btn-review-nav {
        width: 38px;
        height: 38px;
        border-radius: 50%;
        border: 1px solid var(--border-color);
        background: var(--bg-card);
        color: var(--text-dark);
        display: inline-flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        font-size: 0.9rem;
        transition: var(--transition);
        box-shadow: var(--shadow-sm);
    }

    .btn-review-nav:hover {
        background: var(--primary-gradient);
        color: #fff;
        border-color: transparent;
        transform: scale(1.08);
        box-shadow: 0 4px 14px rgba(37, 99, 235, 0.25);
    }
</style>

<div class="home-container">

    <!-- ==========================================
       1. HERO SLIDER BANNER
    ========================================== -->
    <?php
    try {
        $sliders = $pdo->query("SELECT * FROM sliders ORDER BY id ASC")->fetchAll(PDO::FETCH_ASSOC);
    } catch (Exception $e) {
        $sliders = [];
    }
    if(!empty($sliders)):
    ?>
    <div id="heroSlider" class="carousel slide carousel-fade" data-bs-ride="carousel" data-bs-interval="4000">
        <div class="carousel-indicators">
            <?php foreach($sliders as $idx => $s): ?>
                <button type="button" data-bs-target="#heroSlider" data-bs-slide-to="<?= $idx ?>" class="<?= $idx === 0 ? 'active' : '' ?>" aria-label="Slide <?= $idx + 1 ?>"></button>
            <?php endforeach; ?>
        </div>
        <div class="carousel-inner">
            <?php foreach($sliders as $idx => $s): ?>
                <div class="carousel-item <?= $idx === 0 ? 'active' : '' ?>">
                    <?php if(!empty($s['link'])): ?>
                        <a href="<?= htmlspecialchars($s['link']) ?>">
                            <img src="<?= htmlspecialchars($s['image']) ?>" alt="<?= htmlspecialchars($s['title'] ?? 'Banner') ?>" loading="<?= $idx === 0 ? 'eager' : 'lazy' ?>">
                        </a>
                    <?php else: ?>
                        <img src="<?= htmlspecialchars($s['image']) ?>" alt="<?= htmlspecialchars($s['title'] ?? 'Banner') ?>" loading="<?= $idx === 0 ? 'eager' : 'lazy' ?>">
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#heroSlider" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#heroSlider" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
        </button>
    </div>
    <?php endif; ?>

    <!-- ==========================================
       2. TRUST & FEATURES BAR
    ========================================== -->
    <div class="trust-features-bar">
        <div class="trust-card">
            <div class="trust-icon bolt"><i class="fas fa-bolt"></i></div>
            <div class="trust-text">
                <h6>Instant Delivery</h6>
                <p>Automated & fast setup</p>
            </div>
        </div>
        <div class="trust-card">
            <div class="trust-icon shield"><i class="fas fa-shield-halved"></i></div>
            <div class="trust-text">
                <h6>100% Genuine</h6>
                <p>Full warranty guarantee</p>
            </div>
        </div>
        <div class="trust-card">
            <div class="trust-icon headset"><i class="fas fa-headset"></i></div>
            <div class="trust-text">
                <h6>24/7 Live Support</h6>
                <p>Instant WhatsApp & Help</p>
            </div>
        </div>
        <div class="trust-card">
            <div class="trust-icon wallet"><i class="fas fa-wallet"></i></div>
            <div class="trust-text">
                <h6>Easy Payment</h6>
                <p>bKash, Nagad, Cards</p>
            </div>
        </div>
    </div>

    <!-- ==========================================
       3. LIVE SEARCH & CATEGORY PILLS BAR
    ========================================== -->
    <div class="filter-header-bar" id="products">
        <div class="live-search-box">
            <i class="fas fa-search"></i>
            <input type="text" id="storeSearchInput" placeholder="Search digital subscriptions & tools..." onkeyup="filterProductsLive()">
        </div>

        <div class="category-pills-scroll">
            <a href="#products" class="category-pill-btn active" onclick="showAllCategories(this, event)">
                <i class="fas fa-border-all"></i> All Categories
            </a>
            <?php
            $cats = $pdo->query("SELECT * FROM categories ORDER BY id ASC")->fetchAll();
            foreach($cats as $cat):
            ?>
                <a href="#cat-<?= $cat['id'] ?>" class="category-pill-btn" onclick="filterByCategory('cat-section-<?= $cat['id'] ?>', this, event)">
                    <?= htmlspecialchars($cat['name']) ?>
                </a>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- ==========================================
       4. PRODUCTS CATEGORY LOOP
    ========================================== -->
    <?php
    $catCounter = 0;
    foreach($cats as $cat): 
        $stmt = $pdo->prepare("SELECT * FROM products WHERE category_id = ? ORDER BY id DESC");
        $stmt->execute([$cat['id']]);
        $products = $stmt->fetchAll();
        
        if($products):
            $catCounter++;
            $cat_name_l = strtolower($cat['name'] ?? '');
            if (strpos($cat_name_l, 'sub') !== false || strpos($cat_name_l, 'prem') !== false) {
                $cat_icon = 'fa-solid fa-crown';
            } elseif (strpos($cat_name_l, 'tool') !== false || strpos($cat_name_l, 'soft') !== false || strpos($cat_name_l, 'app') !== false) {
                $cat_icon = 'fa-solid fa-wand-magic-sparkles';
            } elseif (strpos($cat_name_l, 'down') !== false || strpos($cat_name_l, 'file') !== false || strpos($cat_name_l, 'code') !== false) {
                $cat_icon = 'fa-solid fa-bolt';
            } else {
                $cat_icon = 'fa-solid fa-crown';
            }
    ?>
        <div class="category-block" id="cat-section-<?= $cat['id'] ?>">
            <!-- Category Title Header -->
            <div class="category-section-header">
                <div class="category-icon-indicator">
                    <i class="<?= $cat_icon ?>"></i>
                </div>
                <h4><?= htmlspecialchars($cat['name']) ?></h4>
                <div class="category-line"></div>
            </div>

            <!-- Products Grid: 4 cols Desktop, 3 cols Tablet, 2 cols Mobile -->
            <div class="row g-2 g-md-3 g-lg-4 mb-4">
                <?php 
                foreach($products as $p): 
                    $discount = $p['regular_price'] - $p['offer_price'];
                ?>
                    <div class="col-6 col-md-4 col-lg-3 product-item-col" data-title="<?= strtolower(htmlspecialchars($p['title'])) ?>">
                        <div class="product-card">
                            
                            <!-- Image Wrap with Badges -->
                            <div class="card-img-wrap">
                                <?php if($discount > 0): ?>
                                    <span class="badge-discount-tag">
                                        <i class="fas fa-tags me-1"></i> Save ৳<?= number_format($discount, 0) ?>
                                    </span>
                                <?php endif; ?>

                                <span class="badge-type-tag">
                                    <?= $p['product_type'] === 'subscription' ? '🔄 Subscription' : '📥 Download' ?>
                                </span>

                                <a href="product.php?id=<?= $p['id'] ?>">
                                    <img src="<?= htmlspecialchars($p['image']) ?>" alt="<?= htmlspecialchars($p['title']) ?>" loading="lazy">
                                </a>
                            </div>
                            
                            <!-- Card Content -->
                            <div class="product-card-body">
                                <a href="product.php?id=<?= $p['id'] ?>" class="text-decoration-none">
                                    <h5 class="product-card-title"><?= htmlspecialchars($p['title']) ?></h5>
                                </a>
                                
                                <!-- Price -->
                                <div class="product-price-row">
                                    <span class="price-offer">৳<?= number_format($p['offer_price'], 0) ?></span>
                                    <?php if($p['regular_price'] > $p['offer_price']): ?>
                                        <span class="price-regular">৳<?= number_format($p['regular_price'], 0) ?></span>
                                    <?php endif; ?>
                                </div>
                                
                                <!-- CTA Button -->
                                <a href="product.php?id=<?= $p['id'] ?>" class="btn-card-buy">
                                    <i class="fas fa-shopping-cart"></i> Buy Now
                                </a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    <?php 
        endif;
    endforeach; 
    ?>

    <!-- ==========================================
       5. CLIENT REVIEWS AUTO SLIDER SECTION
    ========================================== -->
    <?php
    $home_reviews = $pdo->query("SELECT * FROM reviews WHERE status = 1 ORDER BY sort_order ASC, id DESC")->fetchAll(PDO::FETCH_ASSOC);
    if (!empty($home_reviews)):
    ?>
    <div class="reviews-section-card">
        <div class="d-flex align-items-center justify-content-between mb-4 flex-wrap gap-2">
            <div>
                <h3 class="fw-bold mb-1 font-heading" style="color:var(--text-dark); font-size:clamp(1.2rem, 2.5vw, 1.6rem);">
                    <i class="fas fa-star text-warning me-2"></i> What Our Clients Say
                </h3>
                <p class="text-muted small mb-0 fw-bold">Verified reviews and feedback from happy customers</p>
            </div>
            <div class="d-flex align-items-center gap-3">
                <div class="d-flex align-items-center gap-2">
                    <div class="text-warning fs-5">
                        <i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i>
                    </div>
                    <span class="fw-bold fs-5" style="color:var(--text-dark);">4.9/5</span>
                </div>
                <!-- Slider Nav Controls -->
                <div class="d-flex gap-2">
                    <button type="button" class="btn-review-nav" onclick="slideReviewsPrev()" aria-label="Previous Review" title="Previous Review">
                        <i class="fas fa-chevron-left"></i>
                    </button>
                    <button type="button" class="btn-review-nav" onclick="slideReviewsNext()" aria-label="Next Review" title="Next Review">
                        <i class="fas fa-chevron-right"></i>
                    </button>
                </div>
            </div>
        </div>

        <!-- Horizontal Smooth Auto-Slide Viewport -->
        <div class="reviews-slider-viewport" id="reviewsSliderViewport" onmouseenter="pauseReviewAutoSlide()" onmouseleave="startReviewAutoSlide()" ontouchstart="pauseReviewAutoSlide()" ontouchend="startReviewAutoSlide()">
            <?php foreach($home_reviews as $rev): ?>
                <div class="review-slide-card">
                    <div class="review-bubble">
                        <div class="d-flex align-items-center justify-content-between mb-3">
                            <div class="d-flex align-items-center gap-2">
                                <?php if(!empty($rev['avatar'])): ?>
                                    <img src="<?= htmlspecialchars($rev['avatar']) ?>" class="rounded-circle" style="width:42px; height:42px; object-fit:cover;">
                                <?php else: ?>
                                    <div class="rounded-circle d-flex align-items-center justify-content-center fw-bold" style="width:42px; height:42px; background:var(--primary-gradient); color:#fff; font-size:1rem;">
                                        <?= strtoupper(substr($rev['name'], 0, 1)) ?>
                                    </div>
                                <?php endif; ?>
                                <div>
                                    <div class="fw-bold" style="color:var(--text-dark); font-size:0.92rem;"><?= htmlspecialchars($rev['name']) ?></div>
                                    <span class="badge bg-success-subtle text-success" style="font-size:0.68rem; font-weight:700;">
                                        <i class="fas fa-check-circle me-1"></i> Verified Buyer
                                    </span>
                                </div>
                            </div>
                            <div class="text-warning small">
                                <?php 
                                $r = round($rev['rating']); 
                                for($s=1; $s<=5; $s++) {
                                    echo $s <= $r ? '<i class="fas fa-star"></i>' : '<i class="far fa-star text-muted"></i>';
                                }
                                ?>
                            </div>
                        </div>

                        <p class="text-muted small mb-3" style="line-height:1.6; font-size:0.88rem;">
                            "<?= htmlspecialchars($rev['comment']) ?>"
                        </p>

                        <div class="mt-auto pt-2 border-top d-flex justify-content-between align-items-center" style="border-color:var(--border-color) !important;">
                            <span class="text-success small fw-bold" style="font-size:0.75rem;"><i class="fas fa-circle-check me-1"></i> 100% Recommended</span>
                            <small class="text-muted" style="font-size:0.72rem;"><i class="far fa-clock me-1"></i> <?= date('d M, Y', strtotime($rev['created_at'])) ?></small>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
    <?php endif; ?>

</div>

<!-- JavaScript for Live Filter & Reviews Auto-Slide -->
<script>
function filterProductsLive() {
    const query = document.getElementById('storeSearchInput').value.toLowerCase().trim();
    const cols = document.querySelectorAll('.product-item-col');
    cols.forEach(col => {
        const title = col.getAttribute('data-title') || '';
        if (title.includes(query)) {
            col.style.display = '';
        } else {
            col.style.display = 'none';
        }
    });
}

function showAllCategories(btn, e) {
    e.preventDefault();
    document.querySelectorAll('.category-block').forEach(b => b.style.display = '');
    document.querySelectorAll('.category-pill-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    document.getElementById('products').scrollIntoView({ behavior: 'smooth' });
}

function filterByCategory(targetId, btn, e) {
    e.preventDefault();
    document.querySelectorAll('.category-pill-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    const target = document.getElementById(targetId);
    if (target) {
        target.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
}

// ====== REVIEWS AUTO SLIDER LOGIC ======
let reviewSlideInterval = null;

function autoAdvanceReviews() {
    const vp = document.getElementById('reviewsSliderViewport');
    if (!vp) return;
    const item = vp.querySelector('.review-slide-card');
    const scrollAmount = item ? item.offsetWidth + 16 : 320;
    const maxScroll = vp.scrollWidth - vp.clientWidth;
    
    if (vp.scrollLeft >= maxScroll - 15) {
        vp.scrollTo({ left: 0, behavior: 'smooth' });
    } else {
        vp.scrollBy({ left: scrollAmount, behavior: 'smooth' });
    }
}

function slideReviewsNext() {
    const vp = document.getElementById('reviewsSliderViewport');
    if (!vp) return;
    const item = vp.querySelector('.review-slide-card');
    const scrollAmount = item ? item.offsetWidth + 16 : 320;
    const maxScroll = vp.scrollWidth - vp.clientWidth;
    if (vp.scrollLeft >= maxScroll - 15) {
        vp.scrollTo({ left: 0, behavior: 'smooth' });
    } else {
        vp.scrollBy({ left: scrollAmount, behavior: 'smooth' });
    }
}

function slideReviewsPrev() {
    const vp = document.getElementById('reviewsSliderViewport');
    if (!vp) return;
    const item = vp.querySelector('.review-slide-card');
    const scrollAmount = item ? item.offsetWidth + 16 : 320;
    if (vp.scrollLeft <= 15) {
        vp.scrollTo({ left: vp.scrollWidth, behavior: 'smooth' });
    } else {
        vp.scrollBy({ left: -scrollAmount, behavior: 'smooth' });
    }
}

function startReviewAutoSlide() {
    if (reviewSlideInterval) clearInterval(reviewSlideInterval);
    reviewSlideInterval = setInterval(autoAdvanceReviews, 3200);
}

function pauseReviewAutoSlide() {
    if (reviewSlideInterval) {
        clearInterval(reviewSlideInterval);
        reviewSlideInterval = null;
    }
}

document.addEventListener('DOMContentLoaded', () => {
    startReviewAutoSlide();
});
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<?php include 'footer.php'; ?>