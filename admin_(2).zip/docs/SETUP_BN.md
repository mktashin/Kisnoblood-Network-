# JHX Digital Shop — cPanel Setup Guide (বাংলা)

এই package-টি PHP + MySQL ভিত্তিক digital-subscription ও downloadable-file store-এর জন্য তৈরি। এতে automatic payment gateway নেই; payment method হিসেবে শুধু **Manual Payment** রাখা হয়েছে। Subscription product এবং local ZIP/PDF/software file—দুটো ধরনের product বিক্রি করা যাবে।

## ১. যা লাগবে

| বিষয় | প্রয়োজন |
|---|---|
| Hosting | cPanel hosting এবং একটি domain/subdomain |
| PHP | PHP 8.1 বা তার পরের version |
| Database | MySQL বা MariaDB |
| PHP extensions | PDO MySQL, file uploads, sessions |
| SSL | HTTPS ব্যবহার করা strongly recommended |

## ২. cPanel-এ ZIP upload

১. cPanel-এ login করে **File Manager** খুলুন।

২. আপনার domain-এর `public_html` directory খুলুন। যদি addon domain বা subdomain হয়, সেই domain-এর document root ব্যবহার করুন।

৩. এই ZIP file upload করুন এবং **Extract** করুন। ZIP-এর ভেতরের files যেন সরাসরি document root-এ থাকে। সঠিক structure হবে:

```text
public_html/
├── admin/
├── assets/
├── database/
├── downloads/
├── payment/
├── uploads/
├── config.php
├── download.php
├── index.php
└── install.php
```

যদি extract করার পর `public_html/JHX-Digital-Shop-Portable/install.php` হয়, তাহলে ভেতরের সব file এক ধাপ উপরে document root-এ move করুন।

## ৩. MySQL database ও user তৈরি

cPanel-এর **MySQL Databases** section-এ যান।

১. একটি নতুন database তৈরি করুন।

২. একটি নতুন database user তৈরি করুন।

৩. user-কে database-এর সঙ্গে **All Privileges** দিয়ে যুক্ত করুন।

৪. cPanel সাধারণত database name ও username-এর আগে cPanel username prefix যোগ করে। Installer-এ cPanel যে full name দেখায়, সেটিই লিখবেন।

উদাহরণ:

```text
Database name: my_digital_shop
Database user: my_shopuser
Database host: localhost
```

## ৪. ডাটাবেজ সংযোগ ও ইন্সটলেশন (২টি সহজ উপায়)

### উপায় ক: আগের ডাটাবেজ থাকলে সরাসরি চালানো (সবচেয়ে সহজ)
আপনার যদি আগে থেকেই তৈরি করা ডাটাবেজ থাকে (অথবা cPanel/phpMyAdmin-এ SQL ইমপোর্ট করে থাকেন):
১. রুট ডিরেক্টরিতে থাকা **`db_config.php`** ফাইলটি এডিট করুন।
২. আপনার Database `host`, `name`, `user`, এবং `pass` লিখে Save করুন।
৩. ব্যস! আর কিছুই করতে হবে না, সাইট সাথে সাথে আপনার আগের ডাটাবেজ দিয়ে লাইভ চলবে।

### উপায় খ: নতুনভাবে Installer দিয়ে ইন্সটল করা
Browser-এ যান:

```text
https://your-domain.com/install.php
```

তারপর নিচের তথ্য দিন:

| Field | কী লিখবেন |
|---|---|
| Database Host | সাধারণত `localhost` |
| Database Name | cPanel-এ তৈরি করা full database name |
| Database Username | cPanel-এ তৈরি করা full database username |
| Database Password | database user-এর password |
| Admin Name | আপনার admin নাম |
| Admin Email | admin login email |
| Admin Password | কমপক্ষে ১০ অক্ষরের শক্তিশালী password |
| Site Name | দোকানের নাম |

**Demo catalog load** option checked রাখলে JHX branding, একটি slider এবং পাঁচটি sample subscription product তৈরি হবে। Blank store চাইলে checkbox খুলে install করুন।

Installer নিজে:

- সব database table তৈরি করবে;
- manual-payment-only schema তৈরি করবে;
- admin account তৈরি করবে;
- settings row তৈরি করবে;
- sample catalog চাইলে sample data দেবে;
- public_html-এর বাইরে `jhx_private_downloads` directory তৈরি করবে;
- private file download-এর জন্য required storage প্রস্তুত করবে।

## ৫. Installation-এর পর অবশ্যই করুন

Installation সফল হলে cPanel File Manager থেকে **`install.php` delete করুন**। এটি delete না করলে ভবিষ্যতে কেউ installer page দেখতে পারে।

এরপর Admin Panel-এ login করুন:

```text
https://your-domain.com/admin/
```

Admin Panel থেকে প্রথমে Site Settings-এ গিয়ে নিজের:

- bKash number;
- Nagad number;
- Rocket number;
- payment note;
- Telegram support link;
- logo বা site metadata

সেট করুন।

## ৬. Subscription product যোগ করার নিয়ম

Admin Panel → **Products** → **Add New Product** থেকে:

১. Product Type হিসেবে `Subscription / Topup` নির্বাচন করুন।

২. title, description, regular price, offer price ও stock দিন।

৩. thumbnail upload করুন।

৪. Gmail প্রয়োজন হলে product description-এ বিষয়টি পরিষ্কারভাবে লিখুন।

User payment submit করার পর order `Pending` থাকবে। Admin payment যাচাই করে `Completed` করলে user My Orders page-এ activation information দেখতে পারবে।

## ৭. Local file বিক্রির নিয়ম

Local ZIP/PDF/software file বিক্রি করতে:

১. Product Type হিসেবে `Downloadable / Digital` নির্বাচন করুন।

২. title, description, price ও stock দিন।

৩. thumbnail upload করুন।

৪. **Digital File** field-এ ZIP, PDF বা প্রয়োজনীয় file upload করুন।

৫. চাইলে Cloud Drive Link-ও দিতে পারেন। Local file থাকলে সেটি private storage-এ থাকবে।

Local upload-এর database value সাধারণত এই ধরনের হবে:

```text
private_downloads/1780000000_file_example.zip
```

কিন্তু actual file public_html-এর বাইরে থাকবে। User সরাসরি guessed URL দিয়ে file নিতে পারবে না।

### Delivery flow

```text
User checkout করে
        ↓
Transaction ID ও sender number submit করে
        ↓
Order Pending থাকে
        ↓
Admin payment verify করে Completed করে
        ↓
User My Orders-এ Download File button পায়
        ↓
download.php owner + order + status যাচাই করে file দেয়
```

Protected route ছাড়া local file serve করা হয় না। Download route যাচাই করে:

- user login করেছে কি না;
- orderটি ওই user-এর কি না;
- order status `Completed` কি না;
- product type `downloadable` কি না;
- file private directory-এর ভিতরে আছে কি না;
- path traversal চেষ্টা হয়েছে কি না।

Cloud Drive link থাকলে একই authorization check-এর পরে link redirect করা হয়।

## ৮. Database table সংক্ষেপ

| Table | কাজ |
|---|---|
| `users` | customer ও admin account |
| `categories` | product category |
| `products` | subscription ও downloadable product |
| `orders` | manual payment order ও delivery status |
| `settings` | site, Telegram ও manual payment settings |
| `sliders` | homepage banner/slider |

`orders.payment_method` শুধু `Manual` value গ্রহণ করে। Automatic gateway, callback বা API credential package-এ নেই।

## ৯. Security checklist

Installation শেষে নিচের কাজগুলো করুন:

- `install.php` delete করুন।
- Admin password অন্য কোথাও publicভাবে রাখবেন না।
- cPanel password ও admin password আলাদা রাখুন।
- HTTPS/SSL চালু রাখুন।
- `storage/`, `database/` ও public `downloads/` directory-এর `.htaccess` file delete করবেন না।
- Local digital files public_html-এর বাইরে রাখুন; installer এই কাজটি automatic করে।
- Admin Panel থেকে অচেনা user, order ও product নিয়মিত যাচাই করুন।
- Hosting backup policy অনুযায়ী database ও private download files backup রাখুন।

## ১০. Common সমস্যা ও সমাধান

### Database connection failed

Database name/user-এর cPanel prefix ঠিক আছে কি না দেখুন। User-কে database-এ **All Privileges** দেওয়া হয়েছে কি না যাচাই করুন। সাধারণত database host `localhost` হয়।

### Installer page খুলছে না

`install.php` document root-এ আছে কি না দেখুন। PHP version 8.1+ নির্বাচন করুন এবং PHP extension-এ PDO MySQL চালু আছে কি না দেখুন।

### Local file upload হচ্ছে না

cPanel PHP Settings-এ `file_uploads` on আছে কি না এবং `upload_max_filesize` ও `post_max_size` file size-এর চেয়ে বড় কি না দেখুন। Private directory permission সাধারণত `0700` রাখুন।

### Download button দেখা যাচ্ছে না

Admin Orders page থেকে order status `Completed` করুন এবং product type `Downloadable / Digital` আছে কি না দেখুন। Product-এ local file বা valid HTTPS Drive link থাকা প্রয়োজন।

### Logo বা slider দেখা যাচ্ছে না

`uploads/` directory এবং তার subdirectory-গুলোর permission `0755` আছে কি না দেখুন। Demo catalog option ব্যবহার করলে sample assets installer নিজে সেট করে।

## ১১. Upgrade বা migration

নতুন version install করার আগে database backup নিন। Existing `config.php`, `storage/db.php`, `uploads/`, `jhx_private_downloads/` এবং database backup না রেখে পুরো site overwrite করবেন না।

এই package-এর উদ্দেশ্য হলো নতুন cPanel-এ কম ধাপে clean installation দেওয়া; production store-এ update করার আগে backup নেওয়া বাধ্যতামূলক।
