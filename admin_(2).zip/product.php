<?php 
include 'config.php'; 
include 'header.php';

$id = $_GET['id'] ?? null;

if (!$id) {
    die("<div class='container mt-5 alert alert-danger'>Invalid Product ID.</div>");
}

$stmt = $pdo->prepare("SELECT products.*, categories.name AS category_name FROM products LEFT JOIN categories ON products.category_id = categories.id WHERE products.id = ?");
$stmt->execute([$id]);
$p = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$p) die("<div class='container mt-5 alert alert-danger'>Product not found.</div>");

// Fetch multiple gallery photos
$gallery_stmt = $pdo->prepare("SELECT * FROM product_images WHERE product_id = ? ORDER BY sort_order ASC, id ASC");
$gallery_stmt->execute([$id]);
$product_gallery = $gallery_stmt->fetchAll(PDO::FETCH_ASSOC);

// Combine main product image with additional gallery photos
$all_images = [];
if (!empty($p['image'])) {
    $all_images[] = $p['image'];
}
foreach ($product_gallery as $g) {
    if (!empty($g['image']) && !in_array($g['image'], $all_images)) {
        $all_images[] = $g['image'];
    }
}
if (empty($all_images)) {
    $all_images[] = 'assets/images/placeholder.png';
}

// Fetch active customer reviews for testimonial section
$reviews_stmt = $pdo->query("SELECT * FROM reviews WHERE status = 1 ORDER BY sort_order ASC, id DESC LIMIT 4");
$product_reviews = $reviews_stmt ? $reviews_stmt->fetchAll(PDO::FETCH_ASSOC) : [];
$discount = $p['regular_price'] - $p['offer_price'];
?>

<style>
    /* =========================================
       ✨ ULTRA-MODERN PRODUCT DETAILS STYLING
    ========================================= */
    .product-details-container {
        width: min(100%, 1220px);
        padding: clamp(10px, 2.5vw, 24px) clamp(12px, 2.5vw, 24px);
        margin: 0 auto;
    }

    .product-main-card {
        background: var(--bg-card);
        border-radius: clamp(16px, 3vw, 24px);
        border: 1px solid var(--border-color);
        box-shadow: var(--shadow-sm);
        padding: clamp(16px, 3vw, 36px);
        margin-bottom: clamp(24px, 4vw, 40px);
    }

    /* ====== GALLERY STYLING ====== */
    .product-gallery-box {
        position: sticky;
        top: 80px;
    }

    .main-image-display {
        position: relative;
        width: 100%;
        aspect-ratio: 1 / 1;
        border-radius: clamp(14px, 2vw, 20px);
        overflow: hidden;
        background: #0f172a;
        border: 1px solid var(--border-color);
        box-shadow: var(--shadow-sm);
        cursor: zoom-in;
    }

    .main-image-display img {
        width: 100%;
        height: 100%;
        object-fit: cover;
        transition: transform 0.4s ease, opacity 0.2s ease;
        display: block;
    }

    .main-image-display:hover img {
        transform: scale(1.03);
    }

    .zoom-indicator-pill {
        position: absolute;
        bottom: 14px;
        right: 14px;
        background: rgba(15, 23, 42, 0.85);
        backdrop-filter: blur(8px);
        -webkit-backdrop-filter: blur(8px);
        color: #ffffff;
        font-size: 0.75rem;
        font-weight: 700;
        padding: 6px 14px;
        border-radius: 30px;
        letter-spacing: 0.3px;
        box-shadow: 0 4px 15px rgba(0,0,0,0.3);
        pointer-events: none;
        display: flex;
        align-items: center;
        gap: 6px;
        border: 1px solid rgba(255,255,255,0.18);
        z-index: 5;
    }

    .thumbnails-strip {
        display: flex;
        gap: 10px;
        margin-top: 14px;
        overflow-x: auto;
        padding-bottom: 4px;
        scrollbar-width: thin;
    }

    .thumb-btn {
        width: 76px;
        height: 76px;
        border-radius: 14px;
        overflow: hidden;
        border: 2px solid var(--border-color);
        background: #0f172a;
        cursor: pointer;
        flex-shrink: 0;
        transition: var(--transition);
        opacity: 0.65;
        padding: 0;
    }

    .thumb-btn:hover {
        opacity: 1;
        transform: translateY(-2px);
        border-color: var(--primary-light);
    }

    .thumb-btn.active {
        opacity: 1;
        border-color: var(--primary-blue);
        box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.35);
        transform: scale(1.04);
    }

    .thumb-btn img {
        width: 100%;
        height: 100%;
        object-fit: cover;
    }

    /* ====== DETAILS STYLING ====== */
    .breadcrumb-custom {
        display: flex;
        align-items: center;
        gap: 6px;
        font-size: 0.8rem;
        font-weight: 700;
        color: var(--text-muted);
        text-transform: uppercase;
        letter-spacing: 0.4px;
        margin-bottom: 12px;
        flex-wrap: wrap;
    }

    .breadcrumb-custom a {
        color: var(--primary-blue);
        text-decoration: none;
    }

    .prod-details-title {
        font-size: clamp(1.4rem, 2.5vw, 2.1rem);
        font-weight: 900;
        color: var(--text-dark);
        line-height: 1.25;
        letter-spacing: -0.4px;
        margin-bottom: 14px;
    }

    .status-badges-row {
        display: flex;
        align-items: center;
        gap: 8px;
        flex-wrap: wrap;
        margin-bottom: 20px;
    }

    .stock-badge-pill {
        padding: 6px 14px;
        border-radius: 30px;
        font-weight: 800;
        font-size: 0.74rem;
        display: inline-flex;
        align-items: center;
        gap: 6px;
    }

    .stock-badge-pill.in {
        background: #ecfdf5;
        color: #059669;
        border: 1px solid #a7f3d0;
    }

    .stock-badge-pill.out {
        background: #fef2f2;
        color: #dc2626;
        border: 1px solid #fecaca;
    }

    .verified-pill {
        background: #eff6ff;
        color: #1d4ed8;
        border: 1px solid #bfdbfe;
        padding: 6px 14px;
        border-radius: 30px;
        font-weight: 800;
        font-size: 0.74rem;
        display: inline-flex;
        align-items: center;
        gap: 6px;
    }

    /* Price Card */
    .price-display-card {
        background: linear-gradient(135deg, rgba(37, 99, 235, 0.08) 0%, rgba(59, 130, 246, 0.03) 100%);
        border: 1.5px solid rgba(37, 99, 235, 0.2);
        padding: 16px 22px;
        border-radius: var(--radius);
        display: flex;
        align-items: baseline;
        gap: 12px;
        margin-bottom: 22px;
        flex-wrap: wrap;
    }

    .price-display-card .main-offer {
        font-size: clamp(1.8rem, 3vw, 2.4rem);
        font-weight: 900;
        color: var(--primary-blue);
        letter-spacing: -0.5px;
    }

    .price-display-card .main-regular {
        font-size: 1.1rem;
        font-weight: 700;
        color: var(--text-muted);
        text-decoration: line-through;
    }

    .save-pill {
        background: #ef4444;
        color: #fff;
        font-size: 0.72rem;
        font-weight: 800;
        padding: 4px 10px;
        border-radius: 20px;
        margin-left: auto;
    }

    /* Variation selector */
    .variation-select-box {
        background: var(--bg-card-subtle);
        border: 1px solid var(--border-color);
        padding: 16px;
        border-radius: 14px;
        margin-bottom: 20px;
    }

    .variation-select-box label {
        font-size: 0.8rem;
        font-weight: 800;
        color: var(--text-dark);
        margin-bottom: 8px;
        display: block;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }

    .form-select-lg {
        border-radius: 12px;
        font-size: 0.95rem;
        font-weight: 700;
        border: 1.5px solid var(--border-color);
        padding: 12px 16px;
    }

    /* Description Box */
    .desc-wrapper {
        margin-bottom: 24px;
    }

    .desc-wrapper h6 {
        font-size: 0.85rem;
        font-weight: 800;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        color: var(--text-dark);
        margin-bottom: 10px;
    }

    .desc-content {
        font-size: 0.92rem;
        line-height: 1.7;
        color: var(--text-muted);
        background: var(--bg-card-subtle);
        border-radius: 14px;
        padding: 16px;
        border: 1px solid var(--border-color);
    }

    /* Activation Gmail Box */
    .activation-email-card {
        background: #fffbeb;
        border: 1px solid #fde68a;
        border-radius: 14px;
        padding: 16px;
        margin-bottom: 22px;
    }

    .activation-email-card label {
        font-size: 0.82rem;
        font-weight: 800;
        color: #92400e;
        display: block;
        margin-bottom: 6px;
    }

    /* Pay Buttons */
    .btn-auto-pay-btn {
        width: 100%;
        background: var(--primary-gradient);
        color: #fff !important;
        border: none;
        border-radius: 14px;
        padding: 14px 20px;
        font-size: 0.92rem;
        font-weight: 800;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        box-shadow: 0 4px 16px rgba(37, 99, 235, 0.3);
        transition: var(--transition);
        margin-bottom: 10px;
    }

    .btn-auto-pay-btn:hover {
        background: var(--primary-gradient-hover);
        transform: translateY(-2px);
        box-shadow: 0 8px 24px rgba(37, 99, 235, 0.4);
    }

    .btn-manual-pay-btn {
        width: 100%;
        background: var(--bg-card);
        color: var(--text-dark) !important;
        border: 2px solid var(--border-color);
        border-radius: 14px;
        padding: 13px 20px;
        font-size: 0.88rem;
        font-weight: 800;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        transition: var(--transition);
    }

    .btn-manual-pay-btn:hover {
        border-color: var(--primary-blue);
        color: var(--primary-blue) !important;
        background: rgba(37, 99, 235, 0.05);
        transform: translateY(-2px);
    }

    .pay-or-divider {
        display: flex;
        align-items: center;
        text-align: center;
        margin: 12px 0;
        color: var(--text-muted);
        font-size: 0.72rem;
        font-weight: 800;
        text-transform: uppercase;
        letter-spacing: 1px;
    }

    .pay-or-divider::before, .pay-or-divider::after {
        content: '';
        flex: 1;
        border-bottom: 1px dashed var(--border-color);
    }

    .pay-or-divider span {
        padding: 0 10px;
    }

    /* ====== REVIEWS SECTION ON PRODUCT PAGE ====== */
    .product-reviews-box {
        background: var(--bg-card);
        border: 1px solid var(--border-color);
        border-radius: var(--radius);
        padding: clamp(20px, 3.5vw, 32px);
        box-shadow: var(--shadow-sm);
    }

    .review-user-badge {
        width: 38px;
        height: 38px;
        border-radius: 50%;
        background: var(--primary-gradient);
        color: #fff;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: 900;
        font-size: 0.9rem;
    }
</style>

<div class="product-details-container">

    <!-- ====== 1. MAIN PRODUCT DETAILS CARD ====== -->
    <div class="product-main-card">
        <div class="row g-4 g-lg-5">
            
            <!-- LEFT: GALLERY & ZOOM -->
            <div class="col-12 col-lg-6">
                <div class="product-gallery-box">
                    <div class="main-image-display" onclick="openZoomModal()" title="Click to zoom">
                        <img id="mainProductImage" src="<?= htmlspecialchars($all_images[0]) ?>" alt="<?= htmlspecialchars($p['title']) ?>">
                        <div class="zoom-indicator-pill">
                            <i class="fas fa-search-plus"></i> Click to zoom
                        </div>
                    </div>

                    <?php if(count($all_images) > 1): ?>
                    <!-- Multiple Thumbnails Strip -->
                    <div class="thumbnails-strip">
                        <?php foreach($all_images as $idx => $img_url): ?>
                            <button type="button" class="thumb-btn <?= $idx === 0 ? 'active' : '' ?>" onclick="switchProductImage('<?= htmlspecialchars($img_url) ?>', this)" aria-label="Photo <?= $idx + 1 ?>">
                                <img src="<?= htmlspecialchars($img_url) ?>" alt="Thumb <?= $idx + 1 ?>">
                            </button>
                        <?php endforeach; ?>
                    </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- RIGHT: PRODUCT INFO & PURCHASE -->
            <div class="col-12 col-lg-6">
                <!-- Breadcrumb -->
                <div class="breadcrumb-custom">
                    <a href="index.php"><i class="fas fa-home me-1"></i> Home</a>
                    <span>/</span>
                    <a href="index.php#products">Products</a>
                    <span>/</span>
                    <span><?= htmlspecialchars($p['category_name'] ?? 'General') ?></span>
                </div>

                <h1 class="prod-details-title font-heading"><?= htmlspecialchars($p['title']) ?></h1>

                <!-- Status Badges -->
                <div class="status-badges-row">
                    <?php if(($p['stock'] ?? 0) > 0): ?>
                        <span class="stock-badge-pill in"><i class="fas fa-check-circle"></i> In Stock (<?= $p['stock'] ?>)</span>
                    <?php else: ?>
                        <span class="stock-badge-pill out"><i class="fas fa-times-circle"></i> Out of Stock</span>
                    <?php endif; ?>
                    <span class="verified-pill"><i class="fas fa-shield-alt text-success"></i> 100% Genuine & Instant Delivery</span>
                </div>

                <!-- Price Card -->
                <div class="price-display-card">
                    <span class="main-offer" id="display_offer_price">৳<?= number_format($p['offer_price'], 0) ?></span>
                    <?php if($discount > 0): ?>
                        <span class="main-regular">৳<?= number_format($p['regular_price'], 0) ?></span>
                        <span class="save-pill"><i class="fas fa-tags me-1"></i> Save ৳<?= number_format($discount, 0) ?></span>
                    <?php endif; ?>
                </div>

                <!-- Purchase Form -->
                <form action="payment/manual.php" method="GET" id="purchaseForm">
                    <input type="hidden" name="product_id" value="<?= $p['id'] ?>">
                    <input type="hidden" name="final_amount" id="final_amount_input" value="<?= htmlspecialchars($p['offer_price']) ?>">

                    <!-- Variations Selector -->
                    <?php if(!empty($p['variations'])): ?>
                    <div class="variation-select-box">
                        <label><i class="fas fa-layer-group me-1 text-primary"></i> Select Plan / Variation:</label>
                        <select name="selected_variation" class="form-select form-select-lg" id="variation_selector" onchange="updateDynamicPrice()">
                            <?php 
                            $vars = explode("\n", str_replace("\r", "", $p['variations']));
                            foreach($vars as $v): 
                                if(strpos($v, ':') !== false):
                                    list($v_name, $v_price) = explode(':', $v);
                            ?>
                                <option value="<?= trim($v_name) ?>" data-price="<?= trim($v_price) ?>"><?= trim($v_name) ?> - ৳<?= trim($v_price) ?></option>
                            <?php 
                                endif;
                            endforeach; 
                            ?>
                        </select>
                    </div>
                    <?php endif; ?>

                    <!-- Description -->
                    <div class="desc-wrapper">
                        <h6><i class="fas fa-align-left me-1 text-primary"></i> Product Overview & Features:</h6>
                        <div class="desc-content">
                            <?= nl2br(htmlspecialchars($p['description'] ?? 'Premium verified digital subscription with fast delivery.')) ?>
                        </div>
                    </div>

                    <!-- Email for Subscription Delivery -->
                    <?php if($p['product_type'] === 'subscription'): ?>
                        <div class="activation-email-card">
                            <label><i class="fas fa-envelope me-1"></i> Enter Gmail for Instant Account Activation:</label>
                            <input type="email" name="sub_email" class="form-control" required placeholder="e.g. yourname@gmail.com" style="border-radius:10px; font-weight:600;">
                            <small class="text-muted mt-1 d-block" style="font-size:0.75rem;"><i class="fas fa-info-circle me-1"></i> Required for digital delivery & login activation.</small>
                        </div>
                    <?php endif; ?>

                    <!-- Purchase Actions -->
                    <div>
                        <?php if(isset($_SESSION['user_id'])): ?>
                            <?php if(($p['stock'] ?? 0) > 0): ?>
                                <?php 
                                $has_manual = !empty($set['enable_manual_payment']);
                                $has_auto   = !empty($set['enable_auto_payment']) && !empty($set['hostneko_api_key']);
                                ?>

                                <?php if($has_auto && $has_manual): ?>
                                    <button type="submit" formaction="payment/hostneko.php" class="btn-auto-pay-btn">
                                        <i class="fas fa-bolt text-warning"></i> Instant Auto Pay (bKash / Nagad / Cards)
                                    </button>
                                    <div class="pay-or-divider"><span>OR</span></div>
                                    <button type="submit" formaction="payment/manual.php" class="btn-manual-pay-btn">
                                        <i class="fas fa-mobile-screen-button text-primary"></i> Pay Manually (Send Money & TrxID)
                                    </button>
                                <?php elseif($has_auto): ?>
                                    <button type="submit" formaction="payment/hostneko.php" class="btn-auto-pay-btn">
                                        <i class="fas fa-bolt text-warning"></i> Instant Auto Pay (bKash / Nagad / Cards)
                                    </button>
                                <?php elseif($has_manual): ?>
                                    <button type="submit" formaction="payment/manual.php" class="btn-auto-pay-btn">
                                        <i class="fas fa-mobile-screen-button text-warning"></i> Proceed to Manual Payment
                                    </button>
                                <?php else: ?>
                                    <div class="alert alert-warning text-center rounded-3 fw-bold">
                                        <i class="fas fa-info-circle me-1"></i> Checkout is currently paused. Please contact support.
                                    </div>
                                <?php endif; ?>

                            <?php else: ?>
                                <button type="button" class="btn btn-secondary w-100 py-3 rounded-3 fw-bold" disabled>
                                    <i class="fas fa-ban me-2"></i> Currently Sold Out
                                </button>
                            <?php endif; ?>
                        <?php else: ?>
                            <a href="login.php" class="btn-auto-pay-btn text-decoration-none">
                               <i class="fas fa-lock me-2"></i> Login to Purchase
                            </a>
                        <?php endif; ?>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- ====== 2. CUSTOMER REVIEWS SECTION ====== -->
    <?php if(!empty($product_reviews)): ?>
    <div class="product-reviews-box">
        <div class="d-flex align-items-center justify-content-between mb-4 flex-wrap gap-2">
            <div>
                <h3 class="fw-bold mb-1 font-heading" style="color:var(--text-dark); font-size:1.3rem;">
                    <i class="fas fa-star text-warning me-2"></i> Customer Feedback & Reviews
                </h3>
                <p class="text-muted small mb-0 fw-bold">Verified buyer experiences with our digital shop</p>
            </div>
            <div class="d-flex align-items-center gap-1 text-warning fs-5">
                <i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i>
                <span class="ms-1 fw-bold fs-6 text-dark">4.9 / 5.0</span>
            </div>
        </div>

        <div class="row g-3">
            <?php foreach($product_reviews as $rev): ?>
            <div class="col-12 col-md-6">
                <div class="p-3 rounded-4 h-100" style="background:var(--bg-card-subtle); border:1px solid var(--border-color);">
                    <div class="d-flex align-items-center justify-content-between mb-2">
                        <div class="d-flex align-items-center gap-2">
                            <?php if(!empty($rev['avatar'])): ?>
                                <img src="<?= htmlspecialchars($rev['avatar']) ?>" class="rounded-circle" style="width:38px; height:38px; object-fit:cover;">
                            <?php else: ?>
                                <div class="review-user-badge">
                                    <?= strtoupper(substr($rev['name'] ?? 'U', 0, 1)) ?>
                                </div>
                            <?php endif; ?>
                            <div>
                                <div class="fw-bold text-dark" style="font-size:0.88rem;"><?= htmlspecialchars($rev['name']) ?></div>
                                <small class="text-success fw-bold" style="font-size:0.7rem;"><i class="fas fa-check-circle me-1"></i> Verified Buyer</small>
                            </div>
                        </div>
                        <div class="text-warning small">
                            <?php for($s=1; $s<=5; $s++): ?>
                                <i class="fas fa-star <?= $s <= round($rev['rating'] ?? 5) ? '' : 'text-muted' ?>"></i>
                            <?php endfor; ?>
                        </div>
                    </div>
                    <p class="mb-0 text-muted small" style="line-height:1.6; font-size:0.85rem;">
                        "<?= htmlspecialchars($rev['comment']) ?>"
                    </p>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
    <?php endif; ?>

</div>

<!-- Fullscreen Zoom Lightbox Modal -->
<div class="modal fade" id="zoomModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-xl">
        <div class="modal-content bg-transparent border-0">
            <div class="modal-header border-0 pb-0 justify-content-end">
                <button type="button" class="btn-close btn-close-white fs-4" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body text-center p-2">
                <img id="zoomModalImage" src="<?= htmlspecialchars($all_images[0]) ?>" class="img-fluid rounded-4 shadow-lg" style="max-height: 85vh; object-fit: contain; background: rgba(0,0,0,0.85); border: 1px solid rgba(255,255,255,0.2);">
            </div>
        </div>
    </div>
</div>

<script>
function switchProductImage(src, element) {
    const mainImg = document.getElementById('mainProductImage');
    if (!mainImg) return;
    mainImg.style.opacity = '0.3';
    setTimeout(() => {
        mainImg.src = src;
        mainImg.style.opacity = '1';
    }, 150);
    document.querySelectorAll('.thumb-btn').forEach(el => el.classList.remove('active'));
    if (element) element.classList.add('active');
}

function openZoomModal() {
    const currentSrc = document.getElementById('mainProductImage').src;
    document.getElementById('zoomModalImage').src = currentSrc;
    const modal = new bootstrap.Modal(document.getElementById('zoomModal'));
    modal.show();
}

function updateDynamicPrice() {
    const selector = document.getElementById('variation_selector');
    const priceText = document.getElementById('display_offer_price');
    const finalAmountInput = document.getElementById('final_amount_input');
    
    if (selector && priceText) {
        const selectedOption = selector.options[selector.selectedIndex];
        const newPrice = selectedOption.getAttribute('data-price');
        if (newPrice) {
            priceText.innerText = '৳' + Number(newPrice).toLocaleString();
            if (finalAmountInput) finalAmountInput.value = newPrice;
        }
    }
}

document.addEventListener('DOMContentLoaded', function() {
    if(document.getElementById('variation_selector')) {
        updateDynamicPrice();
    }
});
</script>

<?php include 'footer.php'; ?>