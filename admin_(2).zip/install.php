<?php
// Digital Shop - Professional SQL & System Installer
// Supports MySQL / MariaDB and SQLite with Automatic Schema Import

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$storageDir     = __DIR__ . '/storage';
$rootConfigFile = __DIR__ . '/db_config.php';
$dbConfigFile   = $storageDir . '/db_config.php';
$installedFile  = $storageDir . '/.installed';

$existingConfig = [];
if (is_file($rootConfigFile)) {
    $existingConfig = (array)(require $rootConfigFile);
} elseif (is_file($dbConfigFile)) {
    $existingConfig = (array)(require $dbConfigFile);
}

$isInstalled    = is_file($installedFile) && (is_file($dbConfigFile) || is_file($rootConfigFile)) && !isset($_GET['force']);

if (!is_dir($storageDir)) {
    @mkdir($storageDir, 0755, true);
}

// Defensive schema migration helper for legacy or upgrading databases
function ensureLatestSchema(PDO $pdo, string $driver): void {
    if ($driver === 'mysql') {
        $migrations = [
            // Settings columns
            "ALTER TABLE `settings` ADD COLUMN `site_tagline` VARCHAR(255) DEFAULT 'Premium Digital Subscriptions & Downloads'",
            "ALTER TABLE `settings` ADD COLUMN `logo` VARCHAR(255) DEFAULT 'uploads/jhx_digital_shop_logo_v2.svg'",
            "ALTER TABLE `settings` ADD COLUMN `favicon` VARCHAR(255) DEFAULT ''",
            "ALTER TABLE `settings` ADD COLUMN `yt_link` VARCHAR(255) DEFAULT '#'",
            "ALTER TABLE `settings` ADD COLUMN `fb_link` VARCHAR(255) DEFAULT '#'",
            "ALTER TABLE `settings` ADD COLUMN `tg_link` VARCHAR(255) DEFAULT ''",
            "ALTER TABLE `settings` ADD COLUMN `tg_user` VARCHAR(100) DEFAULT ''",
            "ALTER TABLE `settings` ADD COLUMN `whatsapp_number` VARCHAR(30) DEFAULT NULL",
            "ALTER TABLE `settings` ADD COLUMN `site_status` TINYINT(1) NOT NULL DEFAULT 1",
            "ALTER TABLE `settings` ADD COLUMN `auto_approve_orders` TINYINT(1) NOT NULL DEFAULT 0",
            "ALTER TABLE `settings` ADD COLUMN `enable_manual_payment` TINYINT(1) NOT NULL DEFAULT 1",
            "ALTER TABLE `settings` ADD COLUMN `enable_auto_payment` TINYINT(1) NOT NULL DEFAULT 0",
            "ALTER TABLE `settings` ADD COLUMN `hostneko_api_key` VARCHAR(255) DEFAULT ''",
            "ALTER TABLE `settings` ADD COLUMN `hostneko_currency_rate` VARCHAR(20) DEFAULT '1'",
            "ALTER TABLE `settings` ADD COLUMN `currency_symbol` VARCHAR(10) NOT NULL DEFAULT '৳'",
            "ALTER TABLE `settings` ADD COLUMN `meta_title` TEXT DEFAULT NULL",
            "ALTER TABLE `settings` ADD COLUMN `meta_desc` TEXT DEFAULT NULL",
            "ALTER TABLE `settings` ADD COLUMN `meta_keys` TEXT DEFAULT NULL",
            "ALTER TABLE `settings` ADD COLUMN `bkash_number` VARCHAR(30) DEFAULT NULL",
            "ALTER TABLE `settings` ADD COLUMN `nagad_number` VARCHAR(30) DEFAULT NULL",
            "ALTER TABLE `settings` ADD COLUMN `rocket_number` VARCHAR(30) DEFAULT NULL",
            "ALTER TABLE `settings` ADD COLUMN `upay_number` VARCHAR(30) DEFAULT NULL",
            "ALTER TABLE `settings` ADD COLUMN `manual_payment_type` VARCHAR(20) DEFAULT 'Personal'",
            "ALTER TABLE `settings` ADD COLUMN `manual_payment_note` TEXT DEFAULT NULL",

            // Products columns
            "ALTER TABLE `products` ADD COLUMN `file_path` VARCHAR(255) DEFAULT NULL",
            "ALTER TABLE `products` ADD COLUMN `drive_link` TEXT DEFAULT NULL",
            "ALTER TABLE `products` ADD COLUMN `image` VARCHAR(255) DEFAULT NULL",
            "ALTER TABLE `products` ADD COLUMN `variations` TEXT DEFAULT NULL",

            // Orders columns
            "ALTER TABLE `orders` MODIFY COLUMN `payment_method` VARCHAR(50) NOT NULL DEFAULT 'Manual'",
            "ALTER TABLE `orders` ADD COLUMN `payment_data` TEXT DEFAULT NULL",
            "ALTER TABLE `orders` ADD COLUMN `sub_email` VARCHAR(190) DEFAULT NULL",
            "ALTER TABLE `orders` ADD COLUMN `sender_number` VARCHAR(30) DEFAULT NULL",

            // Users columns
            "ALTER TABLE `users` ADD COLUMN `whatsapp` VARCHAR(20) NOT NULL DEFAULT ''",
            "ALTER TABLE `users` ADD COLUMN `role` ENUM('user','admin') NOT NULL DEFAULT 'user'"
        ];

        foreach ($migrations as $query) {
            try {
                $pdo->exec($query);
            } catch (Throwable $e) {
                // Table might not exist yet, or column already exists; safely ignore
            }
        }
    } else {
        // SQLite migrations
        $sqliteMigrations = [
            "ALTER TABLE settings ADD COLUMN site_tagline TEXT DEFAULT 'Premium Digital Subscriptions & Downloads'",
            "ALTER TABLE settings ADD COLUMN logo TEXT DEFAULT 'uploads/jhx_digital_shop_logo_v2.svg'",
            "ALTER TABLE settings ADD COLUMN favicon TEXT DEFAULT ''",
            "ALTER TABLE settings ADD COLUMN yt_link TEXT DEFAULT '#'",
            "ALTER TABLE settings ADD COLUMN fb_link TEXT DEFAULT '#'",
            "ALTER TABLE settings ADD COLUMN tg_link TEXT DEFAULT ''",
            "ALTER TABLE settings ADD COLUMN tg_user TEXT DEFAULT ''",
            "ALTER TABLE settings ADD COLUMN whatsapp_number TEXT DEFAULT ''",
            "ALTER TABLE settings ADD COLUMN site_status INTEGER NOT NULL DEFAULT 1",
            "ALTER TABLE settings ADD COLUMN auto_approve_orders INTEGER NOT NULL DEFAULT 0",
            "ALTER TABLE settings ADD COLUMN enable_manual_payment INTEGER NOT NULL DEFAULT 1",
            "ALTER TABLE settings ADD COLUMN enable_auto_payment INTEGER NOT NULL DEFAULT 0",
            "ALTER TABLE settings ADD COLUMN hostneko_api_key TEXT DEFAULT ''",
            "ALTER TABLE settings ADD COLUMN hostneko_currency_rate TEXT DEFAULT '1'",
            "ALTER TABLE settings ADD COLUMN currency_symbol TEXT NOT NULL DEFAULT '৳'",
            "ALTER TABLE settings ADD COLUMN meta_title TEXT DEFAULT NULL",
            "ALTER TABLE settings ADD COLUMN meta_desc TEXT DEFAULT NULL",
            "ALTER TABLE settings ADD COLUMN meta_keys TEXT DEFAULT NULL",
            "ALTER TABLE settings ADD COLUMN bkash_number TEXT DEFAULT ''",
            "ALTER TABLE settings ADD COLUMN nagad_number TEXT DEFAULT ''",
            "ALTER TABLE settings ADD COLUMN rocket_number TEXT DEFAULT ''",
            "ALTER TABLE settings ADD COLUMN upay_number TEXT DEFAULT ''",
            "ALTER TABLE settings ADD COLUMN manual_payment_type TEXT DEFAULT 'Personal'",
            "ALTER TABLE settings ADD COLUMN manual_payment_note TEXT DEFAULT ''",

            "ALTER TABLE products ADD COLUMN file_path TEXT DEFAULT NULL",
            "ALTER TABLE products ADD COLUMN drive_link TEXT DEFAULT NULL",
            "ALTER TABLE products ADD COLUMN image TEXT DEFAULT NULL",
            "ALTER TABLE products ADD COLUMN variations TEXT DEFAULT NULL",

            "ALTER TABLE orders ADD COLUMN payment_data TEXT DEFAULT NULL",
            "ALTER TABLE orders ADD COLUMN sub_email TEXT DEFAULT NULL",
            "ALTER TABLE orders ADD COLUMN sender_number TEXT DEFAULT NULL",

            "ALTER TABLE users ADD COLUMN whatsapp TEXT NOT NULL DEFAULT ''",
            "ALTER TABLE users ADD COLUMN role TEXT NOT NULL DEFAULT 'user'"
        ];

        foreach ($sqliteMigrations as $query) {
            try {
                $pdo->exec($query);
            } catch (Throwable $e) {
                // Table might not exist yet, or column already exists; safely ignore
            }
        }
    }
}

// ==========================================
// 1. AJAX: TEST DATABASE CONNECTION
// ==========================================
if (isset($_POST['action']) && $_POST['action'] === 'test_db') {
    header('Content-Type: application/json');
    $driver = trim($_POST['db_driver'] ?? 'mysql');

    if ($driver === 'mysql') {
        $host = trim($_POST['db_host'] ?? 'localhost');
        $port = !empty($_POST['db_port']) ? (int)$_POST['db_port'] : 3306;
        $name = trim($_POST['db_name'] ?? '');
        $user = trim($_POST['db_user'] ?? 'root');
        $pass = (string)($_POST['db_pass'] ?? '');

        if ($host === '') $host = 'localhost';
        if ($name === '') {
            echo json_encode(['success' => false, 'error' => 'Database name is required.']);
            exit();
        }

        try {
            // First attempt to connect to server without dbname to check server credentials
            $serverDsn = "mysql:host={$host};port={$port};charset=utf8mb4";
            $testPdo = new PDO($serverDsn, $user, $pass, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_TIMEOUT => 4
            ]);

            // Try to create db if not exists
            try {
                $testPdo->exec("CREATE DATABASE IF NOT EXISTS `$name` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;");
                $dbDsn = "mysql:host={$host};port={$port};dbname={$name};charset=utf8mb4";
                $dbPdo = new PDO($dbDsn, $user, $pass, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
                $tables = $dbPdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
                $tblCount = count($tables);
                if ($tblCount > 0) {
                    echo json_encode(['success' => true, 'message' => "Successfully connected to MySQL! Database '{$name}' has {$tblCount} existing tables. Existing tables will be auto-migrated without data loss."]);
                } else {
                    echo json_encode(['success' => true, 'message' => "Successfully connected to MySQL! Database '{$name}' is ready for fresh setup."]);
                }
            } catch (Throwable $e) {
                // If create fails, check if database already exists
                $dbDsn = "mysql:host={$host};port={$port};dbname={$name};charset=utf8mb4";
                $dbPdo = new PDO($dbDsn, $user, $pass, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
                $tables = $dbPdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
                $tblCount = count($tables);
                if ($tblCount > 0) {
                    echo json_encode(['success' => true, 'message' => "Successfully connected to existing database '{$name}' ({$tblCount} tables found)!"]);
                } else {
                    echo json_encode(['success' => true, 'message' => "Successfully connected to existing database '{$name}'!"]);
                }
            }
            exit();
        } catch (Throwable $e) {
            echo json_encode(['success' => false, 'error' => $e->getMessage()]);
            exit();
        }
    } else {
        // SQLite test
        $sqliteFile = $storageDir . '/database.sqlite';
        if (is_writable($storageDir) || is_writable($sqliteFile)) {
            echo json_encode(['success' => true, 'message' => 'SQLite storage directory is writable.']);
        } else {
            echo json_encode(['success' => false, 'error' => 'Storage directory is not writable.']);
        }
        exit();
    }
}

// ==========================================
// 2. AJAX: EXECUTE INSTALLATION
// ==========================================
if (isset($_POST['action']) && $_POST['action'] === 'do_install') {
    header('Content-Type: application/json');

    $driver      = trim($_POST['db_driver'] ?? 'mysql');
    $dbHost      = trim($_POST['db_host'] ?? 'localhost');
    $dbPort      = !empty($_POST['db_port']) ? (int)$_POST['db_port'] : 3306;
    $dbName      = trim($_POST['db_name'] ?? 'digitalshop');
    $dbUser      = trim($_POST['db_user'] ?? 'root');
    $dbPass      = (string)($_POST['db_pass'] ?? '');

    $siteName    = trim($_POST['site_name'] ?? 'Digital Shop');
    $siteTagline = trim($_POST['site_tagline'] ?? 'Premium Digital Subscriptions & Downloads');
    $currency    = trim($_POST['currency_symbol'] ?? '৳');
    $autoApprove = !empty($_POST['auto_approve_orders']) ? 1 : 0;
    $adminName   = trim($_POST['admin_name'] ?? 'Site Administrator');
    $adminEmail  = strtolower(trim($_POST['admin_email'] ?? 'admin@gmail.com'));
    $adminPass   = (string)($_POST['admin_pass'] ?? 'admin123456');
    $loadDemo     = !empty($_POST['sample_catalog']);
    $cleanInstall = !empty($_POST['clean_install']);

    if ($siteName === '') $siteName = 'Digital Shop';
    if ($currency === '') $currency = '৳';
    if ($adminName === '' || !filter_var($adminEmail, FILTER_VALIDATE_EMAIL)) {
        echo json_encode(['success' => false, 'error' => 'Please provide a valid Admin Email address.']);
        exit();
    }
    if (strlen($adminPass) < 6) {
        echo json_encode(['success' => false, 'error' => 'Admin password must be at least 6 characters.']);
        exit();
    }

    try {
        $pdo = null;

        if ($driver === 'mysql') {
            if ($dbHost === '') $dbHost = 'localhost';
            if ($dbName === '') {
                echo json_encode(['success' => false, 'error' => 'Database name is required for MySQL.']);
                exit();
            }

            // 1. Connect and create database if not exists
            $serverDsn = "mysql:host={$dbHost};port={$dbPort};charset=utf8mb4";
            try {
                $rootPdo = new PDO($serverDsn, $dbUser, $dbPass, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
                $rootPdo->exec("CREATE DATABASE IF NOT EXISTS `$dbName` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;");
            } catch (Throwable $ignore) {
                // If user doesn't have global create DB privilege, proceed to direct connect
            }

            // 2. Connect to the targeted database
            $dbDsn = "mysql:host={$dbHost};port={$dbPort};dbname={$dbName};charset=utf8mb4";
            $pdo = new PDO($dbDsn, $dbUser, $dbPass, [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
                PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4"
            ]);

            // Handle Clean Install vs Defensive Schema Migration
            if ($cleanInstall) {
                $pdo->exec("SET FOREIGN_KEY_CHECKS = 0;");
                $dropTables = ['orders', 'products', 'categories', 'sliders', 'users', 'settings'];
                foreach ($dropTables as $tbl) {
                    $pdo->exec("DROP TABLE IF EXISTS `$tbl`;");
                }
                $pdo->exec("SET FOREIGN_KEY_CHECKS = 1;");
            } else {
                // Pre-migration: ensure existing tables receive missing columns before schema queries
                ensureLatestSchema($pdo, 'mysql');
            }

            // 3. Import MySQL schema
            $schemaFile = __DIR__ . '/database/schema.sql';
            if (is_file($schemaFile)) {
                $sql = file_get_contents($schemaFile);
                // Execute multi-query safely
                $pdo->exec($sql);
            } else {
                // Inline schema fallback
                $pdo->exec("
                    SET NAMES utf8mb4;
                    CREATE TABLE IF NOT EXISTS categories (
                        id INT NOT NULL AUTO_INCREMENT,
                        name VARCHAR(100) NOT NULL,
                        PRIMARY KEY (id)
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

                    CREATE TABLE IF NOT EXISTS users (
                        id INT NOT NULL AUTO_INCREMENT,
                        name VARCHAR(100) NOT NULL,
                        whatsapp VARCHAR(20) NOT NULL DEFAULT '',
                        email VARCHAR(190) NOT NULL,
                        password VARCHAR(255) NOT NULL,
                        role ENUM('user','admin') NOT NULL DEFAULT 'user',
                        created_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
                        PRIMARY KEY (id),
                        UNIQUE KEY uq_users_email (email)
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

                    CREATE TABLE IF NOT EXISTS products (
                        id INT NOT NULL AUTO_INCREMENT,
                        category_id INT DEFAULT NULL,
                        title VARCHAR(255) NOT NULL,
                        description TEXT DEFAULT NULL,
                        product_type ENUM('downloadable','subscription') NOT NULL,
                        regular_price DECIMAL(10,2) NOT NULL,
                        offer_price DECIMAL(10,2) NOT NULL,
                        stock INT NOT NULL DEFAULT 1,
                        drive_link TEXT DEFAULT NULL,
                        file_path VARCHAR(255) DEFAULT NULL,
                        image VARCHAR(255) DEFAULT NULL,
                        variations TEXT DEFAULT NULL,
                        PRIMARY KEY (id)
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

                    CREATE TABLE IF NOT EXISTS orders (
                        id INT NOT NULL AUTO_INCREMENT,
                        user_id INT NOT NULL,
                        product_id INT NOT NULL,
                        amount DECIMAL(10,2) NOT NULL,
                        status ENUM('Pending','Processing','Completed','Rejected') NOT NULL DEFAULT 'Pending',
                        payment_method ENUM('Manual') NOT NULL DEFAULT 'Manual',
                        sub_email VARCHAR(190) DEFAULT NULL,
                        sender_number VARCHAR(30) DEFAULT NULL,
                        trx_id VARCHAR(100) NOT NULL,
                        payment_data TEXT DEFAULT NULL,
                        created_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
                        PRIMARY KEY (id),
                        UNIQUE KEY uq_orders_trx_id (trx_id)
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

                    CREATE TABLE IF NOT EXISTS settings (
                        id INT NOT NULL DEFAULT 1,
                        site_name VARCHAR(100) NOT NULL DEFAULT 'Digital Shop',
                        site_tagline VARCHAR(255) DEFAULT 'Premium Digital Subscriptions & Downloads',
                        logo VARCHAR(255) DEFAULT 'uploads/jhx_digital_shop_logo_v2.svg',
                        favicon VARCHAR(255) DEFAULT '',
                        yt_link VARCHAR(255) DEFAULT '#',
                        fb_link VARCHAR(255) DEFAULT '#',
                        tg_link VARCHAR(255) DEFAULT '',
                        tg_user VARCHAR(100) DEFAULT '',
                        whatsapp_number VARCHAR(30) DEFAULT NULL,
                        site_status TINYINT(1) NOT NULL DEFAULT 1,
                        auto_approve_orders TINYINT(1) NOT NULL DEFAULT 0,
                        enable_manual_payment TINYINT(1) NOT NULL DEFAULT 1,
                        enable_auto_payment TINYINT(1) NOT NULL DEFAULT 0,
                        hostneko_api_key VARCHAR(255) DEFAULT '',
                        hostneko_currency_rate VARCHAR(20) DEFAULT '1',
                        currency_symbol VARCHAR(10) NOT NULL DEFAULT '৳',
                        meta_title TEXT,
                        meta_desc TEXT,
                        meta_keys TEXT,
                        bkash_number VARCHAR(30) DEFAULT NULL,
                        nagad_number VARCHAR(30) DEFAULT NULL,
                        rocket_number VARCHAR(30) DEFAULT NULL,
                        upay_number VARCHAR(30) DEFAULT NULL,
                        manual_payment_type VARCHAR(20) DEFAULT 'Personal',
                        manual_payment_note TEXT,
                        PRIMARY KEY (id)
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

                    CREATE TABLE IF NOT EXISTS sliders (
                        id INT NOT NULL AUTO_INCREMENT,
                        image VARCHAR(255) NOT NULL,
                        link VARCHAR(255) DEFAULT NULL,
                        created_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
                        PRIMARY KEY (id)
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
                ");
            }

            // Post-migration: guarantee all columns are present across all tables
            ensureLatestSchema($pdo, 'mysql');
        } else {
            // SQLite Setup
            $dbFile = $storageDir . '/database.sqlite';
            $pdo = new PDO('sqlite:' . $dbFile, null, null, [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ]);
            $pdo->exec("PRAGMA journal_mode = WAL;");
            $pdo->exec("PRAGMA busy_timeout = 5000;");

            if ($cleanInstall) {
                $dropTables = ['orders', 'products', 'categories', 'sliders', 'users', 'settings'];
                foreach ($dropTables as $tbl) {
                    $pdo->exec("DROP TABLE IF EXISTS `$tbl`;");
                }
            } else {
                ensureLatestSchema($pdo, 'sqlite');
            }

            $pdo->exec("
                CREATE TABLE IF NOT EXISTS categories (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS users (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL,
                    whatsapp TEXT NOT NULL DEFAULT '',
                    email TEXT NOT NULL UNIQUE,
                    password TEXT NOT NULL,
                    role TEXT NOT NULL DEFAULT 'user',
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
                );
                CREATE TABLE IF NOT EXISTS products (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    category_id INTEGER,
                    title TEXT NOT NULL,
                    description TEXT,
                    product_type TEXT NOT NULL,
                    regular_price REAL NOT NULL,
                    offer_price REAL NOT NULL,
                    stock INTEGER NOT NULL DEFAULT 1,
                    drive_link TEXT,
                    file_path TEXT,
                    image TEXT,
                    variations TEXT
                );
                CREATE TABLE IF NOT EXISTS orders (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER NOT NULL,
                    product_id INTEGER NOT NULL,
                    amount REAL NOT NULL,
                    status TEXT NOT NULL DEFAULT 'Pending',
                    payment_method TEXT NOT NULL DEFAULT 'Manual',
                    sub_email TEXT,
                    sender_number TEXT,
                    trx_id TEXT NOT NULL UNIQUE,
                    payment_data TEXT,
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
                );
                CREATE TABLE IF NOT EXISTS settings (
                    id INTEGER PRIMARY KEY DEFAULT 1,
                    site_name TEXT NOT NULL DEFAULT 'Digital Shop',
                    site_tagline TEXT DEFAULT 'Premium Digital Subscriptions & Downloads',
                    logo TEXT DEFAULT 'uploads/jhx_digital_shop_logo_v2.svg',
                    favicon TEXT DEFAULT '',
                    yt_link TEXT DEFAULT '#',
                    fb_link TEXT DEFAULT '#',
                    tg_link TEXT DEFAULT '',
                    tg_user TEXT DEFAULT '',
                    whatsapp_number TEXT DEFAULT '',
                    site_status INTEGER NOT NULL DEFAULT 1,
                    auto_approve_orders INTEGER NOT NULL DEFAULT 0,
                    enable_manual_payment INTEGER NOT NULL DEFAULT 1,
                    enable_auto_payment INTEGER NOT NULL DEFAULT 0,
                    hostneko_api_key TEXT DEFAULT '',
                    hostneko_currency_rate TEXT DEFAULT '1',
                    currency_symbol TEXT NOT NULL DEFAULT '৳',
                    meta_title TEXT DEFAULT 'Digital Shop | Premium Subscriptions',
                    meta_desc TEXT DEFAULT 'Buy verified digital subscriptions and downloads instantly.',
                    meta_keys TEXT DEFAULT 'digital shop, subscriptions, instant delivery',
                    bkash_number TEXT DEFAULT '',
                    nagad_number TEXT DEFAULT '',
                    rocket_number TEXT DEFAULT '',
                    upay_number TEXT DEFAULT '',
                    manual_payment_type TEXT DEFAULT 'Personal',
                    manual_payment_note TEXT DEFAULT 'Send money to our number and provide Transaction ID.'
                );
                CREATE TABLE IF NOT EXISTS sliders (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    image TEXT NOT NULL,
                    link TEXT DEFAULT NULL,
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
                );
            ");

            ensureLatestSchema($pdo, 'sqlite');
        }

        // Insert / Update Admin User
        $hashedPass = password_hash($adminPass, PASSWORD_DEFAULT);
        $checkAdmin = $pdo->prepare("SELECT id FROM users WHERE email = ?");
        $checkAdmin->execute([$adminEmail]);
        $existingAdmin = $checkAdmin->fetch();

        if ($existingAdmin) {
            $updateAdmin = $pdo->prepare("UPDATE users SET name = ?, password = ?, role = 'admin' WHERE id = ?");
            $updateAdmin->execute([$adminName, $hashedPass, $existingAdmin['id']]);
        } else {
            $insertAdmin = $pdo->prepare("INSERT INTO users (name, whatsapp, email, password, role) VALUES (?, '', ?, ?, 'admin')");
            $insertAdmin->execute([$adminName, $adminEmail, $hashedPass]);
        }

        // Configure settings (Safe Upsert: preserves existing payment numbers/gateway keys if present)
        $checkSet = $pdo->query("SELECT id FROM settings WHERE id = 1")->fetch();
        if ($checkSet) {
            $settingsStmt = $pdo->prepare("UPDATE settings SET 
                site_name = ?, 
                site_tagline = ?, 
                currency_symbol = ?, 
                auto_approve_orders = ? 
                WHERE id = 1");
            $settingsStmt->execute([
                $siteName,
                $siteTagline,
                $currency,
                $autoApprove
            ]);
        } else {
            $settingsStmt = $pdo->prepare("INSERT INTO settings (
                id, site_name, site_tagline, currency_symbol, auto_approve_orders, logo, 
                tg_link, tg_user, yt_link, meta_title, meta_desc, site_status
            ) VALUES (1, ?, ?, ?, ?, 'uploads/jhx_digital_shop_logo_v2.svg', '', '', '#', ?, ?, 1)");
            $settingsStmt->execute([
                $siteName,
                $siteTagline,
                $currency,
                $autoApprove,
                $siteName . ' | Premium Digital Subscriptions',
                'Buy premium digital subscriptions and downloadable products with fast delivery.'
            ]);
        }

        // Sample Demo Catalog if selected
        if ($loadDemo) {
            $catCount = $pdo->query("SELECT COUNT(*) FROM categories")->fetchColumn();
            if ((int)$catCount === 0) {
                $pdo->exec("INSERT INTO categories (name) VALUES ('Premium Subscriptions')");
                $catId = (int)$pdo->lastInsertId();

                $demoProducts = [
                    ['Gemini Premium - 18 Months', 'Premium AI subscription access with fast delivery.', 'subscription', 599, 399, 'uploads/gemini_premium_18_months.svg', '18 Months'],
                    ['YouTube Premium - 12 Months', 'Ad-free premium streaming experience.', 'subscription', 1499, 999, 'uploads/youtube_premium_12_months.svg', '12 Months'],
                    ['Netflix Premium - 1 Month', 'Ultra HD 4K streaming access.', 'subscription', 699, 499, 'uploads/netflix_premium_1_month.svg', '1 Month'],
                    ['Telegram Premium - 12 Months', 'Premium Telegram features with fast manual delivery.', 'subscription', 1599, 1199, 'uploads/telegram_premium_12_months.svg', '12 Months'],
                    ['ChatGPT Premium - 1 Month', 'Premium AI GPT-4 access with instant activation.', 'subscription', 1499, 1299, 'uploads/chatgpt_premium_1_month.svg', '1 Month']
                ];

                $pStmt = $pdo->prepare("INSERT INTO products (category_id, title, description, product_type, regular_price, offer_price, stock, image, variations) VALUES (?, ?, ?, ?, ?, ?, 1000, ?, ?)");
                foreach ($demoProducts as $dp) {
                    $pStmt->execute([$catId, $dp[0], $dp[1], $dp[2], $dp[3], $dp[4], $dp[5], $dp[6]]);
                }
                $pdo->exec("INSERT INTO sliders (image, link) VALUES ('uploads/sliders/jhx_digital_shop_slider_v2.svg', 'index.php')");
            }
        }

        // Write db_config.php to root and storage
        $configComment = "<?php\n/**\n * Digital Shop - Database Configuration File\n * Generated by Installer on " . date('Y-m-d H:i:s') . "\n *\n * আপনার যদি আগের ডাটাবেজ থাকে, নিচে credentials পরিবর্তন করলেই কাজ করবে।\n */\n\nreturn [\n";
        $configContent = $configComment;
        $configContent .= "    'driver' => " . var_export($driver, true) . ",\n";
        if ($driver === 'mysql') {
            $configContent .= "    'host'   => " . var_export($dbHost, true) . ",\n";
            $configContent .= "    'port'   => " . var_export($dbPort, true) . ",\n";
            $configContent .= "    'name'   => " . var_export($dbName, true) . ",\n";
            $configContent .= "    'user'   => " . var_export($dbUser, true) . ",\n";
            $configContent .= "    'pass'   => " . var_export($dbPass, true) . ",\n";
        } else {
            $configContent .= "    'file'   => " . var_export($storageDir . '/database.sqlite', true) . ",\n";
        }
        $configContent .= "];\n";

        @file_put_contents($rootConfigFile, $configContent);
        @file_put_contents($dbConfigFile, $configContent);

        // Protect storage directory
        @file_put_contents($storageDir . '/.htaccess', "Deny from all\n<FilesMatch \"\\.(sqlite|db|log|json|php)$\"><RequireAll>Require all denied</RequireAll></FilesMatch>\n");
        @file_put_contents($installedFile, date('c') . "\n");

        echo json_encode([
            'success'     => true,
            'admin_email' => $adminEmail,
            'admin_pass'  => $adminPass,
            'site_name'   => $siteName,
            'driver'      => $driver
        ]);
        exit();
    } catch (Throwable $e) {
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
        exit();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Setup & Installation Wizard | Digital Shop</title>
<link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700;800;900&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
:root {
    --primary: #2563eb;
    --primary-gradient: linear-gradient(135deg, #2563eb 0%, #4338ca 100%);
    --bg-dark: #090d16;
    --card-bg: rgba(23, 31, 51, 0.88);
    --border-color: rgba(255, 255, 255, 0.08);
    --border-focus: #3b82f6;
    --text-white: #f8fafc;
    --text-muted: #94a3b8;
    --success: #10b981;
    --danger: #ef4444;
}

* { box-sizing: border-box; margin: 0; padding: 0; }
body {
    font-family: 'Outfit', sans-serif;
    background-color: var(--bg-dark);
    background-image: 
        radial-gradient(at 0% 0%, rgba(37, 99, 235, 0.22) 0px, transparent 50%),
        radial-gradient(at 100% 100%, rgba(67, 56, 202, 0.25) 0px, transparent 50%);
    color: var(--text-white);
    min-height: 100vh;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    padding: 30px 16px;
}

.installer-container {
    width: min(740px, 100%);
}

.installer-card {
    background: var(--card-bg);
    backdrop-filter: blur(24px);
    border: 1px solid var(--border-color);
    border-radius: 26px;
    padding: clamp(24px, 5vw, 44px);
    box-shadow: 0 25px 60px rgba(0, 0, 0, 0.5);
    position: relative;
    overflow: hidden;
}

.installer-card::before {
    content: '';
    position: absolute;
    top: 0; left: 0; right: 0;
    height: 5px;
    background: var(--primary-gradient);
}

.brand-header {
    text-align: center;
    margin-bottom: 28px;
}

.brand-badge {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    background: rgba(37, 99, 235, 0.15);
    border: 1px solid rgba(37, 99, 235, 0.35);
    padding: 6px 14px;
    border-radius: 999px;
    font-size: 0.75rem;
    font-weight: 700;
    color: #60a5fa;
    text-transform: uppercase;
    letter-spacing: 1px;
    margin-bottom: 12px;
}

.brand-title {
    font-size: clamp(1.6rem, 3.5vw, 2.1rem);
    font-weight: 900;
    color: #fff;
    letter-spacing: -0.5px;
}

.brand-desc {
    color: var(--text-muted);
    font-size: 0.92rem;
    margin-top: 6px;
}

/* Wizard Steps Indicator */
.steps-nav {
    display: flex;
    justify-content: space-between;
    position: relative;
    margin-bottom: 32px;
    padding: 0 10px;
}

.steps-nav::before {
    content: '';
    position: absolute;
    top: 50%;
    left: 40px;
    right: 40px;
    height: 2px;
    background: rgba(255, 255, 255, 0.08);
    transform: translateY(-50%);
    z-index: 1;
}

.step-item {
    position: relative;
    z-index: 2;
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 6px;
    background: var(--card-bg);
    padding: 0 8px;
}

.step-circle {
    width: 38px;
    height: 38px;
    border-radius: 50%;
    background: rgba(255, 255, 255, 0.06);
    border: 2px solid var(--border-color);
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: 800;
    font-size: 0.85rem;
    color: var(--text-muted);
    transition: 0.3s;
}

.step-item.active .step-circle {
    background: var(--primary-gradient);
    border-color: #60a5fa;
    color: #fff;
    box-shadow: 0 0 20px rgba(37, 99, 235, 0.5);
}

.step-item.completed .step-circle {
    background: #059669;
    border-color: #34d399;
    color: #fff;
}

.step-label {
    font-size: 0.72rem;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.6px;
    color: var(--text-muted);
}

.step-item.active .step-label {
    color: #60a5fa;
}

/* Sections */
.form-section {
    display: none;
    animation: fadeIn 0.35s ease;
}

.form-section.active {
    display: block;
}

@keyframes fadeIn {
    from { opacity: 0; transform: translateY(8px); }
    to { opacity: 1; transform: translateY(0); }
}

.section-title {
    font-size: 1.15rem;
    font-weight: 800;
    color: #fff;
    margin-bottom: 6px;
    display: flex;
    align-items: center;
    gap: 10px;
}

.section-subtitle {
    color: var(--text-muted);
    font-size: 0.86rem;
    margin-bottom: 22px;
}

/* Driver Selector Pills */
.driver-selector {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 12px;
    margin-bottom: 20px;
}

.driver-pill {
    position: relative;
    border: 2px solid var(--border-color);
    border-radius: 14px;
    padding: 16px;
    cursor: pointer;
    background: rgba(255, 255, 255, 0.02);
    transition: 0.25s;
    display: flex;
    align-items: flex-start;
    gap: 12px;
}

.driver-pill:hover {
    border-color: rgba(96, 165, 250, 0.4);
    background: rgba(255, 255, 255, 0.04);
}

.driver-pill.selected {
    border-color: var(--primary);
    background: rgba(37, 99, 235, 0.12);
    box-shadow: 0 0 20px rgba(37, 99, 235, 0.15);
}

.driver-pill input {
    display: none;
}

.driver-pill .icon {
    font-size: 1.4rem;
    color: #60a5fa;
}

.driver-pill .name {
    font-weight: 800;
    font-size: 0.95rem;
    color: #fff;
}

.driver-pill .desc {
    font-size: 0.76rem;
    color: var(--text-muted);
    margin-top: 3px;
}

.driver-pill .badge-rec {
    display: inline-block;
    background: #059669;
    color: #fff;
    font-size: 0.6rem;
    padding: 2px 6px;
    border-radius: 4px;
    font-weight: 800;
    text-transform: uppercase;
    margin-left: 6px;
}

/* Grid & Inputs */
.form-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 16px;
    margin-bottom: 16px;
}

.col-span-2 {
    grid-column: span 2;
}

.input-group {
    display: flex;
    flex-direction: column;
    gap: 7px;
}

.input-label {
    font-size: 0.78rem;
    font-weight: 700;
    color: #e2e8f0;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    display: flex;
    align-items: center;
    gap: 6px;
}

.input-label i {
    color: #60a5fa;
}

.input-control {
    background: rgba(15, 23, 42, 0.8);
    border: 1px solid var(--border-color);
    border-radius: 12px;
    padding: 12px 14px;
    color: #fff;
    font-family: inherit;
    font-size: 0.92rem;
    font-weight: 500;
    transition: 0.25s;
    width: 100%;
}

.input-control:focus {
    outline: none;
    border-color: var(--border-focus);
    box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.25);
    background: rgba(15, 23, 42, 1);
}

.input-control::placeholder {
    color: #64748b;
}

.pw-wrapper {
    position: relative;
}

.pw-toggle {
    position: absolute;
    right: 12px;
    top: 50%;
    transform: translateY(-50%);
    background: none;
    border: none;
    color: #64748b;
    cursor: pointer;
    font-size: 0.9rem;
}

.pw-toggle:hover {
    color: #94a3b8;
}

/* Checkboxes */
.checkbox-card {
    display: flex;
    align-items: flex-start;
    gap: 12px;
    background: rgba(255, 255, 255, 0.02);
    border: 1px solid var(--border-color);
    border-radius: 14px;
    padding: 14px 16px;
    margin-bottom: 14px;
    cursor: pointer;
    transition: 0.2s;
}

.checkbox-card:hover {
    background: rgba(255, 255, 255, 0.04);
}

.checkbox-card input[type="checkbox"] {
    width: 18px;
    height: 18px;
    margin-top: 2px;
    accent-color: var(--primary);
    cursor: pointer;
}

.checkbox-copy strong {
    display: block;
    font-size: 0.88rem;
    color: #fff;
    margin-bottom: 2px;
}

.checkbox-copy span {
    font-size: 0.78rem;
    color: var(--text-muted);
}

/* Alert Boxes */
.alert-box {
    padding: 12px 16px;
    border-radius: 12px;
    font-size: 0.85rem;
    font-weight: 600;
    display: flex;
    align-items: center;
    gap: 10px;
    margin-bottom: 18px;
}

.alert-success {
    background: rgba(16, 185, 129, 0.12);
    border: 1px solid rgba(16, 185, 129, 0.3);
    color: #34d399;
}

.alert-error {
    background: rgba(239, 68, 68, 0.12);
    border: 1px solid rgba(239, 68, 68, 0.3);
    color: #f87171;
}

/* Button Row */
.btn-row {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 12px;
    margin-top: 24px;
    padding-top: 20px;
    border-top: 1px solid var(--border-color);
}

.btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    padding: 13px 24px;
    border-radius: 14px;
    font-size: 0.88rem;
    font-weight: 800;
    cursor: pointer;
    transition: 0.25s;
    border: none;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    text-decoration: none;
}

.btn-primary {
    background: var(--primary-gradient);
    color: #fff;
    box-shadow: 0 10px 25px rgba(37, 99, 235, 0.3);
}

.btn-primary:hover {
    transform: translateY(-2px);
    box-shadow: 0 14px 30px rgba(37, 99, 235, 0.45);
}

.btn-secondary {
    background: rgba(255, 255, 255, 0.08);
    color: #e2e8f0;
    border: 1px solid var(--border-color);
}

.btn-secondary:hover {
    background: rgba(255, 255, 255, 0.14);
}

.btn-outline-test {
    background: transparent;
    border: 1px dashed #60a5fa;
    color: #60a5fa;
    padding: 10px 18px;
    font-size: 0.8rem;
}

.btn-outline-test:hover {
    background: rgba(96, 165, 250, 0.1);
}

/* Success Card */
.success-card {
    text-align: center;
    padding: 20px 0;
}

.success-icon {
    width: 76px;
    height: 76px;
    background: rgba(16, 185, 129, 0.15);
    border: 2px solid #10b981;
    border-radius: 50%;
    display: grid;
    place-items: center;
    margin: 0 auto 20px;
    color: #34d399;
    font-size: 2.2rem;
    animation: scaleIn 0.5s cubic-bezier(0.175, 0.885, 0.32, 1.275);
}

@keyframes scaleIn {
    from { transform: scale(0.5); opacity: 0; }
    to { transform: scale(1); opacity: 1; }
}

.creds-box {
    background: rgba(15, 23, 42, 0.7);
    border: 1px solid var(--border-color);
    border-radius: 16px;
    padding: 18px;
    margin: 22px 0;
    text-align: left;
}

.creds-row {
    display: flex;
    justify-content: space-between;
    padding: 8px 0;
    border-bottom: 1px solid rgba(255, 255, 255, 0.05);
    font-size: 0.88rem;
}

.creds-row:last-child {
    border-bottom: none;
}

.creds-row span {
    color: var(--text-muted);
}

.creds-row strong {
    color: #60a5fa;
}

/* Already installed */
.installed-box {
    text-align: center;
    padding: 20px 0;
}

@media (max-width: 640px) {
    .form-grid { grid-template-columns: 1fr; }
    .col-span-2 { grid-column: span 1; }
    .driver-selector { grid-template-columns: 1fr; }
    .btn-row { flex-direction: column-reverse; }
    .btn-row .btn { width: 100%; }
}
</style>
</head>
<body>

<div class="installer-container">

    <div class="installer-card">
        <header class="brand-header">
            <div class="brand-badge"><i class="fas fa-rocket"></i> Master Setup Engine</div>
            <h1 class="brand-title">Digital Shop Setup</h1>
            <p class="brand-desc">Configure your SQL database connection, admin login, and store settings.</p>
        </header>

        <?php if ($isInstalled): ?>
            <!-- ALREADY INSTALLED NOTICE -->
            <div class="installed-box">
                <div class="success-icon"><i class="fas fa-check"></i></div>
                <h2 style="font-size: 1.4rem; font-weight: 900; margin-bottom: 10px;">The System is Already Installed</h2>
                <p style="color: var(--text-muted); font-size: 0.9rem; max-width: 460px; margin: 0 auto 24px;">
                    Your digital store is fully configured and operational. If you need to reconfigure database connection or admin credentials, click Reinstall below.
                </p>
                <div style="display: flex; gap: 12px; justify-content: center; flex-wrap: wrap;">
                    <a href="index.php" class="btn btn-primary"><i class="fas fa-store"></i> Visit Storefront</a>
                    <a href="admin/login.php" class="btn btn-secondary"><i class="fas fa-lock"></i> Admin Panel</a>
                    <a href="install.php?force=1" class="btn btn-outline-test" onclick="return confirm('Do you want to reconfigure the database and store setup?');"><i class="fas fa-rotate"></i> Reinstall</a>
                </div>
            </div>
        <?php else: ?>

            <!-- WIZARD STEP INDICATOR -->
            <div class="steps-nav">
                <div class="step-item active" id="navStep1">
                    <div class="step-circle">1</div>
                    <span class="step-label">Database</span>
                </div>
                <div class="step-item" id="navStep2">
                    <div class="step-circle">2</div>
                    <span class="step-label">Admin & Store</span>
                </div>
                <div class="step-item" id="navStep3">
                    <div class="step-circle">3</div>
                    <span class="step-label">Complete</span>
                </div>
            </div>

            <!-- STEP 1: DATABASE CONFIGURATION -->
            <section class="form-section active" id="section1">
                <div class="section-title"><i class="fas fa-database text-primary" style="color: #60a5fa;"></i> SQL Database Connection</div>
                <p class="section-subtitle">Choose your database engine and provide SQL server credentials.</p>

                <div class="driver-selector">
                    <label class="driver-pill selected" id="driverMysqlLabel">
                        <input type="radio" name="driver_choice" value="mysql" checked onchange="selectDriver('mysql')">
                        <div class="icon"><i class="fas fa-server"></i></div>
                        <div>
                            <div class="name">MySQL / MariaDB <span class="badge-rec">Recommended</span></div>
                            <div class="desc">Standard for cPanel, XAMPP, VPS & phpMyAdmin.</div>
                        </div>
                    </label>
                    <label class="driver-pill" id="driverSqliteLabel">
                        <input type="radio" name="driver_choice" value="sqlite" onchange="selectDriver('sqlite')">
                        <div class="icon"><i class="fas fa-file-shield"></i></div>
                        <div>
                            <div class="name">SQLite 3</div>
                            <div class="desc">Zero configuration, single file database.</div>
                        </div>
                    </label>
                </div>

                <div id="mysqlFields">
                    <div class="form-grid">
                        <div class="input-group">
                            <label class="input-label"><i class="fas fa-network-wired"></i> Database Host</label>
                            <input type="text" class="input-control" id="db_host" value="<?= htmlspecialchars($existingConfig['host'] ?? 'localhost') ?>" placeholder="e.g. localhost or 127.0.0.1">
                        </div>
                        <div class="input-group">
                            <label class="input-label"><i class="fas fa-hashtag"></i> Port</label>
                            <input type="number" class="input-control" id="db_port" value="<?= htmlspecialchars((string)($existingConfig['port'] ?? '3306')) ?>" placeholder="3306">
                        </div>
                        <div class="input-group col-span-2">
                            <label class="input-label"><i class="fas fa-database"></i> Database Name</label>
                            <input type="text" class="input-control" id="db_name" value="<?= htmlspecialchars($existingConfig['name'] ?? 'digitalshop') ?>" placeholder="e.g. digital_shop_db">
                        </div>
                        <div class="input-group">
                            <label class="input-label"><i class="fas fa-user"></i> Database Username</label>
                            <input type="text" class="input-control" id="db_user" value="<?= htmlspecialchars($existingConfig['user'] ?? 'root') ?>" placeholder="e.g. root">
                        </div>
                        <div class="input-group">
                            <label class="input-label"><i class="fas fa-key"></i> Database Password</label>
                            <div class="pw-wrapper">
                                <input type="password" class="input-control" id="db_pass" value="<?= htmlspecialchars($existingConfig['pass'] ?? '') ?>" placeholder="Leave blank if none">
                                <button type="button" class="pw-toggle" onclick="togglePw('db_pass', this)"><i class="fas fa-eye"></i></button>
                            </div>
                        </div>
                    </div>

                    <div style="display: flex; justify-content: flex-end; margin-bottom: 14px;">
                        <button type="button" class="btn btn-outline-test" id="btnTestDb" onclick="testConnection()">
                            <i class="fas fa-plug-circle-check"></i> Test SQL Connection
                        </button>
                    </div>
                </div>

                <div id="dbStatus"></div>

                <div class="btn-row">
                    <div></div>
                    <button type="button" class="btn btn-primary" onclick="goToStep2()">
                        Next: Admin & Store <i class="fas fa-arrow-right"></i>
                    </button>
                </div>
            </section>

            <!-- STEP 2: ADMIN & STORE SETUP -->
            <section class="form-section" id="section2">
                <div class="section-title"><i class="fas fa-user-shield text-primary" style="color: #60a5fa;"></i> Admin Account & Store Setup</div>
                <p class="section-subtitle">Set your admin login credentials and initial storefront preferences.</p>

                <div class="form-grid">
                    <div class="input-group">
                        <label class="input-label"><i class="fas fa-id-badge"></i> Admin Full Name</label>
                        <input type="text" class="input-control" id="admin_name" value="Site Administrator" placeholder="e.g. John Doe">
                    </div>
                    <div class="input-group">
                        <label class="input-label"><i class="fas fa-envelope"></i> Admin Email (Login)</label>
                        <input type="email" class="input-control" id="admin_email" value="admin@gmail.com" placeholder="e.g. admin@gmail.com" required>
                    </div>
                    <div class="input-group col-span-2">
                        <label class="input-label"><i class="fas fa-lock"></i> Admin Password</label>
                        <div class="pw-wrapper">
                            <input type="password" class="input-control" id="admin_pass" value="admin123456" placeholder="Minimum 6 characters" required>
                            <button type="button" class="pw-toggle" onclick="togglePw('admin_pass', this)"><i class="fas fa-eye"></i></button>
                        </div>
                    </div>

                    <div class="input-group">
                        <label class="input-label"><i class="fas fa-store"></i> Store / Website Name</label>
                        <input type="text" class="input-control" id="site_name" value="Digital Shop" placeholder="Digital Shop">
                    </div>
                    <div class="input-group">
                        <label class="input-label"><i class="fas fa-coins"></i> Currency Symbol</label>
                        <input type="text" class="input-control" id="currency_symbol" value="৳" placeholder="৳ or $">
                    </div>
                    <div class="input-group col-span-2">
                        <label class="input-label"><i class="fas fa-heading"></i> Store Tagline</label>
                        <input type="text" class="input-control" id="site_tagline" value="Premium Digital Subscriptions & Downloads">
                    </div>
                </div>

                <label class="checkbox-card">
                    <input type="checkbox" id="auto_approve_orders">
                    <div class="checkbox-copy">
                        <strong>⚡ Instant Order Activation (Auto-Approve Orders)</strong>
                        <span>When enabled, client orders become immediately Active (Completed) upon submitting TrxID & phone number, giving immediate download access to ZIP files. (Can be toggled later in Admin Settings)</span>
                    </div>
                </label>

                <label class="checkbox-card">
                    <input type="checkbox" id="sample_catalog" checked>
                    <div class="checkbox-copy">
                        <strong>📦 Install Sample Demo Products & Sliders</strong>
                        <span>Seeds ready-to-use digital subscriptions, categories, and banners so your store looks great right away.</span>
                    </div>
                </label>

                <label class="checkbox-card" style="border-color: rgba(239, 68, 68, 0.25);">
                    <input type="checkbox" id="clean_install">
                    <div class="checkbox-copy">
                        <strong style="color: #fca5a5;"><i class="fas fa-trash-can" style="margin-right: 4px;"></i> Clean Reinstall (Drop Existing Tables)</strong>
                        <span>Check this if you want to completely erase existing tables in the database and install fresh. Leave unchecked to safely preserve existing orders, products, and users while upgrading the database schema.</span>
                    </div>
                </label>

                <div id="installStatus"></div>

                <div class="btn-row">
                    <button type="button" class="btn btn-secondary" onclick="goToStep1()">
                        <i class="fas fa-arrow-left"></i> Back
                    </button>
                    <button type="button" class="btn btn-primary" id="btnInstall" onclick="runInstallation()">
                        <i class="fas fa-bolt"></i> Complete Installation
                    </button>
                </div>
            </section>

            <!-- STEP 3: CELEBRATION & READY -->
            <section class="form-section" id="section3">
                <div class="success-card">
                    <div class="success-icon"><i class="fas fa-check-double"></i></div>
                    <h2 style="font-size: 1.6rem; font-weight: 900; margin-bottom: 8px;">Installation Completed Successfully!</h2>
                    <p style="color: var(--text-muted); font-size: 0.92rem;">
                        Your digital products store has been configured with the SQL database and is ready for business.
                    </p>

                    <div class="creds-box">
                        <div class="creds-row">
                            <span>Database:</span>
                            <strong id="resDriver">MySQL (InnoDB)</strong>
                        </div>
                        <div class="creds-row">
                            <span>Admin Login URL:</span>
                            <strong>/admin/login.php</strong>
                        </div>
                        <div class="creds-row">
                            <span>Admin Email:</span>
                            <strong id="resEmail">admin@gmail.com</strong>
                        </div>
                        <div class="creds-row">
                            <span>Admin Password:</span>
                            <strong id="resPass">••••••••</strong>
                        </div>
                    </div>

                    <div style="display: flex; gap: 14px; justify-content: center; flex-wrap: wrap;">
                        <a href="admin/login.php" class="btn btn-primary"><i class="fas fa-gauge-high"></i> Go to Admin Dashboard</a>
                        <a href="index.php" class="btn btn-secondary"><i class="fas fa-store"></i> View Storefront</a>
                    </div>
                </div>
            </section>

        <?php endif; ?>
    </div>

</div>

<script>
let currentDriver = 'mysql';

function selectDriver(driver) {
    currentDriver = driver;
    const mysqlPill = document.getElementById('driverMysqlLabel');
    const sqlitePill = document.getElementById('driverSqliteLabel');
    const mysqlFields = document.getElementById('mysqlFields');

    if (driver === 'mysql') {
        mysqlPill.classList.add('selected');
        sqlitePill.classList.remove('selected');
        mysqlFields.style.display = 'block';
    } else {
        sqlitePill.classList.add('selected');
        mysqlPill.classList.remove('selected');
        mysqlFields.style.display = 'none';
    }
}

function togglePw(id, btn) {
    const input = document.getElementById(id);
    if (input.type === 'password') {
        input.type = 'text';
        btn.innerHTML = '<i class="fas fa-eye-slash"></i>';
    } else {
        input.type = 'password';
        btn.innerHTML = '<i class="fas fa-eye"></i>';
    }
}

function goToStep1() {
    document.getElementById('section2').classList.remove('active');
    document.getElementById('section1').classList.add('active');
    document.getElementById('navStep2').classList.remove('active');
    document.getElementById('navStep1').classList.add('active');
}

function goToStep2() {
    document.getElementById('section1').classList.remove('active');
    document.getElementById('section2').classList.add('active');
    document.getElementById('navStep1').classList.remove('active');
    document.getElementById('navStep1').classList.add('completed');
    document.getElementById('navStep2').classList.add('active');
}

function testConnection() {
    const btn = document.getElementById('btnTestDb');
    const statusDiv = document.getElementById('dbStatus');
    btn.disabled = true;
    btn.innerHTML = '<i class="fas fa-circle-notch fa-spin"></i> Testing...';
    statusDiv.innerHTML = '';

    const formData = new FormData();
    formData.append('action', 'test_db');
    formData.append('db_driver', currentDriver);
    formData.append('db_host', document.getElementById('db_host').value.trim());
    formData.append('db_port', document.getElementById('db_port').value.trim());
    formData.append('db_name', document.getElementById('db_name').value.trim());
    formData.append('db_user', document.getElementById('db_user').value.trim());
    formData.append('db_pass', document.getElementById('db_pass').value);

    fetch('install.php', {
        method: 'POST',
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        btn.disabled = false;
        btn.innerHTML = '<i class="fas fa-plug-circle-check"></i> Test SQL Connection';
        if (data.success) {
            statusDiv.innerHTML = `<div class="alert-box alert-success"><i class="fas fa-check-circle"></i> ${data.message}</div>`;
        } else {
            statusDiv.innerHTML = `<div class="alert-box alert-error"><i class="fas fa-exclamation-triangle"></i> ${data.error}</div>`;
        }
    })
    .catch(err => {
        btn.disabled = false;
        btn.innerHTML = '<i class="fas fa-plug-circle-check"></i> Test SQL Connection';
        statusDiv.innerHTML = `<div class="alert-box alert-error"><i class="fas fa-exclamation-triangle"></i> Network or server error: ${err.message}</div>`;
    });
}

function runInstallation() {
    const btn = document.getElementById('btnInstall');
    const statusDiv = document.getElementById('installStatus');
    const adminEmail = document.getElementById('admin_email').value.trim();
    const adminPass = document.getElementById('admin_pass').value;

    if (!adminEmail || !adminPass) {
        statusDiv.innerHTML = `<div class="alert-box alert-error"><i class="fas fa-exclamation-circle"></i> Please enter Admin email and password.</div>`;
        return;
    }
    if (adminPass.length < 6) {
        statusDiv.innerHTML = `<div class="alert-box alert-error"><i class="fas fa-exclamation-circle"></i> Admin password must be at least 6 characters.</div>`;
        return;
    }

    btn.disabled = true;
    btn.innerHTML = '<i class="fas fa-circle-notch fa-spin"></i> Installing System...';
    statusDiv.innerHTML = '';

    const formData = new FormData();
    formData.append('action', 'do_install');
    formData.append('db_driver', currentDriver);
    formData.append('db_host', document.getElementById('db_host').value.trim());
    formData.append('db_port', document.getElementById('db_port').value.trim());
    formData.append('db_name', document.getElementById('db_name').value.trim());
    formData.append('db_user', document.getElementById('db_user').value.trim());
    formData.append('db_pass', document.getElementById('db_pass').value);

    formData.append('site_name', document.getElementById('site_name').value.trim());
    formData.append('site_tagline', document.getElementById('site_tagline').value.trim());
    formData.append('currency_symbol', document.getElementById('currency_symbol').value.trim());
    if (document.getElementById('auto_approve_orders').checked) {
        formData.append('auto_approve_orders', '1');
    }
    if (document.getElementById('sample_catalog').checked) {
        formData.append('sample_catalog', '1');
    }
    if (document.getElementById('clean_install').checked) {
        formData.append('clean_install', '1');
    }

    formData.append('admin_name', document.getElementById('admin_name').value.trim());
    formData.append('admin_email', adminEmail);
    formData.append('admin_pass', adminPass);

    fetch('install.php', {
        method: 'POST',
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        btn.disabled = false;
        btn.innerHTML = '<i class="fas fa-bolt"></i> Complete Installation';

        if (data.success) {
            document.getElementById('resEmail').innerText = data.admin_email;
            document.getElementById('resPass').innerText = data.admin_pass;
            document.getElementById('resDriver').innerText = data.driver === 'mysql' ? 'MySQL / MariaDB' : 'SQLite 3';

            document.getElementById('section2').classList.remove('active');
            document.getElementById('section3').classList.add('active');

            document.getElementById('navStep2').classList.remove('active');
            document.getElementById('navStep2').classList.add('completed');
            document.getElementById('navStep3').classList.add('active');
        } else {
            statusDiv.innerHTML = `<div class="alert-box alert-error"><i class="fas fa-exclamation-triangle"></i> Installation Failed: ${data.error}</div>`;
        }
    })
    .catch(err => {
        btn.disabled = false;
        btn.innerHTML = '<i class="fas fa-bolt"></i> Complete Installation';
        statusDiv.innerHTML = `<div class="alert-box alert-error"><i class="fas fa-exclamation-triangle"></i> Server Error: ${err.message}</div>`;
    });
}
</script>
</body>
</html>
