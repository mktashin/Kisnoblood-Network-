<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include 'config.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$order_id = (int)($_GET['order_id'] ?? 0);
if ($order_id < 1) {
    header('Location: orders.php');
    exit();
}

$stmt = $pdo->prepare("SELECT orders.*, users.name AS customer_name, users.email AS customer_email, users.whatsapp, products.title AS product_title, products.product_type, products.file_path, products.drive_link 
                      FROM orders 
                      JOIN users ON orders.user_id = users.id 
                      JOIN products ON orders.product_id = products.id 
                      WHERE orders.id = ? AND orders.user_id = ? LIMIT 1");
$stmt->execute([$order_id, $_SESSION['user_id']]);
$order = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$order) {
    http_response_code(404);
    exit('Invoice not found.');
}

$invoice_no = 'JHX-' . str_pad((string)$order['id'], 6, '0', STR_PAD_LEFT);
$customer_name = $order['customer_name'] ?: 'Customer';
$site_name = $set['site_name'] ?? 'JHX Digital Shop';
$site_desc = $set['meta_desc'] ?? 'Premium digital subscriptions with secure manual payment verification.';
$status_class = strtolower($order['status']) === 'completed' ? 'success' : (strtolower($order['status']) === 'rejected' ? 'danger' : 'pending');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Invoice <?= htmlspecialchars($invoice_no) ?> | <?= htmlspecialchars($site_name) ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="assets/css/jx-toast.css">
    <style>
        :root { --navy:#0f172a; --blue:#2563eb; --indigo:#4338ca; --muted:#64748b; --line:#e2e8f0; --soft:#f8fafc; }
        * { box-sizing:border-box; }
        body { margin:0; min-height:100vh; background:linear-gradient(135deg,#f8fbff 0%,#eef2ff 55%,#fff 100%); color:var(--navy); font-family:Inter,system-ui,sans-serif; }
        .invoice-wrap { width:min(100%,920px); margin:0 auto; padding:clamp(16px,4vw,42px) clamp(12px,3vw,28px) 50px; }
        .invoice-toolbar { display:flex; justify-content:space-between; align-items:center; gap:12px; margin-bottom:18px; }
        .back-link { color:var(--muted); text-decoration:none; font-size:.8rem; font-weight:800; }
        .back-link:hover { color:var(--blue); }
        .toolbar-actions { display:flex; gap:8px; flex-wrap:wrap; justify-content:flex-end; }
        .toolbar-btn { display:inline-flex; align-items:center; justify-content:center; gap:8px; min-height:40px; padding:10px 15px; border:1px solid var(--line); border-radius:10px; color:var(--navy); background:#fff; text-decoration:none; font-size:.75rem; font-weight:800; cursor:pointer; transition:.2s ease; }
        .toolbar-btn:hover { transform:translateY(-1px); border-color:#bfdbfe; box-shadow:0 7px 18px rgba(37,99,235,.1); }
        .toolbar-btn.primary { border-color:transparent; color:#fff; background:linear-gradient(135deg,var(--blue),var(--indigo)); }
        .invoice-card { overflow:hidden; border:1px solid #dbeafe; border-radius:24px; background:#fff; box-shadow:0 18px 50px rgba(30,42,184,.1); }
        .invoice-top { position:relative; padding:clamp(22px,5vw,42px); background:linear-gradient(135deg,#eff6ff 0%,#eef2ff 62%,#fff 100%); border-bottom:1px solid var(--line); }
        .invoice-top::after { content:""; position:absolute; width:230px; height:230px; border-radius:50%; right:-90px; top:-130px; background:#dbeafe; opacity:.6; }
        .brand-row { position:relative; z-index:1; display:flex; justify-content:space-between; align-items:flex-start; gap:22px; }
        .brand-name { margin:0; color:var(--navy); font-size:clamp(1.25rem,3vw,1.75rem); font-weight:900; letter-spacing:-.6px; }
        .brand-tagline { max-width:360px; margin:7px 0 0; color:var(--muted); font-size:.78rem; font-weight:600; line-height:1.5; }
        .invoice-label { position:relative; z-index:1; text-align:right; }
        .invoice-label p { margin:0; color:var(--muted); font-size:.68rem; font-weight:800; letter-spacing:1.1px; text-transform:uppercase; }
        .invoice-label strong { display:block; margin-top:5px; color:var(--blue); font-size:1.05rem; font-weight:900; }
        .invoice-body { padding:clamp(22px,5vw,42px); }
        .receipt-status { display:flex; align-items:center; justify-content:space-between; gap:14px; margin-bottom:28px; padding:14px 16px; border:1px solid #c7d2fe; border-radius:14px; background:#f8fbff; }
        .receipt-status-copy { color:var(--muted); font-size:.75rem; font-weight:700; line-height:1.45; }
        .receipt-status-copy strong { display:block; color:var(--navy); font-size:.9rem; }
        .status-pill { display:inline-flex; align-items:center; gap:7px; padding:8px 12px; border-radius:999px; font-size:.68rem; font-weight:900; letter-spacing:.4px; text-transform:uppercase; white-space:nowrap; }
        .status-pill.pending { color:#b45309; background:#fffbeb; border:1px solid #fde68a; }
        .status-pill.success { color:#047857; background:#ecfdf5; border:1px solid #bbf7d0; }
        .status-pill.danger { color:#b91c1c; background:#fef2f2; border:1px solid #fecaca; }
        .detail-grid { display:grid; grid-template-columns:repeat(2,minmax(0,1fr)); gap:16px; margin-bottom:28px; }
        .detail-box { padding:15px 16px; border:1px solid var(--line); border-radius:14px; background:#fff; }
        .detail-box span { display:block; margin-bottom:6px; color:var(--muted); font-size:.66rem; font-weight:800; letter-spacing:.65px; text-transform:uppercase; }
        .detail-box strong { display:block; overflow-wrap:anywhere; color:var(--navy); font-size:.86rem; font-weight:800; }
        .section-title { display:flex; align-items:center; gap:8px; margin:0 0 12px; color:var(--navy); font-size:.76rem; font-weight:900; letter-spacing:.65px; text-transform:uppercase; }
        .section-title i { color:var(--blue); }
        .line-items { border:1px solid var(--line); border-radius:16px; overflow:hidden; }
        .line-row { display:grid; grid-template-columns:minmax(0,1fr) auto; gap:16px; align-items:center; padding:17px 18px; border-bottom:1px solid var(--line); }
        .line-row:last-child { border-bottom:0; }
        .line-row span { color:var(--muted); font-size:.78rem; font-weight:700; }
        .line-row strong { color:var(--navy); font-size:.9rem; font-weight:900; text-align:right; }
        .line-row.total { background:#f8fbff; }
        .line-row.total span { color:var(--navy); font-size:.85rem; font-weight:900; }
        .line-row.total strong { color:var(--blue); font-size:1.18rem; }
        .invoice-foot { display:flex; justify-content:space-between; gap:20px; margin-top:28px; padding-top:20px; border-top:1px dashed #cbd5e1; color:var(--muted); font-size:.72rem; font-weight:600; line-height:1.55; }
        .invoice-foot strong { color:var(--navy); }
        @media (max-width:600px) { .invoice-toolbar,.brand-row,.receipt-status,.invoice-foot { align-items:flex-start; flex-direction:column; } .invoice-label { text-align:left; } .toolbar-actions { width:100%; justify-content:stretch; } .toolbar-btn { flex:1; } .detail-grid { grid-template-columns:1fr; } .invoice-card { border-radius:18px; } }
        @media print { body { background:#fff; } .invoice-wrap { width:100%; max-width:none; padding:0; } .invoice-toolbar { display:none; } .invoice-card { border:0; border-radius:0; box-shadow:none; } .invoice-top { padding:24px 0; } .invoice-body { padding:24px 0; } .invoice-top::after { display:none; } }
    </style>
</head>
<body>
<div class="invoice-wrap">
    <div class="invoice-toolbar">
        <a class="back-link" href="orders.php"><i class="fa-solid fa-arrow-left me-1"></i> Back to Orders</a>
        <div class="toolbar-actions">
            <button class="toolbar-btn primary" type="button" onclick="window.print()"><i class="fa-solid fa-print"></i> Print Invoice</button>
            <a class="toolbar-btn" href="index.php"><i class="fa-solid fa-store"></i> Continue Shopping</a>
        </div>
    </div>

    <article class="invoice-card">
        <header class="invoice-top">
            <div class="brand-row">
                <div>
                    <h1 class="brand-name"><?= htmlspecialchars($site_name) ?></h1>
                    <p class="brand-tagline"><?= htmlspecialchars($site_desc) ?></p>
                </div>
                <div class="invoice-label"><p>Payment Receipt</p><strong><?= htmlspecialchars($invoice_no) ?></strong></div>
            </div>
        </header>

        <div class="invoice-body">
            <?php if($order['status'] === 'Completed'): ?>
                <div style="background: linear-gradient(135deg, #059669 0%, #10b981 100%); border-radius: 18px; padding: 22px 24px; color: #fff; margin-bottom: 24px; display: flex; align-items: center; justify-content: space-between; gap: 16px; flex-wrap: wrap; box-shadow: 0 10px 25px rgba(5, 150, 105, 0.2);">
                    <div>
                        <h3 style="margin: 0 0 4px; font-size: 1.15rem; font-weight: 900;"><i class="fa-solid fa-circle-check me-2"></i> Order Active & Verified!</h3>
                        <p style="margin: 0; font-size: 0.85rem; opacity: 0.95;">Your payment has been processed and your digital delivery is ready.</p>
                    </div>
                    <?php if(!empty($order['file_path']) || $order['product_type'] === 'downloadable'): ?>
                        <a href="download.php?order_id=<?= (int)$order['id'] ?>" style="background: #fff; color: #065f46; font-weight: 900; font-size: 0.88rem; text-decoration: none; padding: 12px 24px; border-radius: 12px; display: inline-flex; align-items: center; gap: 8px; box-shadow: 0 4px 14px rgba(0,0,0,0.12);">
                            <i class="fa-solid fa-cloud-arrow-down fs-5"></i> Download Product (.ZIP)
                        </a>
                    <?php elseif(!empty($order['drive_link'])): ?>
                        <a href="<?= htmlspecialchars($order['drive_link']) ?>" target="_blank" style="background: #fff; color: #0284c7; font-weight: 900; font-size: 0.88rem; text-decoration: none; padding: 12px 24px; border-radius: 12px; display: inline-flex; align-items: center; gap: 8px;">
                            <i class="fa-solid fa-external-link me-1"></i> Access Drive Link
                        </a>
                    <?php endif; ?>
                </div>
            <?php elseif($order['status'] === 'Pending'): ?>
                <div style="background: #fffbeb; border: 1px solid #fde68a; border-radius: 14px; padding: 16px 20px; color: #92400e; margin-bottom: 24px; display: flex; align-items: center; gap: 14px;">
                    <i class="fa-solid fa-spinner fa-spin fs-4" style="color: #d97706;"></i>
                    <div style="font-size: 0.88rem; line-height: 1.4;">
                        <strong>Payment Under Verification</strong><br>
                        We are verifying your Transaction ID. Once approved by admin, your order becomes active and the download button will appear here.
                    </div>
                </div>
            <?php endif; ?>

            <div class="receipt-status">
                <div class="receipt-status-copy"><strong>Payment Details Recorded</strong>Status updated in real-time.</div>
                <span class="status-pill <?= htmlspecialchars($status_class) ?>"><i class="fa-solid fa-circle"></i> <?= htmlspecialchars($order['status']) ?></span>
            </div>

            <div class="detail-grid">
                <div class="detail-box"><span>Customer</span><strong><?= htmlspecialchars($customer_name) ?></strong></div>
                <div class="detail-box"><span>Invoice date</span><strong><?= date('d M Y, h:i A', strtotime($order['created_at'])) ?></strong></div>
                <div class="detail-box"><span>Email</span><strong><?= htmlspecialchars($order['customer_email']) ?></strong></div>
                <div class="detail-box"><span>Payment method</span><strong><?= htmlspecialchars(($order['payment_method'] ?? '') === 'HostNekoPay' ? 'HostNekoPay (Auto Pay)' : 'Manual Payment') ?></strong></div>
            </div>

            <h2 class="section-title"><i class="fa-solid fa-receipt"></i> Order summary</h2>
            <div class="line-items">
                <div class="line-row"><span>Product</span><strong><?= htmlspecialchars($order['product_title']) ?></strong></div>
                <div class="line-row"><span>Delivery type</span><strong>Digital subscription</strong></div>
                <?php if (!empty($order['sub_email'])): ?>
                    <div class="line-row"><span>Activation email</span><strong><?= htmlspecialchars($order['sub_email']) ?></strong></div>
                <?php endif; ?>
                <div class="line-row"><span>Transaction ID</span><strong><?= htmlspecialchars($order['trx_id']) ?></strong></div>
                <div class="line-row"><span>Sender number</span><strong><?= htmlspecialchars($order['sender_number']) ?></strong></div>
                <div class="line-row total"><span>Total paid</span><strong>৳<?= number_format((float)$order['amount'], 2) ?></strong></div>
            </div>

            <div class="invoice-foot">
                <div><strong>Next step:</strong> Our team will verify the Transaction ID and update your order status.</div>
                <div><strong>Support:</strong> Contact us through the live WhatsApp support on the website.</div>
            </div>
        </div>
    </article>
</div>
<script src="assets/js/jx-toast.js"></script>
</body>
</html>
