<?php 
// সেশন শুরু করা নিশ্চিত করা হলো
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include 'config.php'; 

// ইউজার লগইন না থাকলে সরাসরি login.php তে রিডাইরেক্ট করবে (অবশ্যই header.php ইনক্লুড করার আগে হতে হবে)
if (!isset($_SESSION['user_id'])) { 
    header("Location: login.php"); 
    exit(); 
}

include 'header.php';

$user_id = $_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT orders.*, products.title, products.drive_link, products.file_path, products.product_type 
                       FROM orders 
                       JOIN products ON orders.product_id = products.id 
                       WHERE orders.user_id = ? ORDER BY orders.id DESC");
$stmt->execute([$user_id]);
$orders = $stmt->fetchAll();
?>

<!-- ====== ফন্ট: Inter ====== -->
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

<style>
    /* =========================================
       ✅ ORDERS PAGE UPDATED: 11 August 2026
       📌 Exact Match with Previous Blue Theme
       🔧 কালার পরিবর্তন: সবুজ → নীল (#1e2ab8)
    ========================================= */
    
    :root {
        --primary-blue: #1e2ab8;
        --primary-gradient: linear-gradient(135deg, #1e2ab8 0%, #4338ca 100%);
        --primary-hover: #0f172a;
        --primary-light: #e0e7ff;
        --border-color: #e2e8f0;
        --dark-bg: #0f172a;
        --text-slate: #64748b;
        --light-bg: #f8fafc;
        --card-bg: #ffffff;
        --success-green: #059669;
        --warning-orange: #d97706;
        --danger-red: #dc2626;
    }

    /* ডার্ক মোড অটো */
    @media (prefers-color-scheme: dark) {
        :root {
            --card-bg: #1e293b;
            --light-bg: #0f172a;
            --dark-bg: #e2e8f0;
            --text-slate: #94a3b8;
            --border-color: #334155;
        }
        body { background-color: #0f172a; }
        .order-card { background: #1e293b; border-color: #334155; }
        .order-info h6 { color: #e2e8f0; }
        .order-meta-item { color: #94a3b8; }
        .trx-id { background: #0f172a; color: #94a3b8; border-color: #334155; }
        .dashboard-title { color: #e2e8f0; }
        .dashboard-title i { background: #1e293b; color: #60a5fa; }
        .sub-info { background: #0f172a; color: #34d399; border-color: #334155; }
        .badge-completed { background: #0f172a; color: #34d399; border-color: #334155; }
        .badge-pending { background: #0f172a; color: #fbbf24; border-color: #334155; }
        .badge-rejected { background: #0f172a; color: #f87171; border-color: #334155; }
        .alert-success { background: #0f172a; border-color: #334155; color: #34d399; }
    }

    * { font-style: normal !important; }

    body {
        font-family: 'Inter', sans-serif;
        background-color: var(--light-bg);
        color: var(--dark-bg);
    }

    .orders-shell {
        width: min(100%, 1080px);
        margin: 0 auto;
    }

    .orders-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 18px;
        margin-bottom: 22px;
        padding: clamp(18px, 3vw, 28px);
        border: 1px solid #dbeafe;
        border-radius: 22px;
        background: linear-gradient(135deg, #ffffff 0%, #f5f8ff 68%, #eef2ff 100%);
        box-shadow: 0 12px 30px rgba(30, 42, 184, .07);
    }

    .orders-header-copy { min-width: 0; }
    .orders-eyebrow {
        margin: 0 0 7px;
        color: var(--primary-blue);
        font-size: .68rem;
        font-weight: 900;
        letter-spacing: 1.3px;
        text-transform: uppercase;
    }
    .orders-subtitle {
        margin: 0;
        color: var(--text-slate);
        font-size: .86rem;
        font-weight: 600;
        line-height: 1.5;
    }
    .orders-count {
        flex: 0 0 auto;
        min-width: 88px;
        padding: 13px 16px;
        border: 1px solid #c7d2fe;
        border-radius: 16px;
        background: rgba(255,255,255,.82);
        text-align: center;
    }
    .orders-count strong { display:block; color: var(--primary-blue); font-size: 1.45rem; line-height: 1; font-weight: 900; }
    .orders-count span { display:block; margin-top: 5px; color: var(--text-slate); font-size: .64rem; font-weight: 800; letter-spacing: .7px; text-transform: uppercase; }

    /* ====== ড্যাশবোর্ড টাইটেল ====== */
    .dashboard-title {
        font-weight: 900;
        color: var(--dark-bg);
        margin-bottom: 20px;
        display: flex;
        align-items: center;
        gap: 12px;
        font-size: 1.3rem;
        text-transform: uppercase;
        letter-spacing: -0.5px;
    }

    @media(min-width: 768px) { 
        .dashboard-title { 
            font-size: 1.6rem; 
            margin-bottom: 30px; 
        } 
    }
    
    .dashboard-title i {
        color: var(--primary-blue);
        background: var(--primary-light);
        padding: 10px;
        border-radius: 12px;
        font-size: 1.1rem;
    }

    /* ====== অর্ডার কার্ড ====== */
    .order-card {
        background: var(--card-bg);
        border-radius: 14px;
        border: 1px solid var(--border-color);
        padding: 16px;
        display: flex;
        flex-direction: column;
        gap: 15px;
        transition: all 0.3s ease;
        box-shadow: 0 1px 2px rgba(0,0,0,0.02);
    }

    .order-card:hover {
        border-color: var(--primary-blue);
        box-shadow: 0 4px 20px rgba(30, 42, 184, 0.06);
    }

    @media(min-width: 768px) {
        .order-card {
            border-radius: 18px;
            padding: 24px;
            flex-direction: row;
            justify-content: space-between;
            align-items: center;
        }
    }

    /* ====== অর্ডার ইনফো ====== */
    .order-info h6 {
        font-weight: 700;
        color: var(--dark-bg);
        font-size: 0.98rem;
        margin-bottom: 6px;
        line-height: 1.4;
        transition: color 0.2s ease;
    }

    .order-card:hover .order-info h6 {
        color: var(--primary-blue);
    }

    @media(min-width: 768px) { 
        .order-info h6 { 
            font-size: 1.1rem; 
        } 
    }

    /* ====== ট্রানজেকশন আইডি ====== */
    .trx-id {
        background: var(--light-bg);
        padding: 4px 12px;
        border-radius: 8px;
        font-family: monospace;
        color: var(--text-slate);
        font-size: 0.75rem;
        font-weight: 700;
        border: 1px solid var(--border-color);
        letter-spacing: 0.3px;
    }

    /* ====== মেটা আইটেম ====== */
    .order-meta-item { 
        color: var(--text-slate); 
        font-size: 0.78rem;
        font-weight: 600;
    }

    .order-meta-item i {
        margin-right: 4px;
        color: var(--primary-blue);
    }

    /* ====== স্ট্যাটাস ব্যাজ ====== */
    .status-badge {
        padding: 5px 14px;
        border-radius: 30px;
        font-size: 0.7rem;
        font-weight: 900;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        display: inline-flex;
        align-items: center;
        gap: 6px;
    }

    .badge-completed { 
        background: #ecfdf5; 
        color: var(--success-green); 
        border: 1px solid rgba(5, 150, 105, 0.15); 
    }
    .badge-pending { 
        background: #fffbeb; 
        color: var(--warning-orange); 
        border: 1px solid rgba(217, 119, 6, 0.15); 
    }
    .badge-rejected { 
        background: #fef2f2; 
        color: var(--danger-red); 
        border: 1px solid rgba(220, 38, 38, 0.15); 
    }

    /* ====== ডাউনলোড বাটন (নীল থিম) ====== */
    .btn-download {
        background: var(--primary-gradient);
        color: white !important;
        border: none;
        padding: 10px 20px;
        border-radius: 12px;
        font-weight: 900;
        font-size: 0.78rem;
        text-decoration: none;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        width: 100%;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        box-shadow: 0 4px 15px rgba(30, 42, 184, 0.15);
        transition: all 0.3s ease;
    }

    .btn-download:hover {
        background: var(--primary-hover);
        transform: translateY(-2px);
        box-shadow: 0 8px 30px rgba(30, 42, 184, 0.25);
        color: white !important;
    }

    @media(min-width: 768px) { 
        .btn-download { 
            width: auto; 
            padding: 12px 28px; 
        } 
    }

    /* ====== সাবস্ক্রিপশন ইনফো ====== */
    .sub-info {
        background: var(--primary-light);
        color: var(--primary-blue);
        padding: 10px 18px;
        border-radius: 12px;
        font-size: 0.8rem;
        font-weight: 700;
        border: 1px solid rgba(30, 42, 184, 0.15);
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        width: 100%;
        text-transform: uppercase;
        letter-spacing: 0.3px;
    }

    .sub-info i {
        color: var(--primary-blue);
    }

    @media(min-width: 768px) { 
        .sub-info { 
            width: auto; 
            padding: 12px 24px;
        } 
    }

    /* ====== অ্যাকশন এরিয়া ====== */
    .action-area { 
        width: 100%; 
        display: flex;
        flex-direction: column;
        gap: 8px;
    }

    .action-area .text-warning {
        color: var(--warning-orange) !important;
        font-weight: 700;
        font-size: 0.8rem;
        text-transform: uppercase;
        letter-spacing: 0.3px;
    }

    .action-area .text-danger {
        color: var(--danger-red) !important;
        font-weight: 700;
        font-size: 0.8rem;
        text-transform: uppercase;
        letter-spacing: 0.3px;
    }

    @media(min-width: 768px) { 
        .action-area { 
            width: auto; 
            text-align: right;
            flex-direction: row;
            align-items: center;
        } 
    }

    /* ====== অ্যালার্ট ====== */
    .alert-success-custom {
        background: var(--primary-light);
        border: 1px solid rgba(30, 42, 184, 0.15);
        color: var(--primary-blue);
        border-radius: 14px;
        padding: 14px 18px;
        font-weight: 700;
        display: flex;
        align-items: center;
        gap: 10px;
        font-size: 0.85rem;
    }

    .alert-success-custom i {
        font-size: 1.1rem;
    }

    /* ====== খালি অর্ডার ====== */
    .empty-orders {
        position: relative;
        overflow: hidden;
        background: linear-gradient(180deg, #ffffff 0%, #f8fbff 100%);
        border: 1px solid #dbeafe;
        border-radius: 22px;
        padding: clamp(34px, 7vw, 68px) 20px;
        text-align: center;
        box-shadow: 0 12px 30px rgba(30, 42, 184, .06);
    }
    .empty-orders::before,
    .empty-orders::after {
        content: "";
        position: absolute;
        width: 170px;
        height: 170px;
        border-radius: 50%;
        background: #dbeafe;
        opacity: .42;
        filter: blur(2px);
        pointer-events: none;
    }
    .empty-orders::before { top: -92px; left: -72px; }
    .empty-orders::after { right: -70px; bottom: -108px; background: #e0e7ff; }
    .empty-icon-wrap {
        position: relative;
        z-index: 1;
        width: 74px;
        height: 74px;
        display: grid;
        place-items: center;
        margin: 0 auto 18px;
        border-radius: 24px;
        color: var(--primary-blue);
        background: linear-gradient(135deg, #eff6ff, #e0e7ff);
        border: 1px solid #c7d2fe;
        box-shadow: 0 10px 22px rgba(37, 99, 235, .12);
    }
    .empty-icon-wrap i { color: var(--primary-blue); font-size: 2rem; margin: 0; opacity: 1; }
    .empty-orders h5 { position: relative; z-index: 1; margin-bottom: 8px; font-weight: 900; color: var(--dark-bg); letter-spacing: .8px; font-size: 1.2rem; }
    .empty-orders p { position: relative; z-index: 1; max-width: 420px; margin: 0 auto 22px; color: var(--text-slate); font-size: .92rem; font-weight: 600; line-height: 1.6; }
    .empty-note { position: relative; z-index: 1; margin: 17px 0 0; color: #94a3b8; font-size: .7rem; font-weight: 700; }


    .invoice-link {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        margin-top: 10px;
        color: var(--primary-blue);
        font-size: .72rem;
        font-weight: 800;
        text-decoration: none;
    }
    .invoice-link:hover { color: var(--primary-hover); text-decoration: underline; }

    .btn-shop {
        position: relative;
        z-index: 1;
        background: var(--primary-gradient);
        color: #fff !important;
        border: none;
        padding: 13px 28px;
        border-radius: 14px;
        font-weight: 900;
        font-size: 0.8rem;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        text-decoration: none;
        display: inline-block;
        box-shadow: 0 4px 15px rgba(30, 42, 184, 0.15);
        transition: all 0.3s ease;
    }

    .btn-shop:hover {
        background: var(--primary-hover);
        transform: translateY(-2px);
        box-shadow: 0 8px 30px rgba(30, 42, 184, 0.25);
        color: #fff !important;
    }

    /* ====== রেসপনসিভ ====== */
    @media (max-width: 768px) {
        .orders-header { align-items: flex-start; border-radius: 18px; }
        .orders-subtitle { font-size: .78rem; }
        .orders-count { min-width: 76px; padding: 11px 12px; }
        .dashboard-title { font-size: 1.1rem; gap: 8px; }
        .dashboard-title i { padding: 8px; font-size: 0.9rem; }
        .order-info h6 { font-size: 0.85rem; }
        .trx-id { font-size: 0.7rem; }
        .order-meta-item { font-size: 0.7rem; }
        .status-badge { font-size: 0.6rem; padding: 3px 10px; }
        .btn-download { font-size: 0.7rem; padding: 8px 14px; }
        .sub-info { font-size: 0.7rem; padding: 8px 14px; }
        .empty-orders { padding: 30px 16px; }
        .empty-orders h5 { font-size: 0.95rem; }
    }

    @media (max-width: 480px) {
        .order-card { padding: 12px; border-radius: 12px; gap: 12px; }
        .order-info h6 { font-size: 0.8rem; }
        .dashboard-title { font-size: 0.95rem; }
        .dashboard-title i { padding: 6px; font-size: 0.8rem; border-radius: 8px; }
        .action-area { gap: 6px; }
    }
</style>

<div class="container py-2 py-md-4">
    <div class="orders-shell">
        <div class="orders-header animate__animated animate__fadeIn">
            <div class="orders-header-copy">
                <p class="orders-eyebrow">Account overview</p>
                <h3 class="dashboard-title mb-2">
                    <i class="fa-solid fa-box-open"></i> My Orders
                </h3>
                <p class="orders-subtitle">Track your manual payment verification and digital subscription delivery in one place.</p>
            </div>
            <div class="orders-count" aria-label="Total orders">
                <strong><?= count($orders) ?></strong>
                <span><?= count($orders) === 1 ? 'Order' : 'Orders' ?></span>
            </div>
        </div>

    <!-- ====== সাকসেস অ্যালার্ট ====== -->
    <?php if(isset($_GET['manual']) && $_GET['manual'] === 'submitted'): ?>
        <div class="alert-success-custom animate__animated animate__fadeInDown mb-3">
            <i class="fa-solid fa-circle-check"></i> Your manual payment has been submitted! We'll verify and approve it shortly.
        </div>
        <script>document.addEventListener('DOMContentLoaded', function(){ if (typeof jxConfetti === 'function') jxConfetti(); });</script>
    <?php endif; ?>

    <?php if(isset($_GET['paid']) && $_GET['paid'] === '1'): ?>
        <div class="alert-success-custom animate__animated animate__fadeInDown mb-3">
            <i class="fa-solid fa-circle-check"></i> Payment received! Your order is now being processed.
        </div>
        <script>document.addEventListener('DOMContentLoaded', function(){ if (typeof jxConfetti === 'function') jxConfetti(); });</script>
    <?php endif; ?>

    <!-- ====== অর্ডার লিস্ট ====== -->
    <?php if(count($orders) > 0): ?>
        <?php foreach($orders as $o): ?>
            <div class="order-card mb-3 animate__animated animate__fadeInUp">
                
                <div class="order-info">
                    <h6><?= htmlspecialchars($o['title']) ?></h6>
                    <div class="d-flex flex-wrap gap-2 align-items-center mb-2">
                        <span class="trx-id"><i class="fa-regular fa-receipt me-1"></i> <?= htmlspecialchars($o['trx_id']) ?></span>
                        <span class="order-meta-item"><i class="fa-regular fa-calendar-days"></i> <?= date('d M, Y', strtotime($o['created_at'])) ?></span>
                        <?php if(($o['payment_method'] ?? '') === 'HostNekoPay'): ?>
                            <span class="order-meta-item" style="color:#2563eb;"><i class="fa-solid fa-bolt text-warning"></i> Auto Pay (HostNekoPay)</span>
                        <?php else: ?>
                            <span class="order-meta-item" style="color:#b45309;"><i class="fa-solid fa-mobile-screen-button"></i> Manual Payment</span>
                        <?php endif; ?>
                    </div>
                    <div>
                        <?php 
                            $statusClass = 'pending'; $statusIcon = 'fa-spinner fa-spin';
                            if($o['status'] == 'Completed') { $statusClass = 'completed'; $statusIcon = 'fa-circle-check'; }
                            if($o['status'] == 'Rejected') { $statusClass = 'rejected'; $statusIcon = 'fa-circle-xmark'; }
                        ?>
                        <span class="status-badge badge-<?= $statusClass ?>">
                            <i class="fa-solid <?= $statusIcon ?>"></i> <?= htmlspecialchars($o['status']) ?>
                        </span>
                        <div><a class="invoice-link" href="invoice.php?order_id=<?= (int)$o['id'] ?>"><i class="fa-solid fa-file-invoice"></i> View Invoice</a></div>
                    </div>
                </div>

                <div class="action-area">
                    <?php if($o['status'] == 'Completed'): ?>
                        <?php if(!empty($o['file_path']) || !empty($o['drive_link']) || $o['product_type'] == 'downloadable'): ?>
                            <a href="download.php?order_id=<?= (int)$o['id'] ?>" class="btn-download">
                                <i class="fa-solid fa-cloud-arrow-down"></i> <?= (!empty($o['drive_link']) && empty($o['file_path'])) ? 'Access Download' : 'Download ZIP' ?>
                            </a>
                        <?php endif; ?>
                        <?php if(!empty($o['sub_email'])): ?>
                            <div class="sub-info">
                                <i class="fa-solid fa-circle-check"></i> Active: <?= htmlspecialchars($o['sub_email']) ?>
                            </div>
                        <?php endif; ?>
                    <?php elseif($o['status'] == 'Pending'): ?>
                        <span class="text-warning fw-semibold" style="font-size:0.85rem;"><i class="fa-solid fa-clock me-1"></i> Verifying Payment...</span>
                    <?php else: ?>
                        <span class="text-danger fw-semibold" style="font-size:0.85rem;"><i class="fa-solid fa-circle-exclamation me-1"></i> <?= htmlspecialchars($o['status']) ?></span>
                    <?php endif; ?>
                </div>
                
            </div>
        <?php endforeach; ?>
        
    <?php else: ?>
        <!-- ====== খালি অর্ডার ====== -->
        <div class="empty-orders animate__animated animate__fadeIn">
            <div class="empty-icon-wrap"><i class="fa-solid fa-basket-shopping"></i></div>
            <h5>No Orders Yet</h5>
            <p>Your order space is ready. Browse our premium digital subscriptions and your verified purchases will appear here.</p>
            <a href="index.php" class="btn-shop">
                <i class="fa-solid fa-cart-shopping me-2"></i> Explore Products
            </a>
            <p class="empty-note"><i class="fa-solid fa-shield-halved me-1"></i> Secure manual verification on every order</p>
        </div>
    <?php endif; ?>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<?php include 'footer.php'; ?>