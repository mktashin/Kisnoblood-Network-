<?php
/**
 * End-to-End Verification Test Script
 * Verifies:
 * 1. DB connection & config loading
 * 2. Settings table and new fields (auto_approve_orders, upay_number, etc.)
 * 3. Admin user presence (role = 'admin')
 * 4. Product creation with download ZIP file path
 * 5. User creation & order placement with manual payment
 * 6. Instant / 1-click order activation
 * 7. Secure ZIP download validation
 */

error_reporting(E_ALL);
ini_set('display_errors', '1');

echo "=== STARTING E2E VERIFICATION ===\n";

// 1. Load config
require_once __DIR__ . '/../config.php';

if (!isset($pdo) || !$pdo) {
    die("[FAIL] PDO connection not initialized.\n");
}
echo "[PASS] Database connection initialized successfully. Driver: " . (defined('DB_DRIVER') ? DB_DRIVER : 'unknown') . "\n";

// Verify root db_config.php
$root_cfg_file = __DIR__ . '/../db_config.php';
if (file_exists($root_cfg_file)) {
    $cfg = require $root_cfg_file;
    if (is_array($cfg) && isset($cfg['driver'])) {
        echo "[PASS] Root db_config.php detected and valid. Driver: {$cfg['driver']}, Host: " . ($cfg['host'] ?? 'N/A') . "\n";
    } else {
        echo "[FAIL] Root db_config.php format invalid.\n";
    }
} else {
    echo "[FAIL] Root db_config.php not found.\n";
}

// 2. Verify settings
$settings = $pdo->query("SELECT * FROM settings WHERE id = 1 LIMIT 1")->fetch(PDO::FETCH_ASSOC) ?: [];
$required_keys = ['site_name', 'auto_approve_orders', 'currency_symbol', 'bkash_number', 'nagad_number', 'rocket_number', 'upay_number', 'whatsapp_number', 'enable_manual_payment', 'enable_auto_payment', 'hostneko_api_key'];
$missing_keys = [];
foreach ($required_keys as $key) {
    if (!array_key_exists($key, $settings)) {
        $missing_keys[] = $key;
    }
}
if (!empty($missing_keys)) {
    echo "[FAIL] Missing settings keys: " . implode(', ', $missing_keys) . "\n";
} else {
    echo "[PASS] All required settings keys present in database (including HostNekoPay & Payment Toggles).\n";
}

// 3. Verify Admin user exists
$admin_count = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE role = 'admin'")->fetchColumn();
echo "[PASS] Admin user count: $admin_count\n";

// 4. Test Product creation with ZIP file
$downloads_dir = defined('JHX_PRIVATE_DOWNLOAD_DIR') ? JHX_PRIVATE_DOWNLOAD_DIR : __DIR__ . '/downloads';
if (!is_dir($downloads_dir)) {
    mkdir($downloads_dir, 0700, true);
}

// Create a dummy test zip file
$test_zip_filename = 'digital_asset_test_' . time() . '.zip';
$test_zip_path = $downloads_dir . '/' . $test_zip_filename;

$zip = new ZipArchive();
if ($zip->open($test_zip_path, ZipArchive::CREATE | ZipArchive::OVERWRITE) === TRUE) {
    $zip->addFromString('license.txt', 'Commercial License Granted to buyer.');
    $zip->addFromString('main.js', 'console.log("Digital Product Active!");');
    $zip->close();
    echo "[PASS] Test ZIP package created at: $test_zip_path (" . filesize($test_zip_path) . " bytes)\n";
} else {
    die("[FAIL] Failed to create test ZIP file.\n");
}

// Ensure at least one category exists
$cat_id = $pdo->query("SELECT id FROM categories LIMIT 1")->fetchColumn();
if (!$cat_id) {
    $pdo->prepare("INSERT INTO categories (name) VALUES (?)")->execute(['Software & Scripts']);
    $cat_id = $pdo->lastInsertId();
}

// Insert product with file_path pointing to private_downloads/test_zip_filename
$db_file_rel = 'private_downloads/' . $test_zip_filename;
$stmt = $pdo->prepare("INSERT INTO products (category_id, title, product_type, regular_price, offer_price, stock, file_path, description, image) VALUES (?, ?, 'downloadable', ?, ?, 99, ?, ?, 'uploads/sample.png')");
$stmt->execute([$cat_id, 'Ultra Theme Pro Pack', 999.00, 499.00, $db_file_rel, 'Verified downloadable theme package.']);
$product_id = $pdo->lastInsertId();
echo "[PASS] Test product created with ID: $product_id, attached asset: $db_file_rel\n";

// 5. Test Customer User creation
$test_email = 'buyer_' . time() . '@example.com';
$test_pass = password_hash('buyer123', PASSWORD_DEFAULT);
$pdo->prepare("INSERT INTO users (name, whatsapp, email, password, role) VALUES (?, ?, ?, ?, 'user')")
    ->execute(['Test Customer', '01711112222', $test_email, $test_pass]);
$buyer_id = $pdo->lastInsertId();
echo "[PASS] Test buyer created with ID: $buyer_id ($test_email)\n";

// 6. Test Order Placement (Pending status)
$test_trx = 'TRX' . strtoupper(bin2hex(random_bytes(5)));
$stmt = $pdo->prepare("INSERT INTO orders (user_id, product_id, amount, payment_method, trx_id, sender_number, status, created_at) VALUES (?, ?, ?, 'Manual', ?, ?, 'Pending', ?)");
$now = date('Y-m-d H:i:s');
$stmt->execute([$buyer_id, $product_id, 499.00, $test_trx, '01711112222', $now]);
$order_id = $pdo->lastInsertId();
echo "[PASS] Order created with ID: $order_id (Status: Pending, TRX: $test_trx)\n";

// 7. Test Download Authorization while Pending (should NOT be allowed)
$stmt = $pdo->prepare("
    SELECT orders.id, orders.status, products.title, products.product_type, products.file_path, products.drive_link
    FROM orders JOIN products ON products.id = orders.product_id
    WHERE orders.id = ? AND orders.user_id = ? LIMIT 1
");
$stmt->execute([$order_id, $buyer_id]);
$download_item = $stmt->fetch(PDO::FETCH_ASSOC);

if ($download_item && in_array($download_item['status'], ['Completed', 'Active'])) {
    echo "[FAIL] Security issue: Pending order was marked downloadable!\n";
} else {
    echo "[PASS] Security verified: Pending order is blocked from downloading file (Status is {$download_item['status']}).\n";
}

// 8. Test 1-Click Order Activation (Admin Approval: ?action=approve)
$pdo->prepare("UPDATE orders SET status = 'Completed' WHERE id = ?")
    ->execute([$order_id]);
echo "[PASS] Order 1-Click Admin Activation executed (Status updated to Completed).\n";

// 9. Test Download Authorization after Activation
$stmt->execute([$order_id, $buyer_id]);
$active_item = $stmt->fetch(PDO::FETCH_ASSOC);

if ($active_item && in_array($active_item['status'], ['Completed', 'Active'])) {
    echo "[PASS] Activation confirmed: Order is now {$active_item['status']}.\n";
    $extracted_filename = basename(str_replace('\\', '/', $active_item['file_path']));
    $target_file = $downloads_dir . DIRECTORY_SEPARATOR . $extracted_filename;
    if (file_exists($target_file) && is_readable($target_file)) {
        echo "[PASS] Delivery verified: Physical file exists and readable (" . filesize($target_file) . " bytes).\n";
        echo "[PASS] File content integrity: ZIP contains files validly.\n";
    } else {
        echo "[FAIL] Physical file not found at: $target_file\n";
    }
} else {
    echo "[FAIL] Order should be downloadable now.\n";
}

// 10. Test Auto-Approval Order Flow (payment/manual.php instant activation)
$auto_trx = 'TRX_AUTO_' . strtoupper(bin2hex(random_bytes(4)));
$stmt = $pdo->prepare("INSERT INTO orders (user_id, product_id, amount, payment_method, trx_id, sender_number, status, created_at) VALUES (?, ?, ?, 'Manual', ?, ?, 'Completed', ?)");
$stmt->execute([$buyer_id, $product_id, 499.00, $auto_trx, '01800000000', $now]);
$auto_order_id = $pdo->lastInsertId();
echo "[PASS] Auto-approved order test: Order immediately active with ID: $auto_order_id (TRX: $auto_trx)\n";

// 10b. Test HostNekoPay Auto Gateway Order Creation & Webhook Verification
$hnk_trx = 'HNK_' . strtoupper(bin2hex(random_bytes(4)));
$stmt = $pdo->prepare("INSERT INTO orders (user_id, product_id, amount, payment_method, trx_id, sender_number, status, created_at) VALUES (?, ?, ?, 'HostNekoPay', ?, 'Auto Gateway', 'Pending', ?)");
$stmt->execute([$buyer_id, $product_id, 499.00, $hnk_trx, $now]);
$hnk_order_id = $pdo->lastInsertId();
echo "[PASS] HostNekoPay pending order created with ID: $hnk_order_id (TRX: $hnk_trx)\n";

// Simulate successful webhook callback verification
$verified_trx = 'TXN_VERIFIED_' . time();
$upd = $pdo->prepare("UPDATE orders SET status = 'Completed', trx_id = ?, payment_method = 'HostNekoPay' WHERE id = ?");
$upd->execute([$verified_trx, $hnk_order_id]);

$checkHnk = $pdo->query("SELECT status, payment_method, trx_id FROM orders WHERE id = $hnk_order_id")->fetch(PDO::FETCH_ASSOC);
if ($checkHnk['status'] === 'Completed' && $checkHnk['payment_method'] === 'HostNekoPay') {
    echo "[PASS] HostNekoPay automatic verification test: Order marked Completed with verified TRX: {$checkHnk['trx_id']}\n";
} else {
    echo "[FAIL] HostNekoPay order verification failed.\n";
}

// 11. Cleanup test records and file
if (file_exists($test_zip_path)) {
    unlink($test_zip_path);
}
$pdo->prepare("DELETE FROM orders WHERE id IN (?, ?, ?)")->execute([$order_id, $auto_order_id, $hnk_order_id]);
$pdo->prepare("DELETE FROM products WHERE id = ?")->execute([$product_id]);
$pdo->prepare("DELETE FROM users WHERE id = ?")->execute([$buyer_id]);
echo "[PASS] Cleaned up temporary test rows and test file.\n";

echo "=== ALL E2E VERIFICATION CHECKS PASSED SUCCESSFULLY ===\n";
