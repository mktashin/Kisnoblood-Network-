<?php
include 'config.php';
include 'header.php';

$slug = trim($_GET['slug'] ?? '');
if (empty($slug)) {
    $slug = 'privacy-policy';
}

$stmt = $pdo->prepare("SELECT * FROM pages WHERE slug = ? LIMIT 1");
$stmt->execute([$slug]);
$page = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$page) {
    // Fallbacks from settings or defaults
    $fallback_titles = [
        'privacy-policy' => 'Privacy Policy',
        'terms-of-service' => 'Terms of Service',
        'refund-policy' => 'Refund Policy'
    ];
    $title = $fallback_titles[$slug] ?? 'Legal & Policies';
    $content = $set[$slug === 'terms-of-service' ? 'terms_service' : str_replace('-', '_', $slug)] ?? "<p>Information for this page is being updated. Please check back shortly.</p>";
} else {
    $title = $page['title'];
    $content = $page['content'];
}
?>

<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

<style>
    :root {
        --legal-ink: #0f172a;
        --legal-muted: #64748b;
        --legal-line: #e2e8f0;
        --legal-card: #ffffff;
        --legal-blue: #2563eb;
    }

    @media (prefers-color-scheme: dark) {
        :root {
            --legal-ink: #f8fafc;
            --legal-muted: #94a3b8;
            --legal-line: #334155;
            --legal-card: #1e293b;
        }
    }

    .legal-page-card {
        background: var(--legal-card);
        border: 1px solid var(--legal-line);
        border-radius: 24px;
        box-shadow: 0 12px 34px rgba(0, 0, 0, 0.04);
        padding: clamp(24px, 4vw, 48px);
        margin: clamp(20px, 3vw, 40px) auto;
        max-width: 960px;
        color: var(--legal-ink);
        font-family: 'Inter', system-ui, -apple-system, sans-serif;
    }

    .legal-header {
        border-bottom: 1px solid var(--legal-line);
        padding-bottom: 24px;
        margin-bottom: 28px;
    }

    .legal-title {
        font-size: clamp(1.6rem, 3vw, 2.2rem);
        font-weight: 900;
        letter-spacing: -0.5px;
        margin: 10px 0 0;
        color: var(--legal-ink);
    }

    .legal-content {
        font-size: 0.96rem;
        line-height: 1.8;
        color: var(--legal-ink);
    }

    .legal-content h3, .legal-content h2 {
        font-size: 1.25rem;
        font-weight: 800;
        margin-top: 28px;
        margin-bottom: 12px;
        color: var(--legal-blue);
    }

    .legal-content p {
        color: var(--legal-muted);
        margin-bottom: 16px;
    }

    .legal-content ul, .legal-content ol {
        color: var(--legal-muted);
        padding-left: 20px;
        margin-bottom: 16px;
    }

    .legal-content li {
        margin-bottom: 8px;
    }

    .legal-breadcrumb {
        font-size: 0.8rem;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }

    .legal-breadcrumb a {
        color: var(--legal-blue);
        text-decoration: none;
    }
</style>

<div class="container py-4">
    <div class="legal-page-card">
        <div class="legal-header">
            <div class="legal-breadcrumb">
                <a href="index.php"><i class="fas fa-home me-1"></i> Home</a> &nbsp;/&nbsp; <span>Legal</span> &nbsp;/&nbsp; <span style="color:var(--legal-muted);"><?= htmlspecialchars($title) ?></span>
            </div>
            <h1 class="legal-title"><?= htmlspecialchars($title) ?></h1>
            <div class="text-muted small mt-2">
                <i class="far fa-clock me-1"></i> Last updated: <?= date('F d, Y', strtotime($page['updated_at'] ?? 'now')) ?>
            </div>
        </div>

        <div class="legal-content">
            <?= $content ?>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>
