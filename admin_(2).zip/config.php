<?php
if (session_status() === PHP_SESSION_NONE && !headers_sent()) {
    @session_start();
}

$storage_dir    = __DIR__ . '/storage';
$root_config_file = __DIR__ . '/db_config.php';
$sub_config_file  = $storage_dir . '/db_config.php';
$db_config_file   = is_file($root_config_file) ? $root_config_file : $sub_config_file;
$install_lock   = $storage_dir . '/.installed';
$script_name    = basename($_SERVER['SCRIPT_NAME'] ?? '');

// Auto-create storage directory if missing
if (!is_dir($storage_dir)) {
    @mkdir($storage_dir, 0755, true);
}

// Download storage root
if (!defined('JHX_PRIVATE_DOWNLOAD_DIR')) {
    define('JHX_PRIVATE_DOWNLOAD_DIR', __DIR__ . '/downloads');
}
if (!is_dir(JHX_PRIVATE_DOWNLOAD_DIR)) {
    @mkdir(JHX_PRIVATE_DOWNLOAD_DIR, 0700, true);
}

// Load database configuration
$db_config = [];
if (is_file($db_config_file)) {
    $db_config = require $db_config_file;
} elseif (is_file($sub_config_file)) {
    $db_config = require $sub_config_file;
    $db_config_file = $sub_config_file;
}

$driver = strtolower($db_config['driver'] ?? 'mysql');
if (!defined('DB_DRIVER')) {
    define('DB_DRIVER', $driver);
}

// Check if credentials are provided in db_config.php
$has_db_credentials = false;
if ($driver === 'mysql') {
    $has_db_credentials = !empty($db_config['name']) && !empty($db_config['user']);
} else {
    $has_db_credentials = !empty($db_config['file']) || is_file($storage_dir . '/database.sqlite');
}

// Check installation status
$is_installed = (is_file($install_lock) || $has_db_credentials) && is_file($db_config_file);

if (!$is_installed) {
    if ($script_name !== 'install.php' && strpos($_SERVER['REQUEST_URI'] ?? '', 'install.php') === false) {
        $base = rtrim(dirname($_SERVER['SCRIPT_NAME'] ?? '/'), '/\\');
        $target = ($base === '' || $base === '/') ? '/install.php' : $base . '/install.php';
        header('Location: ' . $target);
        exit();
    }
    $pdo = null;
    $set = [];
    return;
}

try {
    if ($driver === 'mysql') {
        $host = $db_config['host'] ?? '127.0.0.1';
        $port = !empty($db_config['port']) ? (int)$db_config['port'] : 3306;
        $name = $db_config['name'] ?? '';
        $user = $db_config['user'] ?? 'root';
        $pass = $db_config['pass'] ?? '';

        $dsn = "mysql:host={$host};port={$port};dbname={$name};charset=utf8mb4";
        $pdo = new PDO($dsn, $user, $pass, [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
            PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4"
        ]);
    } else {
        // SQLite Driver Fallback
        $sqlite_file = $db_config['file'] ?? ($storage_dir . '/database.sqlite');
        $pdo = new PDO('sqlite:' . $sqlite_file, null, null, [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]);
        $pdo->exec("PRAGMA journal_mode = WAL;");
        $pdo->exec("PRAGMA busy_timeout = 5000;");
    }

    // Auto-create install lock if connected successfully to an existing database
    if (!is_file($install_lock)) {
        @file_put_contents($install_lock, date('c') . "\n");
    }
} catch (Throwable $e) {
    if ($script_name === 'install.php') {
        $pdo = null;
    } else {
        die("
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset='utf-8'>
            <title>Database Connection Error</title>
            <style>
                body { font-family: 'Inter', system-ui, sans-serif; background: #0f172a; color: #f8fafc; display: grid; place-items: center; min-height: 100vh; margin: 0; padding: 20px; box-sizing: border-box; }
                .box { max-width: 540px; width: 100%; background: #1e293b; border: 1px solid #334155; border-radius: 20px; padding: 32px; box-shadow: 0 20px 40px rgba(0,0,0,0.5); text-align: center; }
                h2 { color: #f87171; margin-top: 0; font-size: 1.4rem; }
                p { color: #94a3b8; font-size: 0.95rem; line-height: 1.6; }
                code { background: #090d16; color: #38bdf8; padding: 8px 12px; border-radius: 8px; display: block; margin: 16px 0; font-size: 0.85rem; word-break: break-all; }
                .btn { display: inline-block; background: #2563eb; color: #fff; padding: 12px 24px; border-radius: 12px; text-decoration: none; font-weight: 700; margin-top: 10px; }
            </style>
        </head>
        <body>
            <div class='box'>
                <h2>Database Connection Failed</h2>
                <p>Could not connect to the database. Please verify your credentials in <code>db_config.php</code> or run the installer.</p>
                <code>" . htmlspecialchars($e->getMessage()) . "</code>
                <a href='install.php?force=1' class='btn'>Run Installer / Reconfigure</a>
            </div>
        </body>
        </html>
        ");
    }
}

// Load dynamic system settings
$set = [];
if ($pdo) {
    // Defensive column migrations for legacy or newly upgraded databases
    try { $pdo->exec("ALTER TABLE settings ADD COLUMN auto_approve_orders INT NOT NULL DEFAULT 0"); } catch (Throwable $e) {}
    try { $pdo->exec("ALTER TABLE settings ADD COLUMN currency_symbol VARCHAR(10) NOT NULL DEFAULT '৳'"); } catch (Throwable $e) {}
    try { $pdo->exec("ALTER TABLE settings ADD COLUMN upay_number VARCHAR(30) DEFAULT NULL"); } catch (Throwable $e) {}
    try { $pdo->exec("ALTER TABLE settings ADD COLUMN whatsapp_number VARCHAR(30) DEFAULT NULL"); } catch (Throwable $e) {}
    try { $pdo->exec("ALTER TABLE settings ADD COLUMN site_tagline VARCHAR(255) DEFAULT 'Premium Digital Subscriptions & Downloads'"); } catch (Throwable $e) {}
    try { $pdo->exec("ALTER TABLE settings ADD COLUMN favicon VARCHAR(255) DEFAULT ''"); } catch (Throwable $e) {}
    try { $pdo->exec("ALTER TABLE settings ADD COLUMN enable_manual_payment INT NOT NULL DEFAULT 1"); } catch (Throwable $e) {}
    try { $pdo->exec("ALTER TABLE settings ADD COLUMN enable_auto_payment INT NOT NULL DEFAULT 0"); } catch (Throwable $e) {}
    try { $pdo->exec("ALTER TABLE settings ADD COLUMN hostneko_api_key VARCHAR(255) DEFAULT ''"); } catch (Throwable $e) {}
    try { $pdo->exec("ALTER TABLE settings ADD COLUMN hostneko_currency_rate VARCHAR(20) DEFAULT '1'"); } catch (Throwable $e) {}
    try { $pdo->exec("ALTER TABLE products ADD COLUMN file_path VARCHAR(255) DEFAULT NULL"); } catch (Throwable $e) {}
    try { $pdo->exec("ALTER TABLE orders MODIFY COLUMN payment_method VARCHAR(50) NOT NULL DEFAULT 'Manual'"); } catch (Throwable $e) {}
    try { $pdo->exec("ALTER TABLE orders ADD COLUMN payment_data TEXT DEFAULT NULL"); } catch (Throwable $e) {}
    try { $pdo->exec("ALTER TABLE settings ADD COLUMN privacy_policy LONGTEXT DEFAULT NULL"); } catch (Throwable $e) {}
    try { $pdo->exec("ALTER TABLE settings ADD COLUMN terms_service LONGTEXT DEFAULT NULL"); } catch (Throwable $e) {}
    try { $pdo->exec("ALTER TABLE settings ADD COLUMN refund_policy LONGTEXT DEFAULT NULL"); } catch (Throwable $e) {}

    // Auto-create reviews and product gallery tables
    try {
        if ($driver === 'mysql') {
            $pdo->exec("CREATE TABLE IF NOT EXISTS reviews (
                id INT AUTO_INCREMENT PRIMARY KEY,
                client_name VARCHAR(150) NOT NULL,
                client_avatar VARCHAR(255) DEFAULT NULL,
                client_rating INT NOT NULL DEFAULT 5,
                client_review TEXT NOT NULL,
                service_name VARCHAR(150) DEFAULT 'Verified Order',
                badge VARCHAR(100) DEFAULT 'Verified Buyer',
                status INT NOT NULL DEFAULT 1,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

            $pdo->exec("CREATE TABLE IF NOT EXISTS product_images (
                id INT AUTO_INCREMENT PRIMARY KEY,
                product_id INT NOT NULL,
                image_path VARCHAR(255) NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                INDEX (product_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        } else {
            $pdo->exec("CREATE TABLE IF NOT EXISTS reviews (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                client_name TEXT NOT NULL,
                client_avatar TEXT DEFAULT NULL,
                client_rating INTEGER NOT NULL DEFAULT 5,
                client_review TEXT NOT NULL,
                service_name TEXT DEFAULT 'Verified Order',
                badge TEXT DEFAULT 'Verified Buyer',
                status INTEGER NOT NULL DEFAULT 1,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )");

            $pdo->exec("CREATE TABLE IF NOT EXISTS product_images (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                product_id INTEGER NOT NULL,
                image_path TEXT NOT NULL,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )");
        }
    } catch (Throwable $e) {}

    try {
        $stmt = $pdo->query("SELECT * FROM settings WHERE id = 1 LIMIT 1");
        $set = $stmt->fetch(PDO::FETCH_ASSOC) ?: [];
    } catch (Throwable $e) {
        $set = [];
    }
}

// Fallback defaults for settings
$set = array_merge([
    'site_name'              => 'Digital Shop',
    'site_tagline'           => 'Premium Digital Subscriptions & Downloads',
    'logo'                   => 'uploads/jhx_digital_shop_logo_v2.svg',
    'favicon'                => '',
    'site_status'            => 1,
    'auto_approve_orders'    => 0,
    'enable_manual_payment'  => 1,
    'enable_auto_payment'    => 0,
    'hostneko_api_key'       => '',
    'hostneko_currency_rate' => '1',
    'currency_symbol'        => '৳',
    'meta_title'             => 'Digital Shop | Premium Subscriptions',
    'meta_desc'              => 'Buy verified digital subscriptions and downloads instantly.',
    'meta_keys'              => 'digital shop, subscriptions, instant delivery, digital products',
    'tg_link'                => '',
    'tg_user'                => '',
    'yt_link'                => '#',
    'fb_link'                => '#',
    'whatsapp_number'        => '',
    'bkash_number'           => '',
    'nagad_number'           => '',
    'rocket_number'          => '',
    'upay_number'            => '',
    'manual_payment_type'    => 'Personal',
    'manual_payment_note'    => 'Send money to our number and provide Transaction ID.',
    'privacy_policy'         => "<h2>Privacy Policy</h2><p>Welcome to our store. We value your privacy and are committed to protecting your personal data.</p><h3>Information We Collect</h3><p>We only collect essential information required to process your digital orders, including your name, email address, and order transaction details.</p><h3>How We Use Your Data</h3><p>Your details are used strictly for order delivery, authentication, and customer support.</p><h3>Security</h3><p>We implement secure protocols to safeguard your account and transaction data. We never share or sell your information to third parties.</p>",
    'terms_service'          => "<h2>Terms of Service</h2><p>By using our digital marketplace, you agree to comply with and be bound by the following terms.</p><h3>Digital Product Delivery</h3><p>Products are delivered instantly or via manual verification as stated on each product page. Access credentials or downloadable files are accessible in your account upon order completion.</p><h3>Usage License</h3><p>Digital subscriptions and products are for individual or authorized use only. Reselling or unauthorized redistribution is strictly prohibited.</p><h3>Account Security</h3><p>You are responsible for maintaining the confidentiality of your login credentials.</p>",
    'refund_policy'          => "<h2>Refund & Replacement Policy</h2><p>Our priority is ensuring 100% satisfaction with every digital purchase.</p><h3>Eligibility for Replacement / Refund</h3><p>If you experience any technical defect, invalid subscription credential, or delivery failure within the guaranteed warranty period, contact our live support for an immediate replacement or full refund.</p><h3>Non-Refundable Circumstances</h3><p>Refunds are not granted in cases of policy violation or change of mind after successful delivery and activation.</p><h3>Contact Support</h3><p>For any refund requests, contact our live WhatsApp support with your Order ID.</p>"
], (array)$set);

// Maintenance Mode Check
if (isset($set['site_status']) && (int)$set['site_status'] === 0) {
    $is_admin = isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
    if (!$is_admin && !str_contains($_SERVER['PHP_SELF'] ?? '', '/admin/')) {
        die("<div style='text-align:center;margin-top:100px;font-family:sans-serif'><h1>Website is under maintenance.</h1><p>Please check back shortly.</p></div>");
    }
}

// Admin Security Helper
if (!function_exists('check_admin')) {
    function check_admin(): void {
        if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
            header('Location: login.php');
            exit();
        }
    }
}
?>
