# JHX Digital Shop — Portable cPanel Package

**বাংলা setup guide:** `docs/SETUP_BN.md`

## দ্রুত install

১. ZIP extract করে document root-এ দিন।

২. cPanel MySQL Databases থেকে database ও user বানিয়ে All Privileges দিন।

৩. Browser-এ `/install.php` খুলে database information, admin email ও password দিন।

৪. Demo catalog চাইলে checkbox checked রাখুন।

৫. Installation শেষে `install.php` delete করুন।

৬. Admin Panel খুলুন: `/admin/`

এই release-এ automatic payment নেই; শুধু manual payment আছে। Local downloadable files public_html-এর বাইরে private directory-তে রাখা হয় এবং user-এর নিজের Completed order ছাড়া download করা যায় না।
